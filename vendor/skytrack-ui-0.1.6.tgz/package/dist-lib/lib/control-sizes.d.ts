/** Shared heights, typography, horizontal padding, gap, and icon sizes for standard controls. */
export type ControlSize = 'xs' | 'sm' | 'default' | 'lg';
export declare const CONTROL_HEIGHT_CLASSES: Record<ControlSize, string>;
export declare const CONTROL_FONT_SIZE_CLASSES: Record<ControlSize, string>;
export declare const CONTROL_PADDING_X_CLASSES: Record<ControlSize, string>;
export declare const CONTROL_ICON_SIZE_CLASSES: Record<ControlSize, string>;
export declare const CONTROL_GAP_CLASSES: Record<ControlSize, string>;
export declare const CONTROL_CHILD_SVG_CLASSES: Record<ControlSize, string>;
export declare const CONTROL_SIZE_CLASSES: Record<ControlSize, string>;
