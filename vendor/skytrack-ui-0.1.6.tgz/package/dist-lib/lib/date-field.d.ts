import * as React from 'react';
/**
 * Shared editing behaviour for the date pickers' text fields.
 *
 * All three pickers (single, range, week) expose the same interaction: the field
 * shows a formatted value, focusing selects it, typing replaces it, Enter and blur
 * commit, Escape and unparseable text revert. Keeping that in one hook means the
 * three pickers cannot drift apart, and the keyboard contract is defined once.
 *
 * `T` is whatever the picker stores: a `Date`, a `DateRange`, or a week-start `Date`.
 */
export type DateFieldOptions<T> = {
    /** Current committed value. */
    value: T | undefined;
    /** Text shown when the user is not editing. */
    format: (value: T | undefined) => string;
    /** Text the user typed to a value; `undefined` means "not a valid input". */
    parse: (text: string) => T | undefined;
    /** Called with a parsed value, or `undefined` when the field was cleared. */
    commit: (value: T | undefined) => void;
    /** Rejects parses that are syntactically valid but not selectable. */
    isUnavailable?: (value: T) => boolean;
    /**
     * Runs on every keystroke with the raw text and whether the caret sits at the end.
     * Returns the text to actually store, e.g. appending a range separator once the
     * first date is complete.
     */
    completeText?: (text: string, caretAtEnd: boolean) => string;
    /** Called after a successful commit from the keyboard (Enter). */
    onCommitFromKeyboard?: () => void;
    /** Called when the field asks to open the popup (ArrowDown on a closed field). */
    onRequestOpen?: () => void;
};
export type DateField = {
    inputValue: string;
    invalid: boolean;
    /** Text currently being edited, or `null` when the field shows `inputValue`. */
    draft: string | null;
    /** Drops the edit in progress; call after a value is chosen outside the field (e.g. a calendar day). */
    reset: () => void;
    handlers: {
        onFocus: (event: React.FocusEvent<HTMLInputElement>) => void;
        onBlur: () => void;
        onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
        onKeyDown: (event: React.KeyboardEvent<HTMLInputElement>) => void;
        onMouseUp: (event: React.MouseEvent<HTMLInputElement>) => void;
    };
};
export declare function useDateField<T>(options: DateFieldOptions<T>): DateField;
