/**
 * Button cva configuration. Kept in an internal module so the showcase can read
 * the real variant and size axes instead of hand-copying them.
 */
export declare const buttonVariantConfig: {
    variants: {
        variant: {
            default: string;
            destructive: string;
            outline: string;
            secondary: string;
            ghost: string;
            link: string;
        };
        size: {
            default: string;
            xs: string;
            sm: string;
            lg: string;
            icon: string;
            'icon-xs': string;
            'icon-sm': string;
            'icon-lg': string;
        };
    };
    defaultVariants: {
        readonly variant: 'default';
        readonly size: 'default';
    };
};
