type DatePartOrder = 'day' | 'month' | 'year';
/**
 * Reads the day/month/year order a locale uses for numeric dates, so typed dates such as
 * `03/04/2026` are interpreted the same way the locale displays them.
 */
export declare function getNumericDatePartOrder(locale?: string): DatePartOrder[];
/**
 * Parses a date typed into a Date Picker field. Accepts ISO (`2026-11-11`), numeric dates in
 * either the locale order or an unambiguous day-first/month-first order (`11/11/2026`,
 * `11-11-2026`, `11.11.2026`), and month-name dates (`11 Nov 2026`, `Nov 11, 2026`).
 * Returns `undefined` when the text is empty or is not a real calendar date.
 */
export declare function parseDateInput(value: string, locale?: string): Date | undefined;
/** Separator the range picker displays and inserts once a start date is complete. */
export declare const DATE_RANGE_SEPARATOR = " \u2013 ";
/** True when the text already contains a range separator, so typing should not add another. */
export declare function hasDateRangeSeparator(value: string): boolean;
/**
 * True when the text reads as a whole date with an unambiguous four-digit year.
 *
 * The range field uses this to decide a typed start date is finished and the end date can
 * follow. It is deliberately stricter than `parseDateInput`, which already accepts
 * `11/11/2` as 2002: completing on any successful parse would insert the range separator
 * while the user is still typing the year.
 */
export declare function isCompleteDateText(value: string, locale?: string): boolean;
export type ParsedDateRange = {
    from: Date;
    to?: Date;
};
/**
 * Parses a typed date range such as `11 Nov 2026 – 15 Nov 2026`.
 *
 * - A single date is accepted and returned as `{ from }`, matching a first click in the calendar.
 * - An empty end half (`11 Nov 2026 – `) is also `{ from }`, so typing does not need to finish.
 *
 * Order is not checked here: an end date before the start date still parses, because whether
 * that range is selectable is the caller's rule. The range picker rejects it as unavailable.
 */
export declare function parseDateRangeInput(value: string, locale?: string): ParsedDateRange | undefined;
export {};
