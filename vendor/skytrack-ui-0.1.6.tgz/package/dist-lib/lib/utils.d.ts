import { type ClassValue } from 'clsx';
/** Merge class names; later Tailwind classes override earlier ones. */
type StatefulClassName<State> = (state: State) => string | undefined;
export declare function cn(...inputs: ClassValue[]): string;
export declare function cn<State>(...inputs: [...ClassValue[], ClassValue | StatefulClassName<State>]): string | StatefulClassName<State>;
export {};
