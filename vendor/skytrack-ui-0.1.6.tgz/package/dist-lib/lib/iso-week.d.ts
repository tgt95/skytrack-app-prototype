/** Monday that starts the ISO-8601 week containing `date`. */
export declare function startOfISOWeek(date: Date): Date;
/** Sunday that ends the ISO-8601 week starting on `weekStart`. */
export declare function endOfISOWeek(weekStart: Date): Date;
/** ISO-8601 week-year and week number for a date, e.g. `2026, Week 45`. */
export declare function getISOWeek(date: Date): {
    weekYear: number;
    week: number;
};
/** Week label shown in the week picker, e.g. `2026, Week 45`. */
export declare function formatWeekLabel(date: Date): string;
/**
 * Parses typed text in the week picker. Accepts either the week label it displays
 * (`2026, Week 45`, `2026 week 45`) or any date, which is normalised to the Monday of
 * its ISO week. Returns `undefined` for empty text, impossible dates, week numbers
 * outside 1–53, and week numbers that do not exist in that ISO week-year.
 */
export declare function parseWeekInput(value: string, locale?: string): Date | undefined;
