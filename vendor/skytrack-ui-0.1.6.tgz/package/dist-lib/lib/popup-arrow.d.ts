import * as React from 'react';
/** Shared border-aware arrow used by popup surfaces with the same geometry. */
export declare function PopupArrowGlyph(props: React.ComponentProps<'svg'>): React.JSX.Element;
