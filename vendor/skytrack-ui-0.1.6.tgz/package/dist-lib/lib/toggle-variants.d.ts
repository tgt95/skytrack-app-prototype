import { type ControlSize } from './control-sizes';
export declare const toggleSizeClasses: Record<ControlSize | 'icon' | 'icon-xs' | 'icon-sm' | 'icon-lg', string>;
/** Toggle cva configuration, shared with the showcase spec sheet. */
export declare const toggleVariantConfig: {
    variants: {
        variant: {
            default: string;
            outline: string;
            segmented: string;
            brand: string;
        };
        size: {
            default: string;
            xs: string;
            sm: string;
            lg: string;
            icon: string;
            'icon-xs': string;
            'icon-sm': string;
            'icon-lg': string;
        };
    };
    defaultVariants: {
        readonly variant: 'default';
        readonly size: 'default';
    };
};
