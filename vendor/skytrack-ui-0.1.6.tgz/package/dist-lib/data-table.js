import { t as cn } from "./chunks/utils-Cr_eCEw3.js";
import { t as Button } from "./chunks/button-CbGRqxEO.js";
import { Menu, MenuCheckboxItem, MenuCheckboxItemIndicator, MenuPopup, MenuPortal, MenuPositioner, MenuTrigger } from "./menu.js";
import { CheckboxRoot } from "./checkbox.js";
import { RadioGroup, RadioRoot } from "./radio.js";
import { Search } from "./search.js";
import { Pagination, PaginationContent, PaginationItem, PaginationNext, PaginationPrevious } from "./pagination.js";
import * as React from "react";
import { CaretDownIcon, CaretRightIcon, CaretUpDownIcon, CaretUpIcon, CheckIcon, SlidersHorizontalIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
import { columnFilteringFeature, columnVisibilityFeature, createExpandedRowModel, createFilteredRowModel, createPaginatedRowModel, createSortedRowModel, filterFn_includesString, globalFilteringFeature, rowExpandingFeature, rowPaginationFeature, rowSelectionFeature, rowSortingFeature, sortFn_alphanumeric, tableFeatures, useTable } from "@tanstack/react-table";
//#region src/components/ui/data-table.tsx
var dataTableFeatures = tableFeatures({
	columnFilteringFeature,
	globalFilteringFeature,
	filteredRowModel: createFilteredRowModel(),
	rowSortingFeature,
	rowExpandingFeature,
	expandedRowModel: createExpandedRowModel(),
	sortedRowModel: createSortedRowModel(),
	rowPaginationFeature,
	paginatedRowModel: createPaginatedRowModel(),
	columnVisibilityFeature,
	rowSelectionFeature,
	filterFns: { includesString: filterFn_includesString },
	sortFns: { alphanumeric: sortFn_alphanumeric }
});
var alignmentClasses = {
	left: "text-left",
	center: "text-center",
	right: "text-right"
};
var sortButtonAlignmentClasses = {
	left: "justify-start",
	center: "justify-center",
	right: "justify-end"
};
var cellSizeClasses = {
	xs: "px-3 py-1 text-xs",
	sm: "px-3 py-1.5 text-sm",
	md: "px-3 py-2 text-sm",
	lg: "px-3 py-3 text-sm",
	xl: "px-3 py-4 text-base"
};
function DataTable({ columns, data, enableRowSelection = false, selectionMode = "multiple", getRowId, pageSize = 10, size = "md", striped = false, loading = false, searchPlaceholder = "Search records", renderSearch, renderColumnVisibility, renderPagination, renderExpandedRow, getRowCanExpand, tableContainerClassName, emptyMessage = "No results found.", className }) {
	const selectionName = React.useId();
	const table = useTable({
		features: dataTableFeatures,
		columns,
		data,
		getRowId,
		initialState: { pagination: {
			pageIndex: 0,
			pageSize
		} },
		globalFilterFn: "includesString",
		getRowCanExpand: (row) => Boolean(renderExpandedRow) && (getRowCanExpand?.(row.original) ?? true),
		defaultColumn: { sortFn: "alphanumeric" }
	});
	const FlexRender = table.FlexRender;
	const pageRows = table.getRowModel().rows;
	const rowCount = table.getRowCount();
	const pageIndex = table.state.pagination.pageIndex;
	const firstRow = rowCount === 0 ? 0 : pageIndex * table.state.pagination.pageSize + 1;
	const lastRow = rowCount === 0 ? 0 : firstRow + pageRows.length - 1;
	const selectedRowId = Object.keys(table.state.rowSelection).find((rowId) => table.state.rowSelection[rowId]) ?? "";
	const query = table.state.globalFilter ?? "";
	const renderProps = {
		table,
		rowCount,
		firstRow,
		lastRow
	};
	const toolbarSearch = renderSearch ? renderSearch(renderProps) : /* @__PURE__ */ jsx(Search, {
		size: "sm",
		"aria-label": searchPlaceholder,
		placeholder: searchPlaceholder,
		className: "w-full sm:max-w-64",
		value: String(query),
		disabled: loading,
		onValueChange: (nextQuery) => table.setGlobalFilter(nextQuery),
		onClear: () => table.setGlobalFilter("")
	});
	const toolbarColumns = renderColumnVisibility ? renderColumnVisibility(renderProps) : /* @__PURE__ */ jsxs(Menu, { children: [/* @__PURE__ */ jsxs(MenuTrigger, {
		render: /* @__PURE__ */ jsx(Button, {
			type: "button",
			variant: "outline",
			size: "sm",
			disabled: loading
		}),
		children: [/* @__PURE__ */ jsx(SlidersHorizontalIcon, { "aria-hidden": "true" }), "Columns"]
	}), /* @__PURE__ */ jsx(MenuPortal, { children: /* @__PURE__ */ jsx(MenuPositioner, {
		side: "bottom",
		align: "end",
		sideOffset: 4,
		children: /* @__PURE__ */ jsx(MenuPopup, { children: table.getAllLeafColumns().filter((column) => column.getCanHide()).map((column) => /* @__PURE__ */ jsxs(MenuCheckboxItem, {
			inset: true,
			checked: column.getIsVisible(),
			onCheckedChange: (checked) => column.toggleVisibility(checked),
			children: [/* @__PURE__ */ jsx(MenuCheckboxItemIndicator, { children: /* @__PURE__ */ jsx(CheckIcon, {
				className: "size-3.5",
				weight: "bold"
			}) }), typeof column.columnDef.header === "string" ? column.columnDef.header : column.id]
		}, column.id)) })
	}) })] });
	const renderBodyRows = () => {
		if (loading) return Array.from({ length: Math.min(Math.max(pageSize, 3), 5) }, (_, rowIndex) => /* @__PURE__ */ jsxs("tr", {
			"aria-hidden": "true",
			className: "border-b border-border last:border-0",
			children: [
				renderExpandedRow && /* @__PURE__ */ jsx("td", { className: cellSizeClasses[size] }),
				enableRowSelection && /* @__PURE__ */ jsx("td", { className: cellSizeClasses[size] }),
				table.getVisibleLeafColumns().map((column, columnIndex) => /* @__PURE__ */ jsx("td", {
					className: cellSizeClasses[size],
					children: /* @__PURE__ */ jsx("span", { className: cn("block h-3 animate-pulse bg-muted", columnIndex % 3 === 0 ? "w-24" : columnIndex % 3 === 1 ? "w-36" : "w-16") })
				}, column.id))
			]
		}, `loading-${rowIndex}`));
		if (!pageRows.length) return /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", {
			colSpan: table.getVisibleLeafColumns().length + Number(enableRowSelection) + Number(Boolean(renderExpandedRow)),
			className: cn("h-24 text-center text-muted-foreground", cellSizeClasses[size]),
			children: emptyMessage
		}) });
		return pageRows.map((row) => /* @__PURE__ */ jsxs(React.Fragment, { children: [/* @__PURE__ */ jsxs("tr", {
			"data-selected": row.getIsSelected() || void 0,
			className: cn("group border-b border-border last:border-0 bg-background hover:bg-muted/40 data-[selected=true]:bg-accent/50", striped && "odd:bg-muted/20"),
			children: [
				renderExpandedRow && /* @__PURE__ */ jsx("td", {
					className: cn("px-1", cellSizeClasses[size]),
					children: row.getCanExpand() && /* @__PURE__ */ jsx(Button, {
						type: "button",
						variant: "ghost",
						size: "icon-xs",
						"aria-label": `${row.getIsExpanded() ? "Collapse" : "Expand"} details for ${row.id}`,
						"aria-expanded": row.getIsExpanded(),
						onClick: row.getToggleExpandedHandler(),
						children: row.getIsExpanded() ? /* @__PURE__ */ jsx(CaretDownIcon, { "aria-hidden": "true" }) : /* @__PURE__ */ jsx(CaretRightIcon, { "aria-hidden": "true" })
					})
				}),
				enableRowSelection && /* @__PURE__ */ jsx("td", {
					className: cn("w-10", cellSizeClasses[size]),
					children: selectionMode === "single" ? /* @__PURE__ */ jsx(RadioRoot, {
						value: row.id,
						"aria-label": `Select row ${row.id}`,
						disabled: !row.getCanSelect()
					}) : /* @__PURE__ */ jsx(CheckboxRoot, {
						"aria-label": `Select row ${row.id}`,
						checked: row.getIsSelected(),
						disabled: !row.getCanSelect(),
						onCheckedChange: (checked) => row.toggleSelected(checked === true)
					})
				}),
				row.getVisibleCells().map((cell) => /* @__PURE__ */ jsx("td", {
					className: cn("whitespace-nowrap align-middle", cellSizeClasses[size], alignmentClasses[cell.column.columnDef.meta?.align ?? "left"]),
					children: /* @__PURE__ */ jsx(FlexRender, { cell })
				}, cell.id))
			]
		}), renderExpandedRow && row.getIsExpanded() && /* @__PURE__ */ jsx("tr", {
			className: "border-b border-border",
			children: /* @__PURE__ */ jsx("td", {
				colSpan: table.getVisibleLeafColumns().length + Number(enableRowSelection) + 1,
				className: cn("bg-muted/30 px-4 py-3", size === "xs" || size === "sm" ? "text-sm" : void 0),
				children: renderExpandedRow({
					...renderProps,
					row
				})
			})
		})] }, row.id));
	};
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "data-table",
		"aria-busy": loading || void 0,
		className: cn("flex w-full min-w-0 flex-col gap-4", className),
		children: [
			toolbarSearch != null || toolbarColumns != null ? /* @__PURE__ */ jsxs("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [toolbarSearch, toolbarColumns]
			}) : null,
			/* @__PURE__ */ jsx("div", {
				className: cn("w-full overflow-x-auto rounded-(--radius) border border-border", tableContainerClassName),
				children: /* @__PURE__ */ jsxs("table", {
					"aria-busy": loading || void 0,
					className: "w-max min-w-full border-collapse text-left text-sm",
					children: [/* @__PURE__ */ jsx("thead", {
						className: "sticky top-0 z-10 bg-muted text-muted-foreground",
						children: table.getHeaderGroups().map((headerGroup) => /* @__PURE__ */ jsxs("tr", {
							className: "border-b border-border",
							children: [
								renderExpandedRow && headerGroup.id === table.getHeaderGroups()[0]?.id && /* @__PURE__ */ jsx("th", {
									scope: "col",
									className: cn("w-10", cellSizeClasses[size]),
									children: /* @__PURE__ */ jsx("span", {
										className: "sr-only",
										children: "Expand row"
									})
								}),
								enableRowSelection && /* @__PURE__ */ jsxs("th", {
									scope: "col",
									className: cn("w-10", cellSizeClasses[size]),
									children: [(selectionMode !== "multiple" || headerGroup.id !== table.getHeaderGroups()[0]?.id) && /* @__PURE__ */ jsx("span", {
										className: "sr-only",
										children: "Select row"
									}), selectionMode === "multiple" && headerGroup.id === table.getHeaderGroups()[0]?.id && /* @__PURE__ */ jsx(CheckboxRoot, {
										"aria-label": "Select all rows on this page",
										checked: table.getIsAllPageRowsSelected(),
										indeterminate: table.getIsSomePageRowsSelected() && !table.getIsAllPageRowsSelected(),
										onCheckedChange: (checked) => table.toggleAllPageRowsSelected(checked === true)
									})]
								}),
								headerGroup.headers.map((header) => {
									const sorted = header.column.getIsSorted();
									const SortIcon = sorted === "asc" ? CaretUpIcon : sorted === "desc" ? CaretDownIcon : CaretUpDownIcon;
									const align = header.column.columnDef.meta?.align ?? "left";
									return /* @__PURE__ */ jsx("th", {
										scope: "col",
										colSpan: header.colSpan,
										"aria-sort": sorted === "asc" ? "ascending" : sorted === "desc" ? "descending" : void 0,
										className: cn("whitespace-nowrap font-medium", cellSizeClasses[size], alignmentClasses[align]),
										children: header.isPlaceholder ? null : header.column.getCanSort() ? /* @__PURE__ */ jsx(Button, {
											type: "button",
											variant: "ghost",
											size: "sm",
											className: cn("h-auto w-full cursor-pointer gap-1.5 p-0 !px-0 font-medium hover:text-foreground focus-visible:underline", sortButtonAlignmentClasses[align]),
											onClick: header.column.getToggleSortingHandler(),
											children: /* @__PURE__ */ jsxs("span", {
												className: "inline-flex items-center gap-1.5",
												children: [/* @__PURE__ */ jsx(FlexRender, { header }), /* @__PURE__ */ jsx(SortIcon, {
													"aria-hidden": "true",
													className: "size-3.5 shrink-0"
												})]
											})
										}) : /* @__PURE__ */ jsx(FlexRender, { header })
									}, header.id);
								})
							]
						}, headerGroup.id))
					}), enableRowSelection && selectionMode === "single" ? /* @__PURE__ */ jsx(RadioGroup, {
						render: /* @__PURE__ */ jsx("tbody", {}),
						role: "rowgroup",
						name: selectionName,
						value: selectedRowId,
						className: "table-row-group text-left text-sm",
						onValueChange: (value) => table.setRowSelection({ [String(value)]: true }),
						children: renderBodyRows()
					}) : /* @__PURE__ */ jsx("tbody", { children: renderBodyRows() })]
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ jsx("p", {
					role: loading ? "status" : void 0,
					className: "whitespace-nowrap text-sm text-muted-foreground",
					children: loading ? "Loading records…" : `Showing ${firstRow}–${lastRow} of ${rowCount} rows${enableRowSelection ? ` · ${Object.keys(table.state.rowSelection).length} selected` : ""}`
				}), !loading && (renderPagination ? renderPagination(renderProps) : /* @__PURE__ */ jsx(Pagination, {
					className: "mx-0 w-auto justify-end",
					children: /* @__PURE__ */ jsxs(PaginationContent, { children: [
						/* @__PURE__ */ jsx(PaginationItem, { children: /* @__PURE__ */ jsx(PaginationPrevious, {
							href: "#",
							"aria-disabled": !table.getCanPreviousPage(),
							onClick: (event) => {
								event.preventDefault();
								if (table.getCanPreviousPage()) table.previousPage();
							}
						}) }),
						/* @__PURE__ */ jsx(PaginationItem, { children: /* @__PURE__ */ jsxs("span", {
							className: "px-2 text-sm tabular-nums text-muted-foreground",
							children: [
								"Page ",
								Math.min(pageIndex + 1, Math.max(table.getPageCount(), 1)),
								" of",
								" ",
								Math.max(table.getPageCount(), 1)
							]
						}) }),
						/* @__PURE__ */ jsx(PaginationItem, { children: /* @__PURE__ */ jsx(PaginationNext, {
							href: "#",
							"aria-disabled": !table.getCanNextPage(),
							onClick: (event) => {
								event.preventDefault();
								if (table.getCanNextPage()) table.nextPage();
							}
						}) })
					] })
				}))]
			})
		]
	});
}
//#endregion
export { DataTable };
