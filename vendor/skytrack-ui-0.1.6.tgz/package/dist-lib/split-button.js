import { t as cn } from "./chunks/utils-Cr_eCEw3.js";
import { t as Button } from "./chunks/button-D0Q6JLgL.js";
import * as React from "react";
import { CaretDownIcon } from "@phosphor-icons/react";
import { jsx } from "react/jsx-runtime";
//#region src/components/ui/split-button.tsx
var SplitButtonContext = React.createContext(null);
function useSplitButtonContext() {
	return React.useContext(SplitButtonContext) ?? {
		variant: "default",
		size: "default",
		disabled: false
	};
}
/**
* Maps the shared control height to the matching square Button size, so the trigger
* is exactly as tall as the action without a second size scale.
*/
var TRIGGER_SIZE = {
	xs: "icon-xs",
	sm: "icon-sm",
	default: "icon",
	lg: "icon-lg"
};
var splitButtonRootClasses = cn("inline-flex items-stretch", "[&>[data-split-button-part=action]]:rounded-r-none", "[&>[data-split-button-part=trigger]]:rounded-l-none", "[&>[data-split-button-part=trigger]]:-ml-px", "[&>[data-split-button-part]:focus-visible]:relative", "[&>[data-split-button-part]:focus-visible]:z-10");
/**
* Filled variants have no border of their own, so the trigger draws the seam.
* `outline` and `link` are excluded: `outline` already brings a 1px border on both
* parts, and a second border colour there produces a darker, uneven seam.
*/
var splitButtonDividerClasses = cn("[&>[data-split-button-part=trigger]]:border-l", "[&>[data-split-button-part=trigger]]:border-current/20");
/**
* Groups one primary action with a menu of related actions.
* Use it only when one action is clearly dominant; for actions of equal weight use
* a separate Button and Menu.
*/
function SplitButton({ variant = "default", size = "default", disabled = false, className, children, ...props }) {
	return /* @__PURE__ */ jsx(SplitButtonContext.Provider, {
		value: {
			variant,
			size,
			disabled
		},
		children: /* @__PURE__ */ jsx("div", {
			"data-slot": "split-button",
			"data-variant": variant,
			"data-size": size,
			role: "group",
			className: cn(splitButtonRootClasses, variant !== "outline" && variant !== "link" && splitButtonDividerClasses, className),
			...props,
			children
		})
	});
}
/** The dominant action. Renders a standard Button with inherited variant and size. */
function SplitButtonAction({ className, disabled, ...props }) {
	const context = useSplitButtonContext();
	return /* @__PURE__ */ jsx(Button, {
		variant: context.variant,
		size: context.size,
		disabled: disabled ?? context.disabled,
		"data-split-button-part": "action",
		className: cn("relative", className),
		...props
	});
}
/**
* The menu trigger. Compose it with `MenuTrigger render={<SplitButtonTrigger />}` so the
* popup, keyboard behavior, and `aria-expanded` stay owned by Menu.
*/
function SplitButtonTrigger({ className, disabled, children, ...props }) {
	const context = useSplitButtonContext();
	return /* @__PURE__ */ jsx(Button, {
		variant: context.variant,
		size: TRIGGER_SIZE[context.size],
		disabled: disabled ?? context.disabled,
		"data-split-button-part": "trigger",
		className: cn("relative", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretDownIcon, { "aria-hidden": "true" })
	});
}
//#endregion
export { SplitButton, SplitButtonAction, SplitButtonTrigger };
