import { t as cn } from "./chunks/utils-Cr_eCEw3.js";
import { t as focusRing } from "./chunks/focus-ring-BwICtWf4.js";
import { RadioGroup } from "./radio.js";
import "react";
import { CheckIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Radio } from "@base-ui/react/radio";
//#region src/components/ui/choice-button.tsx
/**
* Single-choice group for `ChoiceButton` options. Owns the one selected value
* (`value` / `onValueChange`, or `defaultValue`) and the keyboard radio
* navigation from `skytrack-ui/radio`. Give it an accessible name through
* `aria-label` or a visible label referenced by `aria-labelledby`.
*/
function ChoiceGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx(RadioGroup, {
		"data-slot": "choice-group",
		className: cn("flex flex-row flex-wrap items-start gap-2", className),
		...props
	});
}
/**
* One chip-like choice inside a `ChoiceGroup`. Radio semantics stay owned by
* Base UI Radio: the checked choice shows a checkmark on a filled primary
* surface, the unchecked choice uses an outlined chip. Render one instance per
* option and pass its `value`.
*/
function ChoiceButton({ className, children, ...props }) {
	return /* @__PURE__ */ jsxs(Radio.Root, {
		"data-slot": "choice-button",
		className: cn("flex min-h-8 cursor-pointer select-none items-center gap-2 rounded-(--radius) border border-input bg-background px-3 py-1 text-sm font-medium text-foreground transition-colors", "hover:bg-accent hover:text-accent-foreground", "data-checked:border-primary data-checked:bg-primary data-checked:text-(--foreground-inverse)", "data-checked:hover:bg-primary/90 data-checked:hover:text-(--foreground-inverse)", "data-disabled:cursor-not-allowed data-disabled:opacity-50", focusRing, className),
		...props,
		children: [/* @__PURE__ */ jsx(Radio.Indicator, {
			className: "flex items-center justify-center",
			children: /* @__PURE__ */ jsx(CheckIcon, {
				className: "size-3.5",
				weight: "bold"
			})
		}), children]
	});
}
//#endregion
export { ChoiceButton, ChoiceGroup };
