import { t as cn } from "./chunks/utils-Cr_eCEw3.js";
import { t as focusRing } from "./chunks/focus-ring-BwICtWf4.js";
import { a as CONTROL_ICON_SIZE_CLASSES, s as CONTROL_SIZE_CLASSES } from "./chunks/control-sizes-BA6H39VF.js";
import { RadioGroup } from "./radio.js";
import "react";
import { CheckIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Radio } from "@base-ui/react/radio";
//#region src/components/ui/choice-button.tsx
/**
* Single-choice group for `ChoiceButton` options. Owns the one selected value
* (`value` / `onValueChange`, or `defaultValue`) and the keyboard radio
* navigation from `skytrack-ui/radio`. Give it an accessible name through
* `aria-label` or a visible label referenced by `aria-labelledby`.
*/
function ChoiceGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx(RadioGroup, {
		"data-slot": "choice-group",
		className: cn("flex flex-row flex-wrap items-start gap-2", className),
		...props
	});
}
/**
* One chip-like choice inside a `ChoiceGroup`. Radio semantics stay owned by
* Base UI Radio semantics with shared control sizes and configurable checked
* appearance. Render one instance per option inside `ChoiceGroup` and pass its
* `value`.
*/
function ChoiceButton({ className, children, size = "default", selectedVariant = "default", showCheckmark = true, ...props }) {
	return /* @__PURE__ */ jsxs(Radio.Root, {
		"data-slot": "choice-button",
		"data-size": size,
		className: cn("flex cursor-pointer select-none items-center whitespace-nowrap rounded-(--radius) border border-input bg-background font-medium text-foreground transition-colors", CONTROL_SIZE_CLASSES[size], "hover:bg-accent hover:text-accent-foreground", selectedVariant === "subtle" ? "data-checked:border-primary data-checked:bg-secondary data-checked:text-foreground data-checked:hover:bg-secondary/80 data-checked:hover:text-foreground" : "data-checked:border-primary data-checked:bg-primary data-checked:text-(--foreground-inverse) data-checked:hover:bg-primary/90 data-checked:hover:text-(--foreground-inverse)", "data-disabled:cursor-not-allowed data-disabled:opacity-50", focusRing, className),
		...props,
		children: [showCheckmark ? /* @__PURE__ */ jsx(Radio.Indicator, {
			className: "flex items-center justify-center",
			children: /* @__PURE__ */ jsx(CheckIcon, {
				className: CONTROL_ICON_SIZE_CLASSES[size],
				weight: "bold"
			})
		}) : null, children]
	});
}
//#endregion
export { ChoiceButton, ChoiceGroup };
