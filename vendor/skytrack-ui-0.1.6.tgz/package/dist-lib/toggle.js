import "./toggle-group.js";
import { n as toggleVariants, t as Toggle } from "./chunks/toggle-CPOcGFJ8.js";
export { Toggle, toggleVariants };
