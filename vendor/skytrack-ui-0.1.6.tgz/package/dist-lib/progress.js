import { t as cn } from "./chunks/utils-Cr_eCEw3.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { Progress as Progress$1 } from "@base-ui/react/progress";
//#region src/components/ui/progress.tsx
function Progress({ className, ...props }) {
	return /* @__PURE__ */ jsx(Progress$1.Root, {
		"data-slot": "progress",
		className: cn("grid max-w-full grid-cols-2 gap-y-2", className),
		...props
	});
}
function ProgressLabel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Progress$1.Label, {
		"data-slot": "progress-label",
		className: cn("text-sm font-normal text-foreground", className),
		...props
	});
}
function ProgressValue({ className, ...props }) {
	return /* @__PURE__ */ jsx(Progress$1.Value, {
		"data-slot": "progress-value",
		className: cn("text-right text-sm text-foreground", className),
		...props
	});
}
function ProgressTrack({ className, ...props }) {
	return /* @__PURE__ */ jsx(Progress$1.Track, {
		"data-slot": "progress-track",
		className: cn("col-span-2 h-1 overflow-hidden bg-muted", className),
		...props
	});
}
function ProgressIndicator({ className, ...props }) {
	return /* @__PURE__ */ jsx(Progress$1.Indicator, {
		"data-slot": "progress-indicator",
		className: cn("h-full bg-primary transition-[width] duration-500", "data-indeterminate:w-1/3 data-indeterminate:animate-[progress-indeterminate_1.5s_infinite_ease-in-out]", className),
		...props
	});
}
//#endregion
export { Progress, ProgressIndicator, ProgressLabel, ProgressTrack, ProgressValue };
