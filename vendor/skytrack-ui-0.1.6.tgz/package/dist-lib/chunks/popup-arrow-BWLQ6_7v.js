import "react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/lib/popup-arrow.tsx
/** Shared border-aware arrow used by popup surfaces with the same geometry. */
function PopupArrowGlyph(props) {
	return /* @__PURE__ */ jsxs("svg", {
		width: "20",
		height: "10",
		viewBox: "0 0 20 10",
		fill: "none",
		"aria-hidden": "true",
		focusable: "false",
		...props,
		children: [/* @__PURE__ */ jsx("path", {
			d: "M1 9 L10 1 L19 9 Z",
			fill: "currentColor",
			stroke: "none",
			className: "text-popover"
		}), /* @__PURE__ */ jsx("path", {
			d: "M1 9 L10 1 L19 9",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: 1,
			strokeLinejoin: "round",
			strokeLinecap: "round",
			className: "text-border"
		})]
	});
}
//#endregion
export { PopupArrowGlyph as t };
