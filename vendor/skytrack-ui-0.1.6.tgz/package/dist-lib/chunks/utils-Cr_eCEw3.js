import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
//#region src/lib/utils.ts
function cn(...inputs) {
	if (inputs.find((input) => typeof input === "function")) return (state) => twMerge(clsx(inputs.map((input) => typeof input === "function" ? Reflect.apply(input, void 0, [state]) : input)));
	return twMerge(clsx(inputs));
}
//#endregion
export { cn as t };
