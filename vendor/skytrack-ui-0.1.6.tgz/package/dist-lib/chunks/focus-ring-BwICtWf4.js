//#region src/lib/focus-ring.ts
/** Shared focus ring styles for keyboard-operable controls. */
var focusRing = "outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:border-ring";
//#endregion
export { focusRing as t };
