import { t as cn } from "./chunks/utils-Cr_eCEw3.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { cva } from "class-variance-authority";
//#region src/components/ui/card.tsx
var cardVariants = cva("group/card flex min-w-0 flex-col gap-4 rounded-(--radius) not-[.border-none]:border not-[.border-none]:border-border bg-card shadow-xs", {
	variants: { size: {
		sm: "p-4",
		md: "p-6",
		lg: "p-8"
	} },
	defaultVariants: { size: "md" }
});
/** Content surface with a fixed-height heading row and size-based padding. */
function Card({ as, size = "md", className, ...props }) {
	return /* @__PURE__ */ jsx(as ?? "section", {
		"data-slot": "card",
		"data-size": size ?? "md",
		className: cn(cardVariants({ size }), className),
		...props
	});
}
/** Header stacks a fixed-height title/toolbar row above the description. */
function CardHeader({ className, ...props }) {
	return /* @__PURE__ */ jsx("header", {
		"data-slot": "card-header",
		className: cn("flex min-w-0 flex-col gap-0", className),
		...props
	});
}
/** Fixed-height row for the title and optional toolbar. */
function CardHeading({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "card-heading",
		className: cn("flex h-10 min-w-0 items-center justify-between gap-3", className),
		...props
	});
}
function CardTitle({ as: Heading = "h2", className, ...props }) {
	return /* @__PURE__ */ jsx(Heading, {
		"data-slot": "card-title",
		className: cn("m-0 line-clamp-1 h4", className),
		...props
	});
}
function CardDescription({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "card-description",
		className: cn("mt-0.5 line-clamp-1 text-sm text-muted-foreground group-data-[size=lg]/card:text-base", className),
		...props
	});
}
function CardToolbar({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "card-toolbar",
		role: "group",
		className: cn("flex max-w-1/2 min-w-0 shrink-0 items-center gap-2 overflow-x-auto group-data-[size=lg]/card:[&_[data-slot=button]]:!h-10", className),
		...props
	});
}
function CardContent({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "card-content",
		className: cn("min-w-0", className),
		...props
	});
}
function CardFooter({ className, ...props }) {
	return /* @__PURE__ */ jsx("footer", {
		"data-slot": "card-footer",
		className: cn("flex min-w-0 items-center gap-2", className),
		...props
	});
}
//#endregion
export { Card, CardContent, CardDescription, CardFooter, CardHeader, CardHeading, CardTitle, CardToolbar };
