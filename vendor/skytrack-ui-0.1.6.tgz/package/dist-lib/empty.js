import { t as cn } from "./chunks/utils-Cr_eCEw3.js";
import * as React from "react";
import { FolderDashedIcon } from "@phosphor-icons/react";
import { jsx } from "react/jsx-runtime";
import { cva } from "class-variance-authority";
//#region src/components/ui/empty.tsx
var EmptyContext = React.createContext(null);
function useEmptyContext() {
	return React.useContext(EmptyContext) ?? {
		size: "default",
		variant: "default"
	};
}
var emptyVariants = cva("flex w-full flex-col items-center justify-center text-center text-pretty", {
	variants: { size: {
		sm: "gap-2 p-4",
		default: "gap-4 p-6",
		lg: "gap-6 p-8"
	} },
	defaultVariants: { size: "default" }
});
/** Placeholder for a region with no records, results, or content. */
function Empty({ size = "default", variant = "default", className, children, ...props }) {
	const groupedChildren = React.useMemo(() => {
		const items = React.Children.toArray(children);
		const result = [];
		let buffer = [];
		const flush = () => {
			if (buffer.length > 0) {
				const gapClass = size === "sm" ? "gap-0.5" : "gap-1";
				result.push(/* @__PURE__ */ jsx("div", {
					className: `flex flex-col ${gapClass}`,
					children: buffer
				}, `empty-title-description-${result.length}`));
				buffer = [];
			}
		};
		items.forEach((child) => {
			if (React.isValidElement(child) && (child.type === EmptyTitle || child.type === EmptyDescription)) buffer.push(child);
			else {
				flush();
				result.push(child);
			}
		});
		flush();
		return result;
	}, [children, size]);
	return /* @__PURE__ */ jsx(EmptyContext.Provider, {
		value: {
			size: size ?? "default",
			variant
		},
		children: /* @__PURE__ */ jsx("div", {
			"data-slot": "empty",
			"data-size": size ?? "default",
			"data-variant": variant,
			className: cn(emptyVariants({ size }), className),
			...props,
			children: groupedChildren
		})
	});
}
var emptyMediaVariants = cva("flex shrink-0 items-center justify-center text-muted-foreground [&_img]:object-contain", {
	variants: {
		variant: {
			default: "rounded-(--radius) bg-muted dark:bg-muted/40 p-3 [&>svg]:size-6",
			simple: "p-0 [&>svg]:size-8"
		},
		size: {
			sm: "",
			default: "",
			lg: ""
		}
	},
	compoundVariants: [
		{
			variant: "default",
			size: "sm",
			class: "p-2 [&>svg]:size-5"
		},
		{
			variant: "default",
			size: "lg",
			class: "p-4 [&>svg]:size-7"
		},
		{
			variant: "simple",
			size: "sm",
			class: "[&>svg]:size-6"
		},
		{
			variant: "simple",
			size: "lg",
			class: "[&>svg]:size-12"
		}
	],
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
/** Visual slot. With no children it renders a decorative default mark. */
function EmptyMedia({ className, children, icon = FolderDashedIcon, ...props }) {
	const { size, variant } = useEmptyContext();
	if (children != null) return /* @__PURE__ */ jsx("div", {
		"data-slot": "empty-media",
		className: cn("flex shrink-0 items-center justify-center text-muted-foreground", className),
		...props,
		children
	});
	const mark = React.isValidElement(icon) ? icon : React.createElement(icon, { "aria-hidden": "true" });
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "empty-media",
		"aria-hidden": "true",
		className: cn(emptyMediaVariants({
			variant,
			size
		}), className),
		...props,
		children: mark
	});
}
var emptyTitleVariants = cva("font-medium text-foreground text-balance", {
	variants: { size: {
		sm: "text-sm",
		default: "text-base",
		lg: "text-lg"
	} },
	defaultVariants: { size: "default" }
});
/** Short headline naming what is missing. Rendered as a styled `div`, not a heading element. */
function EmptyTitle({ className, ...props }) {
	const { size } = useEmptyContext();
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "empty-title",
		className: cn(emptyTitleVariants({ size }), className),
		...props
	});
}
var emptyDescriptionVariants = cva("text-muted-foreground text-balance", {
	variants: { size: {
		sm: "text-sm",
		default: "text-sm",
		lg: "text-sm"
	} },
	defaultVariants: { size: "default" }
});
/** Supporting text that explains why the region is empty and what to do next. */
function EmptyDescription({ className, ...props }) {
	const { size } = useEmptyContext();
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "empty-description",
		className: cn(emptyDescriptionVariants({ size }), className),
		...props
	});
}
/** Action row below the copy, usually SkyTrack Buttons or links. */
function EmptyContent({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "empty-content",
		className: cn("flex max-w-full flex-wrap items-center justify-center gap-2", className),
		...props
	});
}
//#endregion
export { Empty, EmptyContent, EmptyDescription, EmptyMedia, EmptyTitle, emptyVariants };
