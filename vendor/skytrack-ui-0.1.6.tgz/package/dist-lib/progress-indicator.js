import { t as cn } from "./chunks/utils-Cr_eCEw3.js";
import "react";
import { CheckIcon, ExclamationMarkIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/components/ui/progress-indicator.tsx
function getStepStatus(step, index, currentStep) {
	return step.status ?? (index < currentStep ? "complete" : index === currentStep ? "current" : "upcoming");
}
var markerClasses = {
	complete: "border-primary bg-primary text-primary-foreground",
	current: "border-primary bg-background text-primary",
	upcoming: "border-border bg-background text-muted-foreground",
	error: "border-destructive bg-background text-destructive",
	disabled: "border-border bg-muted text-muted-foreground"
};
function ProgressStepIndicator({ steps, currentStep = 0, orientation = "horizontal", alignment = "start", className, "aria-label": ariaLabel = "Progress", ...props }) {
	const safeCurrentStep = Math.min(Math.max(currentStep, 0), Math.max(steps.length - 1, 0));
	return /* @__PURE__ */ jsx("ol", {
		"aria-label": ariaLabel,
		"data-slot": "progress-indicator",
		"data-orientation": orientation,
		className: cn("w-full", orientation === "horizontal" ? "flex items-start" : "flex flex-col", className),
		...props,
		children: steps.map((step, index) => {
			const status = getStepStatus(step, index, safeCurrentStep);
			const isCurrent = status === "current";
			const isComplete = status === "complete";
			const isError = status === "error";
			const isLast = index === steps.length - 1;
			const MarkerIcon = isComplete ? CheckIcon : isError ? ExclamationMarkIcon : null;
			return /* @__PURE__ */ jsxs("li", {
				"data-status": status,
				"aria-current": isCurrent ? "step" : void 0,
				"aria-disabled": status === "disabled" || void 0,
				className: cn("min-w-0", orientation === "horizontal" ? "flex flex-1 flex-col gap-2" : "flex gap-3"),
				children: [/* @__PURE__ */ jsxs("div", {
					className: cn("flex", orientation === "horizontal" ? cn("relative w-full items-center", alignment === "center" && "justify-center") : "flex-col items-center"),
					children: [/* @__PURE__ */ jsx("span", {
						"aria-hidden": "true",
						className: cn("flex size-7 shrink-0 items-center justify-center rounded-full border text-sm font-medium", markerClasses[status]),
						children: MarkerIcon ? /* @__PURE__ */ jsx(MarkerIcon, {
							className: "size-4",
							weight: "bold"
						}) : index + 1
					}), !isLast && /* @__PURE__ */ jsx("span", {
						"aria-hidden": "true",
						className: cn("bg-border", isComplete && "bg-primary", orientation === "horizontal" ? alignment === "center" ? "absolute left-[calc(50%+14px)] right-[calc(-50%+14px)] top-1/2 h-px -translate-y-1/2" : "mx-2 h-px min-w-3 flex-1" : "my-1 h-full min-h-5 w-px")
					})]
				}), /* @__PURE__ */ jsxs("div", {
					className: cn("min-w-0", orientation === "horizontal" && alignment === "start" && !isLast && "pe-4", orientation === "vertical" && "pb-4", orientation === "horizontal" && alignment === "center" && "text-center"),
					children: [/* @__PURE__ */ jsxs("p", {
						className: cn("text-base font-medium leading-7", status === "disabled" ? "text-muted-foreground" : "text-foreground", isError && "text-destructive"),
						children: [
							/* @__PURE__ */ jsx("span", {
								className: "sr-only",
								children: status === "complete" ? "Completed: " : status === "current" ? "Current: " : status === "error" ? "Error: " : status === "disabled" ? "Unavailable: " : "Not started: "
							}),
							step.label,
							step.optional && /* @__PURE__ */ jsx("span", {
								className: "ml-1 text-sm font-normal text-muted-foreground",
								children: "Optional"
							})
						]
					}), step.description && /* @__PURE__ */ jsx("p", {
						className: "mt-0.5 text-sm text-muted-foreground",
						children: step.description
					})]
				})]
			}, `${step.label}-${index}`);
		})
	});
}
//#endregion
export { ProgressStepIndicator };
