import { t as cn } from "./chunks/utils-Cr_eCEw3.js";
import { t as focusRing } from "./chunks/focus-ring-BwICtWf4.js";
import { t as PopupArrowGlyph } from "./chunks/popup-arrow-BWLQ6_7v.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { Popover as Popover$1 } from "@base-ui/react/popover";
//#region src/components/ui/popover.tsx
/**
* Popover — a popup anchored to a trigger.
* `Popover` (Root) renders no element of its own, so it is re-exported as-is.
*/
var Popover = Popover$1.Root;
/** Creates a handle that lets detached triggers control this popover. */
var createHandle = Popover$1.createHandle;
function PopoverTrigger({ className, ...props }) {
	return /* @__PURE__ */ jsx(Popover$1.Trigger, {
		"data-slot": "popover-trigger",
		className,
		...props
	});
}
function PopoverPortal({ className, ...props }) {
	return /* @__PURE__ */ jsx(Popover$1.Portal, {
		"data-slot": "popover-portal",
		className: cn("z-50", className),
		...props
	});
}
function PopoverBackdrop({ className, ...props }) {
	return /* @__PURE__ */ jsx(Popover$1.Backdrop, {
		"data-slot": "popover-backdrop",
		className: cn("fixed inset-0 z-50 bg-black/20 transition-opacity duration-150", "data-starting-style:opacity-0 data-ending-style:opacity-0 data-closed:pointer-events-none", className),
		...props
	});
}
function PopoverPositioner({ className, ...props }) {
	return /* @__PURE__ */ jsx(Popover$1.Positioner, {
		"data-slot": "popover-positioner",
		className: cn("z-50 h-[var(--positioner-height)] w-[var(--positioner-width)] max-w-[var(--available-width)]", className),
		...props
	});
}
function PopoverPopup({ className, ...props }) {
	return /* @__PURE__ */ jsx(Popover$1.Popup, {
		"data-slot": "popover-popup",
		className: cn("relative z-50 flex w-[var(--popup-width,auto)] max-w-80 origin-[var(--transform-origin)] flex-col gap-1 rounded-(--radius) border border-border bg-popover p-4 text-popover-foreground shadow-md outline-none", "transition-[scale,opacity] duration-100 ease-out", "data-starting-style:scale-95 data-starting-style:opacity-0", "data-ending-style:scale-95 data-ending-style:opacity-0", "data-instant:transition-none", className),
		...props
	});
}
function PopoverArrow({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Popover$1.Arrow, {
		"data-slot": "popover-arrow",
		className: cn("pointer-events-none absolute z-10 flex h-2.5 w-5 items-center justify-center", "data-[side=top]:bottom-[-9px] data-[side=top]:rotate-180", "data-[side=bottom]:top-[-9px]", "data-[side=left]:right-[-14px] data-[side=left]:rotate-90", "data-[side=right]:left-[-14px] data-[side=right]:-rotate-90", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(PopupArrowGlyph, {})
	});
}
function PopoverTitle({ className, ...props }) {
	return /* @__PURE__ */ jsx(Popover$1.Title, {
		"data-slot": "popover-title",
		className: cn("text-lg heading font-medium text-popover-foreground", className),
		...props
	});
}
function PopoverDescription({ className, ...props }) {
	return /* @__PURE__ */ jsx(Popover$1.Description, {
		"data-slot": "popover-description",
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
function PopoverClose({ className, ...props }) {
	return /* @__PURE__ */ jsx(Popover$1.Close, {
		"data-slot": "popover-close",
		className: cn("absolute top-2 right-2 inline-flex size-6 cursor-pointer items-center justify-center rounded-(--radius) text-muted-foreground transition-colors", "hover:bg-accent hover:text-accent-foreground", "disabled:pointer-events-none disabled:opacity-50 data-disabled:pointer-events-none data-disabled:opacity-50", focusRing, className),
		...props
	});
}
function PopoverViewport({ className, ...props }) {
	return /* @__PURE__ */ jsx(Popover$1.Viewport, {
		"data-slot": "popover-viewport",
		className: cn("relative h-full w-full overflow-clip", className),
		...props
	});
}
//#endregion
export { Popover, PopoverArrow, PopoverBackdrop, PopoverClose, PopoverDescription, PopoverPopup, PopoverPortal, PopoverPositioner, PopoverTitle, PopoverTrigger, PopoverViewport, createHandle };
