import * as React from 'react';
export type CodeBlockTreeNodeKind = 'object' | 'array' | 'string' | 'number' | 'boolean' | 'null';
export type CodeBlockTreeNodeContext = {
    /** The property key (string), array index (number), or null for the root value. */
    key: string | number | null;
    /** Context label alias for key. */
    label: string | number | null;
    /** The value of the JSON node. */
    value: unknown;
    /** Deterministic path identifying this node in the JSON tree (e.g. `$/mission/id`). */
    path: string;
    /** 0-based depth of the node in the JSON hierarchy. */
    depth: number;
    /** The JSON data type of the node. */
    kind: CodeBlockTreeNodeKind;
    /** Alias for kind. */
    nodeKind: CodeBlockTreeNodeKind;
    /** Whether this node can be expanded or collapsed (objects and arrays with entries). */
    expandable: boolean;
    /** Whether the node is currently expanded. */
    expanded: boolean;
    /** The default Shiki syntax-highlighted content for this row. */
    defaultContent: React.ReactNode;
    /** Alias for defaultContent. */
    defaultHighlightedContent: React.ReactNode;
};
export type CodeBlockTreeProps = Omit<React.ComponentProps<'div'>, 'children'> & {
    /** JSON text or a JSON-serializable value. Strings are parsed as JSON text. */
    value?: unknown;
    /** Short context label shown in the code block header. */
    title?: string;
    /** Whether line numbers are visible. Controlled when supplied; defaults to true. */
    lineNumbers?: boolean;
    /** Initial line-number visibility when `lineNumbers` is uncontrolled. Defaults to true. */
    defaultLineNumbers?: boolean;
    /** Whether every expandable JSON node starts expanded. Defaults to false. */
    defaultExpandAll?: boolean;
    /** Whether the header shows the line-number visibility toggle. Defaults to true. */
    showLineNumbersToggle?: boolean;
    /** Called when the built-in line-number toggle changes visibility. */
    onLineNumbersChange?: (enabled: boolean) => void;
    /** Custom header actions rendered after the line-number toggle and before Copy. */
    toolbarActions?: React.ReactNode;
    /** Optional callback to render custom ReactNode/JSX for each JSON node while retaining hierarchy and disclosure. */
    renderNode?: (context: CodeBlockTreeNodeContext) => React.ReactNode;
};
export declare function CodeBlockTree({ value, title, lineNumbers: controlledLineNumbers, defaultLineNumbers, defaultExpandAll, showLineNumbersToggle, onLineNumbersChange, toolbarActions, renderNode: renderNodeProp, className, style, ...props }: CodeBlockTreeProps): React.JSX.Element;
