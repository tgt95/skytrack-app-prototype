import * as React from 'react';
import { type VariantProps } from 'class-variance-authority';
declare const cardVariants: (props?: ({
    size?: "lg" | "md" | "sm" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
type CardElement = 'div' | 'section' | 'article';
type CardOwnProps = VariantProps<typeof cardVariants> & {
    className?: string;
    as?: CardElement;
};
export type CardProps<T extends CardElement = 'section'> = CardOwnProps & Omit<React.ComponentPropsWithoutRef<T>, keyof CardOwnProps>;
/** Content surface with a fixed-height heading row and size-based padding. */
declare function Card<T extends CardElement = 'section'>({ as, size, className, ...props }: CardProps<T>): React.JSX.Element;
export type CardHeaderProps = React.ComponentProps<'header'>;
/** Header stacks a fixed-height title/toolbar row above the description. */
declare function CardHeader({ className, ...props }: CardHeaderProps): React.JSX.Element;
export type CardHeadingProps = React.ComponentProps<'div'>;
/** Fixed-height row for the title and optional toolbar. */
declare function CardHeading({ className, ...props }: CardHeadingProps): React.JSX.Element;
export type CardTitleProps = React.ComponentProps<'h2'> & {
    /** Choose the heading level that matches the page outline. */
    as?: 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6';
};
declare function CardTitle({ as: Heading, className, ...props }: CardTitleProps): React.JSX.Element;
export type CardDescriptionProps = React.ComponentProps<'p'>;
declare function CardDescription({ className, ...props }: CardDescriptionProps): React.JSX.Element;
export type CardToolbarProps = React.ComponentProps<'div'>;
declare function CardToolbar({ className, ...props }: CardToolbarProps): React.JSX.Element;
export type CardContentProps = React.ComponentProps<'div'>;
declare function CardContent({ className, ...props }: CardContentProps): React.JSX.Element;
export type CardFooterProps = React.ComponentProps<'footer'>;
declare function CardFooter({ className, ...props }: CardFooterProps): React.JSX.Element;
export { Card, CardContent, CardDescription, CardFooter, CardHeader, CardHeading, CardTitle, CardToolbar };
