import * as React from 'react';
import { Field } from '@base-ui/react/field';
import { type ControlSize } from '@/lib/control-sizes';
export type FieldOrientation = 'vertical' | 'horizontal';
type FieldRootProps = React.ComponentProps<typeof Field.Root> & {
    /** `vertical` stacks the label above the control; `horizontal` places them side by side. */
    orientation?: FieldOrientation;
};
declare function FieldRoot({ className, orientation, ...props }: FieldRootProps): React.JSX.Element;
declare function FieldLabel({ className, ...props }: React.ComponentProps<typeof Field.Label>): React.JSX.Element;
type FieldControlProps = Omit<React.ComponentProps<typeof Field.Control>, 'size'> & {
    size?: ControlSize;
};
declare function FieldControl({ className, size, ...props }: FieldControlProps): React.JSX.Element;
declare function FieldDescription({ className, ...props }: React.ComponentProps<typeof Field.Description>): React.JSX.Element;
declare function FieldError({ className, ...props }: React.ComponentProps<typeof Field.Error>): React.JSX.Element;
type FieldValidityProps = Omit<React.ComponentProps<typeof Field.Validity>, 'className'> & {
    className?: string;
};
declare function FieldValidity({ className, children, ...props }: FieldValidityProps): React.JSX.Element;
declare function FieldItem({ className, ...props }: React.ComponentProps<typeof Field.Item>): React.JSX.Element;
/** Convenience layout part: tight vertical stack for related fields. */
declare function FieldGroup({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
/** Convenience layout part: horizontal row for a control and its message. */
declare function FieldRow({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
export { Field, FieldRoot, FieldLabel, FieldControl, FieldDescription, FieldError, FieldValidity, FieldItem, FieldGroup, FieldRow };
