import * as React from 'react';
import { NumberField as BaseNumberField } from '@base-ui/react/number-field';
import { type ControlSize } from '@/lib/control-sizes';
type NumberFieldProps = Omit<React.ComponentProps<typeof BaseNumberField.Root>, 'size'> & {
    size?: ControlSize;
};
declare function NumberField({ className, size, ...props }: NumberFieldProps): React.JSX.Element;
type NumberFieldGroupProps = Omit<React.ComponentProps<typeof BaseNumberField.Group>, 'size'> & {
    size?: ControlSize;
};
declare function NumberFieldGroup({ className, size, ...props }: NumberFieldGroupProps): React.JSX.Element;
type NumberFieldInputProps = Omit<React.ComponentProps<typeof BaseNumberField.Input>, 'size'> & {
    size?: ControlSize;
};
declare function NumberFieldInput({ className, size, ...props }: NumberFieldInputProps): React.JSX.Element;
type NumberFieldStepperProps = Omit<React.ComponentProps<typeof BaseNumberField.Decrement>, 'size'> & {
    size?: ControlSize;
};
declare function NumberFieldDecrement({ className, children, size, ...props }: NumberFieldStepperProps): React.JSX.Element;
type NumberFieldIncrementProps = Omit<React.ComponentProps<typeof BaseNumberField.Increment>, 'size'> & {
    size?: ControlSize;
};
declare function NumberFieldIncrement({ className, children, size, ...props }: NumberFieldIncrementProps): React.JSX.Element;
declare function NumberFieldScrubArea({ className, ...props }: React.ComponentProps<typeof BaseNumberField.ScrubArea>): React.JSX.Element;
declare function NumberFieldScrubAreaCursor({ className, ...props }: React.ComponentProps<typeof BaseNumberField.ScrubAreaCursor>): React.JSX.Element;
export { NumberField, NumberFieldGroup, NumberFieldInput, NumberFieldDecrement, NumberFieldIncrement, NumberFieldScrubArea, NumberFieldScrubAreaCursor };
