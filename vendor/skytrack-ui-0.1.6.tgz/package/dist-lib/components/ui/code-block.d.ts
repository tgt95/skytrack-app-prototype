import * as React from 'react';
import { type VariantProps } from 'class-variance-authority';
import { type ButtonProps } from '@/components/ui/button';
type CodeBlockSize = 'default' | 'sm' | 'xs';
declare const codeBlockVariants: (props?: ({
    variant?: "default" | "destructive" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type CodeBlockProps = React.ComponentProps<'div'> & VariantProps<typeof codeBlockVariants> & {
    size?: CodeBlockSize;
    lineNumbers?: boolean;
    lineIndex?: boolean;
    showLineNumbers?: boolean;
    defaultLineNumbers?: boolean;
    defaultLineIndex?: boolean;
    startLine?: number;
    startLineIndex?: number;
    onLineNumbersChange?: (enabled: boolean) => void;
};
declare function CodeBlock({ className, size, variant, lineNumbers: controlledLineNumbers, lineIndex: controlledLineIndex, showLineNumbers: controlledShowLineNumbers, defaultLineNumbers, defaultLineIndex, startLine, startLineIndex, onLineNumbersChange, children, ...props }: CodeBlockProps): React.JSX.Element;
declare function CodeBlockHeader({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
declare function CodeBlockTitle({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
declare function CodeBlockActions({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
export type CodeBlockCopyButtonProps = Omit<ButtonProps, 'children'> & {
    value: string;
    copyLabel?: string;
    copiedLabel?: string;
    copyFailedLabel?: string;
};
declare function CodeBlockCopyButton({ value, className, onClick, copyLabel, copiedLabel, copyFailedLabel, variant, size, ...props }: CodeBlockCopyButtonProps): React.JSX.Element;
export type CodeBlockContentProps = Omit<React.ComponentProps<'pre'>, 'children'> & {
    children?: React.ReactNode;
    language?: string;
    wrap?: boolean;
    lineNumbers?: boolean;
    lineIndex?: boolean;
    showLineNumbers?: boolean;
    startLine?: number;
    startLineIndex?: number;
};
declare function CodeBlockContent({ children, language, wrap, lineNumbers: propLineNumbers, lineIndex: propLineIndex, showLineNumbers: propShowLineNumbers, startLine: propStartLine, startLineIndex: propStartLineIndex, tabIndex, style, className, ...props }: CodeBlockContentProps): React.JSX.Element;
export type CodeBlockLineProps = React.ComponentProps<'span'> & {
    variant?: 'default' | 'added' | 'removed' | 'highlighted';
    lineNumber?: string | number;
    'data-line-number'?: string;
};
declare function CodeBlockLine({ variant, lineNumber, className, children, ...props }: CodeBlockLineProps): React.JSX.Element;
export type CodeBlockLineNumbersToggleProps = Omit<ButtonProps, 'children'> & {
    pressedLabel?: string;
    unpressedLabel?: string;
};
declare function CodeBlockLineNumbersToggle({ className, variant, size, pressedLabel, unpressedLabel, onClick, ...props }: CodeBlockLineNumbersToggleProps): React.JSX.Element;
declare const CodeBlockLineIndexToggle: typeof CodeBlockLineNumbersToggle;
export type CodeBlockLineIndexToggleProps = CodeBlockLineNumbersToggleProps;
declare function CodeBlockFooter({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
export declare function useHighlightedCode(code: string, language: string): React.ReactNode[];
export { CodeBlock, CodeBlockActions, CodeBlockContent, CodeBlockCopyButton, CodeBlockFooter, CodeBlockHeader, CodeBlockLine, CodeBlockLineIndexToggle, CodeBlockLineNumbersToggle, CodeBlockTitle };
