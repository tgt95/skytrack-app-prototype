import * as React from 'react';
import { Radio } from '@base-ui/react/radio';
import { RadioGroup } from '@/components/ui/radio';
import { type ControlSize } from '@/lib/control-sizes';
export type ChoiceGroupProps = React.ComponentProps<typeof RadioGroup>;
/**
 * Single-choice group for `ChoiceButton` options. Owns the one selected value
 * (`value` / `onValueChange`, or `defaultValue`) and the keyboard radio
 * navigation from `skytrack-ui/radio`. Give it an accessible name through
 * `aria-label` or a visible label referenced by `aria-labelledby`.
 */
declare function ChoiceGroup({ className, ...props }: ChoiceGroupProps): React.JSX.Element;
export type ChoiceButtonProps = React.ComponentProps<typeof Radio.Root> & {
    /** Choice content, usually a short label. */
    children: React.ReactNode;
    /** Shared control size. */
    size?: ControlSize;
    /** Visual treatment for the checked choice. */
    selectedVariant?: 'default' | 'subtle';
    /** Show the decorative checkmark while checked. */
    showCheckmark?: boolean;
};
/**
 * One chip-like choice inside a `ChoiceGroup`. Radio semantics stay owned by
 * Base UI Radio semantics with shared control sizes and configurable checked
 * appearance. Render one instance per option inside `ChoiceGroup` and pass its
 * `value`.
 */
declare function ChoiceButton({ className, children, size, selectedVariant, showCheckmark, ...props }: ChoiceButtonProps): React.JSX.Element;
export { ChoiceGroup, ChoiceButton };
