import * as React from 'react';
import { Radio } from '@base-ui/react/radio';
import { RadioGroup } from '@/components/ui/radio';
export type ChoiceGroupProps = React.ComponentProps<typeof RadioGroup>;
/**
 * Single-choice group for `ChoiceButton` options. Owns the one selected value
 * (`value` / `onValueChange`, or `defaultValue`) and the keyboard radio
 * navigation from `skytrack-ui/radio`. Give it an accessible name through
 * `aria-label` or a visible label referenced by `aria-labelledby`.
 */
declare function ChoiceGroup({ className, ...props }: ChoiceGroupProps): React.JSX.Element;
export type ChoiceButtonProps = React.ComponentProps<typeof Radio.Root> & {
    /** Choice content, usually a short label. */
    children: React.ReactNode;
};
/**
 * One chip-like choice inside a `ChoiceGroup`. Radio semantics stay owned by
 * Base UI Radio: the checked choice shows a checkmark on a filled primary
 * surface, the unchecked choice uses an outlined chip. Render one instance per
 * option and pass its `value`.
 */
declare function ChoiceButton({ className, children, ...props }: ChoiceButtonProps): React.JSX.Element;
export { ChoiceGroup, ChoiceButton };
