import * as React from 'react';
import { Command as CommandPrimitive } from 'cmdk';
import { Dialog } from '@/components/ui/dialog';
declare function Command({ className, ...props }: React.ComponentProps<typeof CommandPrimitive>): React.JSX.Element;
declare function CommandDialog({ className, children, ...props }: Omit<React.ComponentProps<typeof Dialog>, 'children'> & {
    children: React.ReactNode;
    className?: string;
}): React.JSX.Element;
declare function CommandInput({ className, ...props }: React.ComponentProps<typeof CommandPrimitive.Input>): React.JSX.Element;
declare function CommandList({ className, ...props }: React.ComponentProps<typeof CommandPrimitive.List>): React.JSX.Element;
declare function CommandEmpty({ className, children, ...props }: React.ComponentProps<typeof CommandPrimitive.Empty>): React.JSX.Element;
declare function CommandGroup({ className, ...props }: React.ComponentProps<typeof CommandPrimitive.Group>): React.JSX.Element;
declare function CommandItem({ className, ...props }: React.ComponentProps<typeof CommandPrimitive.Item>): React.JSX.Element;
declare function CommandSeparator({ className, ...props }: React.ComponentProps<typeof CommandPrimitive.Separator>): React.JSX.Element;
declare function CommandShortcut({ className, ...props }: React.ComponentProps<'span'>): React.JSX.Element;
export { Command, CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator, CommandShortcut };
