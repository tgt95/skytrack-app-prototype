import * as React from 'react';
import type { VariantProps } from 'class-variance-authority';
import { buttonVariants } from '@/components/ui/button';
import type { ControlSize } from '@/lib/control-sizes';
import { type PopoverTriggerProps } from '@/components/ui/popover';
/** One selectable option in the filter popup. */
export type FilterButtonOption = {
    value: string;
    /** Complete option content; may be text or rich content such as a colored Badge. */
    label: React.ReactNode;
    disabled?: boolean;
};
export type FilterButtonProps = Omit<PopoverTriggerProps, 'children' | 'render'> & Omit<VariantProps<typeof buttonVariants>, 'size' | 'variant'> & {
    /**
     * Complete trigger content exactly as supplied by the caller: label, count
     * badge, icon. The component never generates or appends trigger content, so
     * the visible control value stays caller-owned.
     */
    children: React.ReactNode;
    /** Heading inside the popup. Also names the popup for assistive technology. */
    title: string;
    /** Button variant shared by the trigger and clear segment. */
    variant?: NonNullable<VariantProps<typeof buttonVariants>['variant']>;
    /** Accessible name for the conditional clear button. Defaults to `Clear ${title}`. */
    clearLabel?: string;
    /** Button control size. */
    size?: ControlSize;
    /** Controlled selected option values. */
    value: string[];
    onValueChange: (value: string[]) => void;
    options: FilterButtonOption[];
};
/**
 * Opens a multi-select filter popup from a styled Button trigger.
 * The trigger renders the caller's `children` through the Popover trigger
 * render slot, so popup state stays owned by `skytrack-ui/popover` and no
 * button is nested inside another. When values are selected, a SplitButton-style
 * X segment clears this filter's values.
 */
declare function FilterButton({ title, clearLabel, value, onValueChange, options, variant, size, children, className, disabled, ...props }: FilterButtonProps): React.JSX.Element;
export { FilterButton };
