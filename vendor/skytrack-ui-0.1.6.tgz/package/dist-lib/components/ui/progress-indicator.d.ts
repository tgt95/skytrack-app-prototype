import * as React from 'react';
export type ProgressStepStatus = 'complete' | 'current' | 'upcoming' | 'error' | 'disabled';
export type ProgressIndicatorOrientation = 'horizontal' | 'vertical';
export type ProgressIndicatorStep = {
    label: string;
    description?: string;
    optional?: boolean;
    status?: ProgressStepStatus;
};
export type ProgressIndicatorAlignment = 'start' | 'center';
export type ProgressStepIndicatorProps = React.ComponentProps<'ol'> & {
    steps: ProgressIndicatorStep[];
    currentStep?: number;
    orientation?: ProgressIndicatorOrientation;
    /** Align each horizontal step marker and its text to the start or center of its column. */
    alignment?: ProgressIndicatorAlignment;
};
declare function ProgressStepIndicator({ steps, currentStep, orientation, alignment, className, 'aria-label': ariaLabel, ...props }: ProgressStepIndicatorProps): React.JSX.Element;
export { ProgressStepIndicator };
