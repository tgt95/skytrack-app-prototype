import * as React from 'react';
import { type VariantProps } from 'class-variance-authority';
export type EmptySize = 'sm' | 'default' | 'lg';
export type EmptyVariant = 'default' | 'simple';
export declare const emptyVariants: (props?: ({
    size?: "default" | "lg" | "sm" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type EmptyProps = React.ComponentProps<'div'> & VariantProps<typeof emptyVariants> & {
    /** `simple` drops the media tile and shows a larger bare mark for compact regions. */
    variant?: EmptyVariant;
};
/** Placeholder for a region with no records, results, or content. */
declare function Empty({ size, variant, className, children, ...props }: EmptyProps): React.JSX.Element;
export type EmptyMediaProps = React.ComponentProps<'div'> & {
    /** Icon rendered as the decorative default mark when no children are provided. Accepts a component or an element. Defaults to `FolderDashedIcon`. */
    icon?: React.ComponentType<{
        className?: string;
    }> | React.ReactElement;
};
/** Visual slot. With no children it renders a decorative default mark. */
declare function EmptyMedia({ className, children, icon, ...props }: EmptyMediaProps): React.JSX.Element;
export type EmptyTitleProps = React.ComponentProps<'div'>;
/** Short headline naming what is missing. Rendered as a styled `div`, not a heading element. */
declare function EmptyTitle({ className, ...props }: EmptyTitleProps): React.JSX.Element;
export type EmptyDescriptionProps = React.ComponentProps<'div'>;
/** Supporting text that explains why the region is empty and what to do next. */
declare function EmptyDescription({ className, ...props }: EmptyDescriptionProps): React.JSX.Element;
export type EmptyContentProps = React.ComponentProps<'div'>;
/** Action row below the copy, usually SkyTrack Buttons or links. */
declare function EmptyContent({ className, ...props }: EmptyContentProps): React.JSX.Element;
export { Empty, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent };
