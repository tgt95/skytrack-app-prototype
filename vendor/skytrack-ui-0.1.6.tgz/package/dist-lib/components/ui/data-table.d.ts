import * as React from 'react';
import { type ColumnDef, type Row, type RowData, type ReactTable } from '@tanstack/react-table';
declare const dataTableFeatures: {
    columnFilteringFeature: import("@tanstack/table-core").TableFeature;
    globalFilteringFeature: import("@tanstack/table-core").TableFeature;
    filteredRowModel: (table: import("@tanstack/table-core").Table<any, any>) => () => import("@tanstack/table-core").RowModel<any, any>;
    rowSortingFeature: import("@tanstack/table-core").TableFeature;
    rowExpandingFeature: import("@tanstack/table-core").TableFeature;
    expandedRowModel: (table: import("@tanstack/table-core").Table<any, any>) => () => import("@tanstack/table-core").RowModel<any, any>;
    sortedRowModel: (table: import("@tanstack/table-core").Table<any, any>) => () => import("@tanstack/table-core").RowModel<any, any>;
    rowPaginationFeature: import("@tanstack/table-core").TableFeature;
    paginatedRowModel: (table: import("@tanstack/table-core").Table<any, any>) => () => import("@tanstack/table-core").RowModel<any, any>;
    columnVisibilityFeature: import("@tanstack/table-core").TableFeature;
    rowSelectionFeature: import("@tanstack/table-core").TableFeature;
    filterFns: {
        includesString: import("@tanstack/table-core").CreatedFilterFn<any, any>;
    };
    sortFns: {
        alphanumeric: import("@tanstack/table-core").CreatedSortFn<any, any>;
    };
};
type DataTableAlignment = 'left' | 'center' | 'right';
export type DataTableSelectionMode = 'multiple' | 'single';
export type DataTableSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
type DataTableColumnMeta = {
    align?: DataTableAlignment;
    wrap?: boolean;
};
export type DataTableColumnDef<TData extends RowData> = ColumnDef<typeof dataTableFeatures, TData, unknown> & {
    meta?: DataTableColumnMeta;
};
export type DataTableRenderProps<TData extends RowData> = {
    table: ReactTable<typeof dataTableFeatures, TData>;
    rowCount: number;
    firstRow: number;
    lastRow: number;
};
export type DataTableExpandedRowProps<TData extends RowData> = DataTableRenderProps<TData> & {
    row: Row<typeof dataTableFeatures, TData>;
};
export type DataTableProps<TData extends RowData> = {
    columns: DataTableColumnDef<TData>[];
    data: TData[];
    enableRowSelection?: boolean;
    selectionMode?: DataTableSelectionMode;
    getRowId?: (originalRow: TData, index: number) => string;
    pageSize?: number;
    size?: DataTableSize;
    striped?: boolean;
    loading?: boolean;
    searchPlaceholder?: string;
    renderSearch?: (props: DataTableRenderProps<TData>) => React.ReactNode;
    renderColumnVisibility?: (props: DataTableRenderProps<TData>) => React.ReactNode;
    renderPagination?: (props: DataTableRenderProps<TData>) => React.ReactNode;
    renderExpandedRow?: (props: DataTableExpandedRowProps<TData>) => React.ReactNode;
    getRowCanExpand?: (originalRow: TData) => boolean;
    tableContainerClassName?: string;
    /** Content of the no-data / no-match state, rendered inside a compact Empty in the spanning cell. */
    emptyMessage?: React.ReactNode;
    /** Render the current row range beneath the table. Defaults to true. */
    showRowCount?: boolean;
    className?: string;
};
declare function DataTable<TData extends RowData>({ columns, data, enableRowSelection, selectionMode, getRowId, pageSize, size, striped, loading, searchPlaceholder, renderSearch, renderColumnVisibility, renderPagination, renderExpandedRow, getRowCanExpand, tableContainerClassName, emptyMessage, showRowCount, className }: DataTableProps<TData>): React.JSX.Element;
export { DataTable };
