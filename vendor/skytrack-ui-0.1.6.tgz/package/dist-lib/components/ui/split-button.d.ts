import * as React from 'react';
import type { VariantProps } from 'class-variance-authority';
import { buttonVariants, type ButtonProps } from '@/components/ui/button';
import type { ControlSize } from '@/lib/control-sizes';
/**
 * Split Button reuses the Button variant and size axes instead of defining its own
 * visual tokens. Deriving the types from `buttonVariants` keeps the two in sync:
 * a new Button variant or control height reaches Split Button without edits here.
 */
export type SplitButtonVariant = NonNullable<VariantProps<typeof buttonVariants>['variant']>;
/** Control heights shared with Button (xs 24 · sm 32 · default 40 · lg 48 px). */
export type SplitButtonSize = ControlSize;
export type SplitButtonProps = React.ComponentProps<'div'> & {
    /** Button variant applied to every part unless a part overrides it. */
    variant?: SplitButtonVariant;
    /** Button control size applied to every part. The menu trigger keeps the same height. */
    size?: SplitButtonSize;
    /** Disables the action and the menu trigger together. */
    disabled?: boolean;
};
/**
 * Groups one primary action with a menu of related actions.
 * Use it only when one action is clearly dominant; for actions of equal weight use
 * a separate Button and Menu.
 */
declare function SplitButton({ variant, size, disabled, className, children, ...props }: SplitButtonProps): React.JSX.Element;
export type SplitButtonActionProps = Omit<ButtonProps, 'variant' | 'size'>;
/** The dominant action. Renders a standard Button with inherited variant and size. */
declare function SplitButtonAction({ className, disabled, ...props }: SplitButtonActionProps): React.JSX.Element;
export type SplitButtonTriggerProps = Omit<ButtonProps, 'variant' | 'size' | 'children'> & {
    /** Accessible name for the menu trigger. Required: the caret alone has no label. */
    'aria-label': string;
    /** Replaces the default caret icon. Keep it decorative. */
    children?: React.ReactNode;
};
/**
 * The menu trigger. Compose it with `MenuTrigger render={<SplitButtonTrigger />}` so the
 * popup, keyboard behavior, and `aria-expanded` stay owned by Menu.
 */
declare function SplitButtonTrigger({ className, disabled, children, ...props }: SplitButtonTriggerProps): React.JSX.Element;
export { SplitButton, SplitButtonAction, SplitButtonTrigger };
