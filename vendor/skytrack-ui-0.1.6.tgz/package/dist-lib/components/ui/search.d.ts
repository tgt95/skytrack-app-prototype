import * as React from 'react';
import { type InputProps } from '@/components/ui/input';
export type SearchProps = Omit<InputProps, 'type' | 'startAdornment' | 'endAdornment' | 'value' | 'defaultValue'> & {
    value?: string;
    defaultValue?: string;
    onValueChange?: (value: string) => void;
    onClear?: () => void;
    appearance?: 'default' | 'fluid';
};
declare function Search({ value: valueProp, defaultValue, onValueChange, onClear, appearance, disabled, className, onChange, ...props }: SearchProps): React.JSX.Element;
export { Search };
