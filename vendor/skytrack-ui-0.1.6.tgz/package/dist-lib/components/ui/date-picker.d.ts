import * as React from 'react';
import { type DateRange, type DayPickerProps } from 'react-day-picker';
type DistributiveOmit<T, K extends PropertyKey> = T extends unknown ? Omit<T, K> : never;
/** Calendar props shared by the pickers; `mode`, selection and nav layout stay internal. */
type PickerCalendarProps<Mode extends 'single' | 'range'> = DistributiveOmit<Extract<DayPickerProps, {
    mode: Mode;
}>, 'mode' | 'selected' | 'onSelect' | 'captionLayout' | 'navLayout'>;
export type DatePickerProps = {
    id?: string;
    'aria-label'?: string;
    'aria-labelledby'?: string;
    value?: Date;
    defaultValue?: Date;
    onValueChange?: (value: Date | undefined) => void;
    placeholder?: string;
    disabled?: boolean;
    className?: string;
    buttonClassName?: string;
    calendarClassName?: string;
    /** Accessible name for the calendar button that opens the popover. */
    calendarButtonLabel?: string;
    calendarProps?: PickerCalendarProps<'single'>;
};
export type DateRangePickerProps = {
    id?: string;
    'aria-label'?: string;
    'aria-labelledby'?: string;
    value?: DateRange;
    defaultValue?: DateRange;
    onValueChange?: (value: DateRange | undefined) => void;
    placeholder?: string;
    disabled?: boolean;
    className?: string;
    buttonClassName?: string;
    calendarClassName?: string;
    /** Accessible name for the calendar button that opens the popover. */
    calendarButtonLabel?: string;
    calendarProps?: PickerCalendarProps<'range'>;
};
export type DateWeekPickerProps = {
    id?: string;
    'aria-label'?: string;
    'aria-labelledby'?: string;
    /** Any date inside the selected week; the value is normalized to that week's Monday. */
    value?: Date;
    defaultValue?: Date;
    onValueChange?: (value: Date | undefined) => void;
    placeholder?: string;
    disabled?: boolean;
    className?: string;
    buttonClassName?: string;
    calendarClassName?: string;
    /** Accessible name for the calendar button that opens the popover. */
    calendarButtonLabel?: string;
    calendarProps?: PickerCalendarProps<'range'>;
};
declare function DatePicker(props: DatePickerProps): React.JSX.Element;
declare function DateRangePicker(props: DateRangePickerProps): React.JSX.Element;
declare function DateWeekPicker(props: DateWeekPickerProps): React.JSX.Element;
export { DatePicker, DateRangePicker, DateWeekPicker };
