import * as React from 'react';
import { Button as BaseButton } from '@base-ui/react/button';
import { type VariantProps } from 'class-variance-authority';
import { focusRing } from '@/lib/focus-ring';
/** Keep existing button-subpath imports working while shared controls use the common module. */
export { focusRing };
export { CONTROL_SIZE_CLASSES as controlSizeClasses } from '@/lib/control-sizes';
export type { ControlSize } from '@/lib/control-sizes';
export declare const buttonVariants: (props?: ({
    variant?: "default" | "destructive" | "ghost" | "link" | "outline" | "secondary" | null | undefined;
    size?: "default" | "icon" | "icon-lg" | "icon-sm" | "icon-xs" | "lg" | "sm" | "xs" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type ButtonProps = React.ComponentProps<typeof BaseButton> & VariantProps<typeof buttonVariants>;
declare function Button({ className, variant, size, ...props }: ButtonProps): React.JSX.Element;
export { Button };
