import { t as cn } from "./chunks/utils-Cr_eCEw3.js";
import { i as CONTROL_HEIGHT_CLASSES } from "./chunks/control-sizes-CG-tSiWV.js";
import * as React from "react";
import { jsx } from "react/jsx-runtime";
import { ToggleGroup as ToggleGroup$1 } from "@base-ui/react/toggle-group";
//#region src/components/ui/toggle-group.tsx
var ToggleGroupContext = React.createContext(null);
var toggleGroupHeightClasses = {
	xs: CONTROL_HEIGHT_CLASSES.xs,
	sm: CONTROL_HEIGHT_CLASSES.sm,
	default: CONTROL_HEIGHT_CLASSES.default,
	lg: CONTROL_HEIGHT_CLASSES.lg,
	icon: CONTROL_HEIGHT_CLASSES.default,
	"icon-xs": CONTROL_HEIGHT_CLASSES.xs,
	"icon-sm": CONTROL_HEIGHT_CLASSES.sm,
	"icon-lg": CONTROL_HEIGHT_CLASSES.lg
};
function ToggleGroup({ className, variant, size, ...props }) {
	return /* @__PURE__ */ jsx(ToggleGroupContext.Provider, {
		value: {
			variant,
			size
		},
		children: /* @__PURE__ */ jsx(ToggleGroup$1, {
			"data-slot": "toggle-group",
			className: cn("flex items-center rounded-(--radius) border border-border", toggleGroupHeightClasses[size ?? "default"], variant === "segmented" && "gap-1 bg-background p-0.5", variant === "outline" && "[&>[data-slot=toggle]]:border-0", "data-[orientation=vertical]:flex-col data-[orientation=vertical]:h-auto", className),
			...props
		})
	});
}
//#endregion
export { ToggleGroup, ToggleGroupContext };
