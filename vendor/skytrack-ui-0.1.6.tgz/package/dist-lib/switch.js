import { t as cn } from "./chunks/utils-Cr_eCEw3.js";
import { t as focusRing } from "./chunks/focus-ring-BwICtWf4.js";
import * as React from "react";
import { jsx } from "react/jsx-runtime";
import { cva } from "class-variance-authority";
import { Switch as Switch$1 } from "@base-ui/react/switch";
//#region src/components/ui/switch.tsx
var switchVariants = cva(cn("inline-flex cursor-pointer shrink-0 items-center rounded-(--radius) border border-input bg-muted p-0.5 transition-colors", "data-checked:bg-primary data-checked:border-primary", "disabled:cursor-not-allowed disabled:opacity-50 data-disabled:cursor-not-allowed data-disabled:opacity-50", focusRing), {
	variants: { size: {
		default: "h-5 w-9",
		sm: "h-4 w-7"
	} },
	defaultVariants: { size: "default" }
});
var switchThumbVariants = cva("block bg-background shadow transition-transform", {
	variants: { size: {
		default: "size-3.5 data-checked:translate-x-4",
		sm: "size-3 data-unchecked:translate-x-[-0.8px] data-checked:translate-x-[calc(var(--spacing)*2.7)]"
	} },
	defaultVariants: { size: "default" }
});
var SwitchSizeContext = React.createContext("default");
function Switch({ className, size, children, ...props }) {
	return /* @__PURE__ */ jsx(SwitchSizeContext.Provider, {
		value: size ?? "default",
		children: /* @__PURE__ */ jsx(Switch$1.Root, {
			"data-slot": "switch",
			className: cn(switchVariants({ size }), className),
			...props,
			children: children ?? /* @__PURE__ */ jsx(SwitchThumb, {})
		})
	});
}
function SwitchThumb({ className, size, ...props }) {
	const inheritedSize = React.useContext(SwitchSizeContext);
	return /* @__PURE__ */ jsx(Switch$1.Thumb, {
		"data-slot": "switch-thumb",
		className: cn(switchThumbVariants({ size: size ?? inheritedSize }), className),
		...props
	});
}
//#endregion
export { Switch, SwitchThumb, switchThumbVariants, switchVariants };
