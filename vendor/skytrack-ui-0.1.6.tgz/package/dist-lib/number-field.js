import { t as cn } from "./chunks/utils-Cr_eCEw3.js";
import { t as focusRing } from "./chunks/focus-ring-BwICtWf4.js";
import { i as CONTROL_HEIGHT_CLASSES, n as CONTROL_FONT_SIZE_CLASSES, o as CONTROL_PADDING_X_CLASSES, t as CONTROL_CHILD_SVG_CLASSES } from "./chunks/control-sizes-BA6H39VF.js";
import * as React from "react";
import { CaretLeftIcon, CaretRightIcon } from "@phosphor-icons/react";
import { jsx } from "react/jsx-runtime";
import { NumberField as NumberField$1 } from "@base-ui/react/number-field";
//#region src/components/ui/number-field.tsx
var NumberFieldContext = React.createContext({ size: "default" });
function NumberField({ className, size, ...props }) {
	const contextValue = React.useMemo(() => size ? { size } : void 0, [size]);
	const root = /* @__PURE__ */ jsx(NumberField$1.Root, {
		"data-slot": "number-field",
		className: cn("flex flex-col items-start gap-1", className),
		...props
	});
	if (contextValue) return /* @__PURE__ */ jsx(NumberFieldContext.Provider, {
		value: contextValue,
		children: root
	});
	return root;
}
function NumberFieldGroup({ className, size, ...props }) {
	const rootContext = React.useContext(NumberFieldContext);
	const resolvedSize = size ?? rootContext.size ?? "default";
	const groupContextValue = React.useMemo(() => ({
		size: resolvedSize,
		grouped: true
	}), [resolvedSize]);
	return /* @__PURE__ */ jsx(NumberFieldContext.Provider, {
		value: groupContextValue,
		children: /* @__PURE__ */ jsx(NumberField$1.Group, {
			"data-slot": "number-field-group",
			"data-size": resolvedSize,
			className: cn("inline-flex items-stretch rounded-(--radius) border border-input bg-background shadow-xs transition-colors", "focus-within:border-ring focus-within:ring-[3px] focus-within:ring-ring/50", "has-[[data-invalid]]:border-destructive has-[[data-invalid]]:ring-destructive/20", "has-[[aria-invalid=true]]:border-destructive has-[[aria-invalid=true]]:ring-destructive/20", "has-[[data-disabled]]:cursor-not-allowed has-[[data-disabled]]:opacity-50", CONTROL_HEIGHT_CLASSES[resolvedSize], CONTROL_CHILD_SVG_CLASSES[resolvedSize], className),
			...props
		})
	});
}
function NumberFieldInput({ className, size, ...props }) {
	const context = React.useContext(NumberFieldContext);
	const resolvedSize = size ?? context.size ?? "default";
	return /* @__PURE__ */ jsx(NumberField$1.Input, {
		"data-slot": "number-field-input",
		"data-size": resolvedSize,
		className: cn("w-16 tabular-nums transition-colors", context.grouped ? "bg-transparent shadow-none rounded-none focus-visible:ring-0" : "border border-input bg-background rounded-(--radius)", CONTROL_HEIGHT_CLASSES[resolvedSize], CONTROL_FONT_SIZE_CLASSES[resolvedSize], CONTROL_PADDING_X_CLASSES[resolvedSize], "focus-visible:z-10", "placeholder:text-muted-foreground", "data-disabled:cursor-not-allowed data-disabled:opacity-50 data-readonly:bg-muted", "data-invalid:border-destructive", focusRing, className),
		...props
	});
}
var stepperClasses = cn("flex h-full aspect-square cursor-pointer shrink-0 items-center justify-center text-foreground transition-colors select-none", "hover:bg-accent hover:text-accent-foreground", "active:bg-secondary", "data-disabled:pointer-events-none data-disabled:opacity-50 data-readonly:bg-muted", focusRing);
function NumberFieldDecrement({ className, children, size, ...props }) {
	const context = React.useContext(NumberFieldContext);
	const resolvedSize = size ?? context.size ?? "default";
	return /* @__PURE__ */ jsx(NumberField$1.Decrement, {
		"data-slot": "number-field-decrement",
		"data-size": resolvedSize,
		className: cn(stepperClasses, context.grouped ? "border-0 border-e border-input bg-transparent focus-visible:ring-0" : "border border-input bg-background", CONTROL_CHILD_SVG_CLASSES[resolvedSize], "first:rounded-s-(--radius) focus-visible:z-10 focus-visible:border-e", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretLeftIcon, {})
	});
}
function NumberFieldIncrement({ className, children, size, ...props }) {
	const context = React.useContext(NumberFieldContext);
	const resolvedSize = size ?? context.size ?? "default";
	return /* @__PURE__ */ jsx(NumberField$1.Increment, {
		"data-slot": "number-field-increment",
		"data-size": resolvedSize,
		className: cn(stepperClasses, context.grouped ? "border-0 border-s border-input bg-transparent focus-visible:ring-0" : "border border-input bg-background", CONTROL_CHILD_SVG_CLASSES[resolvedSize], "last:rounded-e-(--radius) focus-visible:z-10 focus-visible:border-s", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretRightIcon, {})
	});
}
function NumberFieldScrubArea({ className, ...props }) {
	return /* @__PURE__ */ jsx(NumberField$1.ScrubArea, {
		"data-slot": "number-field-scrub-area",
		className: cn("group cursor-ew-resize select-none", "data-disabled:pointer-events-none data-disabled:opacity-50", className),
		...props
	});
}
function NumberFieldScrubAreaCursor({ className, ...props }) {
	return /* @__PURE__ */ jsx(NumberField$1.ScrubAreaCursor, {
		"data-slot": "number-field-scrub-area-cursor",
		className: cn("pointer-events-none flex items-center opacity-0 transition-opacity data-scrubbing:opacity-100", className),
		...props
	});
}
//#endregion
export { NumberField, NumberFieldDecrement, NumberFieldGroup, NumberFieldIncrement, NumberFieldInput, NumberFieldScrubArea, NumberFieldScrubAreaCursor };
