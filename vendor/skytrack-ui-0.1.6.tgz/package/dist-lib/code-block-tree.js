import { t as cn } from "./chunks/utils-Cr_eCEw3.js";
import { Alert, AlertDescription } from "./alert.js";
import { CodeBlock, CodeBlockActions, CodeBlockContent, CodeBlockCopyButton, CodeBlockHeader, CodeBlockLine, CodeBlockLineNumbersToggle, CodeBlockTitle, useHighlightedCode } from "./code-block.js";
import { ScrollArea, ScrollAreaContent, ScrollAreaScrollbar, ScrollAreaThumb, ScrollAreaViewport } from "./scroll-area.js";
import * as React from "react";
import { CaretDownIcon, CaretRightIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/components/ui/code-block-tree.tsx
function getNodeKind(value) {
	if (value === null) return "null";
	if (Array.isArray(value)) return "array";
	if (typeof value === "object") return "object";
	if (typeof value === "string") return "string";
	if (typeof value === "number") return "number";
	if (typeof value === "boolean") return "boolean";
	return "null";
}
function parseJsonValue(value) {
	if (value === void 0) return {
		source: "",
		text: "",
		value: void 0,
		error: false,
		empty: true
	};
	let source;
	try {
		source = (typeof value === "string" ? value : JSON.stringify(value, null, 2)) ?? "";
	} catch {
		return {
			source: "[Unable to serialize JSON value]",
			text: "[Unable to serialize JSON value]",
			value: void 0,
			error: true,
			empty: false
		};
	}
	if (source.trim() === "") return {
		source,
		text: "",
		value: void 0,
		error: false,
		empty: true
	};
	try {
		const parsed = JSON.parse(source);
		return {
			source,
			text: JSON.stringify(parsed, null, 2),
			value: parsed,
			error: false,
			empty: false
		};
	} catch {
		return {
			source,
			text: source,
			value: void 0,
			error: true,
			empty: false
		};
	}
}
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function entriesFor(value) {
	if (Array.isArray(value)) return value.map((entry, index) => ({
		label: index,
		value: entry,
		isArrayItem: true
	}));
	if (isRecord(value)) return Object.keys(value).map((key) => ({
		label: key,
		value: value[key],
		isArrayItem: false
	}));
	return [];
}
function childPath(parentPath, label, isArrayItem) {
	return `${parentPath}/${isArrayItem ? `i:${label}` : `p:${encodeURIComponent(String(label))}`}`;
}
function buildTree(value) {
	let nextLine = 1;
	const build = (current, label, path, parentPath, depth, hasNext) => {
		const entries = entriesFor(current);
		const expandable = entries.length > 0;
		const startLine = nextLine++;
		const children = expandable ? entries.map((entry, index) => build(entry.value, entry.label, childPath(path, entry.label, entry.isArrayItem), path, depth + 1, index < entries.length - 1)) : [];
		return {
			path,
			parentPath,
			label,
			value: current,
			depth,
			startLine,
			endLine: expandable ? nextLine++ : startLine,
			children,
			expandable,
			isArray: Array.isArray(current),
			hasNext,
			kind: getNodeKind(current)
		};
	};
	return build(value, null, "$", void 0, 0, false);
}
function collectExpandablePaths(root) {
	const paths = /* @__PURE__ */ new Set();
	const visit = (node) => {
		if (node.expandable) paths.add(node.path);
		node.children.forEach(visit);
	};
	visit(root);
	return paths;
}
function collectVisibleLines(root, isExpanded, sourceLines) {
	const result = [];
	const appendNode = (node) => {
		if (!node.expandable) {
			const text = (sourceLines[node.startLine - 1] ?? "").trimStart();
			result.push({
				lineNumber: node.startLine,
				text
			});
			return;
		}
		if (!isExpanded(node)) {
			result.push({
				lineNumber: node.startLine,
				text: collapsedLine(node)
			});
			return;
		}
		const startText = (sourceLines[node.startLine - 1] ?? "").trimStart();
		result.push({
			lineNumber: node.startLine,
			text: startText
		});
		node.children.forEach(appendNode);
		const endText = (sourceLines[node.endLine - 1] ?? "").trimStart();
		result.push({
			lineNumber: node.endLine,
			text: endText
		});
	};
	if (root.expandable) {
		const startText = (sourceLines[root.startLine - 1] ?? "").trimStart();
		result.push({
			lineNumber: root.startLine,
			text: startText
		});
		root.children.forEach(appendNode);
		const endText = (sourceLines[root.endLine - 1] ?? "").trimStart();
		result.push({
			lineNumber: root.endLine,
			text: endText
		});
	} else {
		const text = (sourceLines[root.startLine - 1] ?? "").trimStart();
		result.push({
			lineNumber: root.startLine,
			text
		});
	}
	return result;
}
function collapsedLine(node) {
	return `${node.label === null || typeof node.label === "number" ? "" : `${JSON.stringify(node.label)}: `}${node.isArray ? "[ … ]" : "{ … }"}${node.hasNext ? "," : ""}`;
}
function CodeBlockTree({ value, title = "JSON", lineNumbers: controlledLineNumbers, defaultLineNumbers = true, defaultExpandAll = false, showLineNumbersToggle = true, onLineNumbersChange, toolbarActions, renderNode: renderNodeProp, className, style, ...props }) {
	const parsed = React.useMemo(() => parseJsonValue(value), [value]);
	const sourceLines = React.useMemo(() => parsed.text.split(/\r?\n/), [parsed.text]);
	const root = React.useMemo(() => parsed.error || parsed.empty ? null : buildTree(parsed.value), [parsed]);
	const [expandedPaths, setExpandedPaths] = React.useState(() => defaultExpandAll && root ? collectExpandablePaths(root) : /* @__PURE__ */ new Set());
	const [internalLineNumbers, setInternalLineNumbers] = React.useState(defaultLineNumbers);
	const isLineNumbersControlled = controlledLineNumbers !== void 0;
	const lineNumbers = isLineNumbersControlled ? controlledLineNumbers : internalLineNumbers;
	const treeId = React.useId().replaceAll(":", "");
	const isExpanded = React.useCallback((node) => expandedPaths.has(node.path), [expandedPaths]);
	const visibleLines = React.useMemo(() => root ? collectVisibleLines(root, isExpanded, sourceLines) : [], [
		isExpanded,
		root,
		sourceLines
	]);
	const codeToHighlight = React.useMemo(() => {
		if (parsed.error) return parsed.text;
		return visibleLines.map((line) => line.text).join("\n");
	}, [
		parsed.error,
		parsed.text,
		visibleLines
	]);
	const highlightedLines = useHighlightedCode(codeToHighlight, "json");
	const highlightedByLine = React.useMemo(() => new Map(visibleLines.map((line, index) => [line.lineNumber, highlightedLines[index] ?? line.text])), [highlightedLines, visibleLines]);
	const toggleNode = (node) => {
		setExpandedPaths((current) => {
			const next = new Set(current);
			if (next.has(node.path)) next.delete(node.path);
			else next.add(node.path);
			return next;
		});
	};
	const handleLineNumbersChange = (enabled) => {
		if (!isLineNumbersControlled) setInternalLineNumbers(enabled);
		onLineNumbersChange?.(enabled);
	};
	const lineNumberFor = (line) => lineNumbers ? line : "";
	const gutterLineClassName = "min-w-max px-2 [&_[data-slot=code-block-line-number]]:pr-8";
	const lineId = (line) => `${treeId}-line-${line}`;
	const groupId = (path) => `${treeId}-group-${encodeURIComponent(path)}`;
	const lastLineNumber = root ? root.endLine : sourceLines.length || 1;
	const digitsCount = Math.max(2, String(lastLineNumber).length);
	const gutterWidth = lineNumbers ? `calc(${digitsCount}ch + 2.75rem)` : "2.75rem";
	const renderNode = (node) => {
		const expanded = isExpanded(node);
		const defaultStartText = highlightedByLine.get(node.startLine) ?? (node.expandable && !expanded ? collapsedLine(node) : sourceLines[node.startLine - 1]?.trimStart() ?? "");
		const context = {
			key: node.label,
			label: node.label,
			value: node.value,
			path: node.path,
			depth: node.depth,
			kind: node.kind,
			nodeKind: node.kind,
			expandable: node.expandable,
			expanded,
			defaultContent: defaultStartText,
			defaultHighlightedContent: defaultStartText
		};
		const customContent = renderNodeProp ? renderNodeProp(context) : void 0;
		const displayContent = customContent !== void 0 ? customContent : defaultStartText;
		if (!node.expandable) return /* @__PURE__ */ jsx("li", {
			className: "m-0 list-none p-0",
			children: /* @__PURE__ */ jsx(CodeBlockLine, {
				id: lineId(node.startLine),
				lineNumber: lineNumberFor(node.startLine),
				variant: "default",
				className: gutterLineClassName,
				children: /* @__PURE__ */ jsx("span", {
					className: "inline-flex items-center min-w-0",
					style: { paddingLeft: `${node.depth * 2}ch` },
					children: /* @__PURE__ */ jsx("span", {
						className: "min-w-0",
						children: displayContent
					})
				})
			})
		}, node.path);
		const childGroupId = groupId(node.path);
		const closingContent = highlightedByLine.get(node.endLine) ?? sourceLines[node.endLine - 1]?.trimStart() ?? (node.isArray ? "]" : "}");
		return /* @__PURE__ */ jsxs("li", {
			className: "m-0 list-none p-0",
			children: [/* @__PURE__ */ jsxs(CodeBlockLine, {
				id: lineId(node.startLine),
				lineNumber: lineNumberFor(node.startLine),
				variant: "default",
				className: cn("relative", gutterLineClassName),
				children: [/* @__PURE__ */ jsx("button", {
					type: "button",
					"aria-label": `${expanded ? "Collapse" : "Expand"} ${node.label === null ? "root JSON" : String(node.label)}`,
					"aria-expanded": expanded,
					"aria-controls": expanded ? childGroupId : void 0,
					onClick: () => toggleNode(node),
					className: "absolute top-1/2 z-2 inline-flex size-4 -translate-y-1/2 items-center justify-center rounded-xs border-0 bg-transparent p-0 text-muted-foreground hover:text-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring",
					style: { left: "calc(var(--code-block-gutter-width) - 1.25rem)" },
					children: expanded ? /* @__PURE__ */ jsx(CaretDownIcon, {
						className: "size-3.5",
						"aria-hidden": "true"
					}) : /* @__PURE__ */ jsx(CaretRightIcon, {
						className: "size-3.5",
						"aria-hidden": "true"
					})
				}), /* @__PURE__ */ jsx("span", {
					className: "inline-flex items-center min-w-0",
					style: { paddingLeft: `${node.depth * 2}ch` },
					children: /* @__PURE__ */ jsx("span", {
						className: "min-w-0",
						children: displayContent
					})
				})]
			}), expanded ? /* @__PURE__ */ jsxs("ul", {
				id: childGroupId,
				role: "group",
				className: "m-0 flex min-w-max list-none flex-col gap-0 p-0",
				children: [node.children.map(renderNode), /* @__PURE__ */ jsx("li", {
					className: "m-0 list-none p-0",
					children: /* @__PURE__ */ jsx(CodeBlockLine, {
						id: lineId(node.endLine),
						lineNumber: lineNumberFor(node.endLine),
						variant: "default",
						className: gutterLineClassName,
						children: /* @__PURE__ */ jsx("span", {
							className: "inline-flex items-center min-w-0",
							style: { paddingLeft: `${node.depth * 2}ch` },
							children: /* @__PURE__ */ jsx("span", {
								className: "min-w-0 font-mono",
								children: closingContent
							})
						})
					})
				})]
			}) : null]
		}, node.path);
	};
	const rootStartContent = highlightedByLine.get(root?.startLine ?? 1) ?? sourceLines[0]?.trimStart() ?? "{";
	const rootContext = root ? {
		key: null,
		label: null,
		value: root.value,
		path: root.path,
		depth: 0,
		kind: root.kind,
		nodeKind: root.kind,
		expandable: root.expandable,
		expanded: true,
		defaultContent: rootStartContent,
		defaultHighlightedContent: rootStartContent
	} : null;
	const rootCustom = rootContext && renderNodeProp ? renderNodeProp(rootContext) : void 0;
	const rootStartDisplay = rootCustom !== void 0 ? rootCustom : rootStartContent;
	return /* @__PURE__ */ jsxs(CodeBlock, {
		...props,
		style: {
			"--code-block-gutter-width": gutterWidth,
			...style
		},
		className: cn("min-w-0", className),
		size: "sm",
		lineNumbers,
		onLineNumbersChange: handleLineNumbersChange,
		children: [/* @__PURE__ */ jsxs(CodeBlockHeader, { children: [/* @__PURE__ */ jsx(CodeBlockTitle, { children: title }), /* @__PURE__ */ jsxs(CodeBlockActions, { children: [
			showLineNumbersToggle ? /* @__PURE__ */ jsx(CodeBlockLineNumbersToggle, {}) : null,
			toolbarActions,
			/* @__PURE__ */ jsx(CodeBlockCopyButton, { value: parsed.error ? parsed.source : parsed.text })
		] })] }), parsed.error ? /* @__PURE__ */ jsxs("div", {
			className: "flex min-w-0 flex-col gap-2 p-3",
			children: [/* @__PURE__ */ jsx(Alert, {
				variant: "destructive",
				role: "alert",
				children: /* @__PURE__ */ jsx(AlertDescription, { children: "Invalid JSON. Showing the original text." })
			}), /* @__PURE__ */ jsx(CodeBlockContent, {
				className: "max-h-[34rem]",
				children: highlightedLines.map((line, index) => /* @__PURE__ */ jsx(CodeBlockLine, { children: line }, index))
			})]
		}) : parsed.empty ? /* @__PURE__ */ jsx("p", {
			className: "m-0 p-3 text-sm text-muted-foreground",
			role: "status",
			children: "No JSON value supplied."
		}) : /* @__PURE__ */ jsxs(ScrollArea, {
			className: "h-[34rem] min-w-0",
			children: [
				/* @__PURE__ */ jsx(ScrollAreaViewport, { children: /* @__PURE__ */ jsx(ScrollAreaContent, {
					className: "min-w-max gap-0 p-0 font-mono text-xs leading-5 whitespace-pre",
					children: root?.expandable ? /* @__PURE__ */ jsxs("div", {
						role: "group",
						"aria-label": "JSON tree",
						children: [
							/* @__PURE__ */ jsx(CodeBlockLine, {
								id: lineId(root.startLine),
								lineNumber: lineNumberFor(root.startLine),
								variant: "default",
								className: gutterLineClassName,
								children: /* @__PURE__ */ jsx("span", {
									className: "inline-flex items-center min-w-0",
									children: /* @__PURE__ */ jsx("span", {
										className: "min-w-0 font-mono",
										children: rootStartDisplay
									})
								})
							}),
							/* @__PURE__ */ jsx("ul", {
								className: "m-0 flex min-w-max list-none flex-col gap-0 p-0",
								children: root.children.map(renderNode)
							}),
							/* @__PURE__ */ jsx(CodeBlockLine, {
								id: lineId(root.endLine),
								lineNumber: lineNumberFor(root.endLine),
								variant: "default",
								className: gutterLineClassName,
								children: /* @__PURE__ */ jsx("span", {
									className: "inline-flex items-center min-w-0",
									children: /* @__PURE__ */ jsx("span", {
										className: "min-w-0 font-mono",
										children: highlightedByLine.get(root.endLine) ?? sourceLines[root.endLine - 1]?.trimStart() ?? "}"
									})
								})
							})
						]
					}) : /* @__PURE__ */ jsx(CodeBlockLine, {
						id: lineId(root?.startLine ?? 1),
						lineNumber: lineNumberFor(root?.startLine ?? 1),
						variant: "default",
						className: gutterLineClassName,
						children: /* @__PURE__ */ jsx("span", {
							className: "inline-flex items-center min-w-0",
							children: /* @__PURE__ */ jsx("span", {
								className: "min-w-0 font-mono",
								children: rootStartDisplay
							})
						})
					})
				}) }),
				/* @__PURE__ */ jsx(ScrollAreaScrollbar, { children: /* @__PURE__ */ jsx(ScrollAreaThumb, {}) }),
				/* @__PURE__ */ jsx(ScrollAreaScrollbar, {
					orientation: "horizontal",
					children: /* @__PURE__ */ jsx(ScrollAreaThumb, {})
				})
			]
		})]
	});
}
//#endregion
export { CodeBlockTree };
