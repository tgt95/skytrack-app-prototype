import { t as cn } from "./chunks/utils-Cr_eCEw3.js";
import { t as Button } from "./chunks/button-CbGRqxEO.js";
import * as React from "react";
import { CheckIcon, CopySimpleIcon, ListNumbersIcon } from "@phosphor-icons/react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { cva } from "class-variance-authority";
//#region src/components/ui/code-block.tsx
var codeBlockLineHeight = {
	default: "leading-6",
	sm: "leading-5",
	xs: "leading-4"
};
var CodeBlockContext = React.createContext({
	size: "default",
	floatingActions: false,
	lineNumbers: false,
	startLine: 1
});
var codeBlockVariants = cva("group/code-block isolate relative flex min-w-0 flex-col overflow-hidden rounded-(--radius) border text-card-foreground", {
	variants: { variant: {
		default: "border-border bg-card",
		destructive: "border-destructive/50 bg-destructive/5"
	} },
	defaultVariants: { variant: "default" }
});
function CodeBlock({ className, size = "default", variant = "default", lineNumbers: controlledLineNumbers, lineIndex: controlledLineIndex, showLineNumbers: controlledShowLineNumbers, defaultLineNumbers, defaultLineIndex, startLine, startLineIndex, onLineNumbersChange, children, ...props }) {
	const resolvedSize = size ?? "default";
	const resolvedVariant = variant ?? "default";
	const explicitLineNumbers = controlledLineNumbers ?? controlledLineIndex ?? controlledShowLineNumbers;
	const isControlled = explicitLineNumbers !== void 0;
	const initialLineNumbers = defaultLineNumbers ?? defaultLineIndex ?? false;
	const [internalLineNumbers, setInternalLineNumbers] = React.useState(initialLineNumbers);
	const lineNumbers = isControlled ? explicitLineNumbers : internalLineNumbers;
	const toggleLineNumbers = React.useCallback(() => {
		const next = !lineNumbers;
		if (!isControlled) setInternalLineNumbers(next);
		onLineNumbersChange?.(next);
	}, [
		lineNumbers,
		isControlled,
		onLineNumbersChange
	]);
	const resolvedStartLine = startLine ?? startLineIndex ?? 1;
	const floatingActions = !React.Children.toArray(children).some((child) => React.isValidElement(child) && child.type === CodeBlockHeader);
	const context = React.useMemo(() => ({
		size: resolvedSize,
		floatingActions,
		lineNumbers,
		startLine: resolvedStartLine,
		toggleLineNumbers
	}), [
		resolvedSize,
		floatingActions,
		lineNumbers,
		resolvedStartLine,
		toggleLineNumbers
	]);
	return /* @__PURE__ */ jsx(CodeBlockContext.Provider, {
		value: context,
		children: /* @__PURE__ */ jsx("div", {
			"data-slot": "code-block",
			"data-size": resolvedSize,
			"data-variant": resolvedVariant,
			"data-line-numbers": lineNumbers ? "true" : "false",
			className: cn(codeBlockVariants({ variant: resolvedVariant }), className),
			...props,
			children
		})
	});
}
function CodeBlockHeader({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "code-block-header",
		className: cn("flex min-w-0 items-center gap-2 border-b border-border bg-muted/20 px-3 py-2", className),
		...props
	});
}
function CodeBlockTitle({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "code-block-title",
		className: cn("min-w-0 flex-1 truncate font-medium text-foreground", className),
		...props
	});
}
function CodeBlockActions({ className, ...props }) {
	const { floatingActions } = React.useContext(CodeBlockContext);
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "code-block-actions",
		"data-floating": floatingActions ? "true" : void 0,
		className: cn(floatingActions ? "absolute right-2 top-2 z-10 flex items-center gap-1" : "ml-auto flex shrink-0 items-center gap-1", className),
		...props
	});
}
function CodeBlockCopyButton({ value, className, onClick, copyLabel = "Copy", copiedLabel = "Copied", copyFailedLabel = "Copy failed", variant = "ghost", size = "icon-sm", ...props }) {
	const [copyState, setCopyState] = React.useState("idle");
	const resetTimer = React.useRef(null);
	const statusLabel = copyState === "copied" ? copiedLabel : copyState === "error" ? copyFailedLabel : copyLabel;
	React.useEffect(() => () => {
		if (resetTimer.current) clearTimeout(resetTimer.current);
	}, []);
	const handleClick = async (event) => {
		onClick?.(event);
		if (event.defaultPrevented) return;
		if (resetTimer.current) clearTimeout(resetTimer.current);
		try {
			if (!navigator.clipboard?.writeText) throw new Error("Clipboard API is unavailable");
			await navigator.clipboard.writeText(value);
			setCopyState("copied");
		} catch {
			setCopyState("error");
		}
		resetTimer.current = setTimeout(() => setCopyState("idle"), 1800);
	};
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(Button, {
		type: "button",
		variant,
		size,
		"aria-label": statusLabel,
		className,
		onClick: handleClick,
		...props,
		children: copyState === "copied" ? /* @__PURE__ */ jsx(CheckIcon, { "aria-hidden": "true" }) : /* @__PURE__ */ jsx(CopySimpleIcon, { "aria-hidden": "true" })
	}), /* @__PURE__ */ jsx("span", {
		className: "sr-only",
		role: "status",
		"aria-live": "polite",
		"aria-atomic": "true",
		children: statusLabel
	})] });
}
function CodeBlockContent({ children, language, wrap = false, lineNumbers: propLineNumbers, lineIndex: propLineIndex, showLineNumbers: propShowLineNumbers, startLine: propStartLine, startLineIndex: propStartLineIndex, tabIndex = 0, style, className, ...props }) {
	const context = React.useContext(CodeBlockContext);
	const size = context.size;
	const floatingActions = context.floatingActions;
	const highlightedLines = useHighlightedCode(typeof children === "string" ? children : "", typeof children === "string" ? language ?? "" : "");
	const resolvedChildren = language && typeof children === "string" ? highlightedLines.map((line, index) => /* @__PURE__ */ jsx(CodeBlockLine, { children: line }, index)) : children;
	const lineNumbers = propLineNumbers ?? propLineIndex ?? propShowLineNumbers ?? context.lineNumbers ?? false;
	const rawStartLine = propStartLine ?? propStartLineIndex ?? context.startLine ?? 1;
	const validStartLine = Number.isFinite(rawStartLine) && rawStartLine > 0 ? Math.floor(rawStartLine) : 1;
	const childLines = typeof resolvedChildren === "string" ? resolvedChildren.split("\n") : React.Children.toArray(resolvedChildren);
	const lastLineNumber = validStartLine + Math.max(0, childLines.length - 1);
	const gutterWidth = `calc(${Math.max(2, String(lastLineNumber).length)}ch + ${size === "sm" ? "1.5rem" : size === "xs" ? "1.25rem" : "1.75rem"})`;
	const contentStyle = {
		...style,
		...lineNumbers ? { "--code-block-gutter-width": gutterWidth } : {}
	};
	const content = lineNumbers ? childLines.map((line, index) => {
		const lineNumber = String(validStartLine + index);
		if (React.isValidElement(line) && line.type === CodeBlockLine) return React.cloneElement(line, {
			lineNumber,
			"data-line-number": lineNumber
		});
		return /* @__PURE__ */ jsx(CodeBlockLine, {
			lineNumber,
			"data-line-number": lineNumber,
			children: typeof line === "string" && line.length === 0 ? "\xA0" : line
		}, index);
	}) : resolvedChildren;
	return /* @__PURE__ */ jsx("pre", {
		...props,
		"data-slot": "code-block-content",
		"data-line-numbers": lineNumbers ? "true" : "false",
		dir: "ltr",
		tabIndex,
		style: contentStyle,
		className: cn("m-0 min-w-0 max-w-full overflow-x-auto font-mono text-foreground outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:ring-inset", lineNumbers ? size === "sm" ? "py-2 pr-2 pl-0 text-sm" : size === "xs" ? "py-1 pr-1 pl-0 text-xs" : "py-3 pr-3 pl-0" : size === "sm" ? "p-2 text-sm" : size === "xs" ? "p-1 text-xs" : "p-3", codeBlockLineHeight[size], floatingActions && "pt-10", className),
		children: /* @__PURE__ */ jsx("code", {
			className: cn("block min-w-full", wrap ? "whitespace-pre-wrap break-words" : "whitespace-pre"),
			children: content
		})
	});
}
function CodeBlockLine({ variant = "default", lineNumber, className, children, ...props }) {
	const { size } = React.useContext(CodeBlockContext);
	const resolvedLineNumber = lineNumber ?? props["data-line-number"];
	const hasLineNumber = resolvedLineNumber !== void 0;
	const marker = variant === "added" ? "+" : variant === "removed" ? "−" : null;
	return /* @__PURE__ */ jsxs("span", {
		"data-slot": "code-block-line",
		"data-variant": variant,
		"data-line-number": resolvedLineNumber,
		className: cn("flex min-w-full", codeBlockLineHeight[size], variant === "added" && "bg-success/10", variant === "removed" && "bg-destructive/10", variant === "highlighted" && "bg-primary/10", className),
		...props,
		children: [hasLineNumber && /* @__PURE__ */ jsx("span", {
			"aria-hidden": "true",
			"data-slot": "code-block-line-number",
			className: cn("sticky left-0 z-1 inline-flex shrink-0 select-none justify-end border-r border-border font-mono text-muted-foreground/60 transition-colors", "bg-card pr-3.5 pl-3", size === "sm" && "pr-2.5 pl-2 text-xs", size === "xs" && "pr-2 pl-1.5 text-[11px]", variant === "added" && "bg-success/15 text-success", variant === "removed" && "bg-destructive/15 text-destructive", variant === "highlighted" && "bg-primary/15 text-primary"),
			style: { width: "var(--code-block-gutter-width, 3.5rem)" },
			children: resolvedLineNumber
		}), /* @__PURE__ */ jsxs("span", {
			"data-slot": "code-block-line-content",
			className: cn("flex-1 min-w-0", hasLineNumber ? size === "sm" ? "pl-2.5" : size === "xs" ? "pl-2" : "pl-3.5" : "", "inline-block"),
			children: [marker && /* @__PURE__ */ jsx("span", {
				className: "mr-3 inline-block w-3 select-none text-muted-foreground",
				children: marker
			}), children]
		})]
	});
}
function CodeBlockLineNumbersToggle({ className, variant = "ghost", size = "icon-sm", pressedLabel = "Hide line numbers", unpressedLabel = "Show line numbers", onClick, ...props }) {
	const { lineNumbers, toggleLineNumbers } = React.useContext(CodeBlockContext);
	const label = lineNumbers ? pressedLabel : unpressedLabel;
	const handleClick = (event) => {
		onClick?.(event);
		if (event.defaultPrevented) return;
		toggleLineNumbers?.();
	};
	return /* @__PURE__ */ jsx(Button, {
		type: "button",
		variant,
		size,
		"aria-label": label,
		"aria-pressed": lineNumbers,
		title: label,
		className: cn(lineNumbers && "bg-accent text-accent-foreground", className),
		onClick: handleClick,
		...props,
		children: /* @__PURE__ */ jsx(ListNumbersIcon, { "aria-hidden": "true" })
	});
}
var CodeBlockLineIndexToggle = CodeBlockLineNumbersToggle;
function CodeBlockFooter({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "code-block-footer",
		className: cn("flex items-center gap-2 border-t border-border px-3 py-2", className),
		...props
	});
}
function useHighlightedCode(code, language) {
	const plainLines = React.useMemo(() => {
		return (code.endsWith("\n") ? code.slice(0, -1) : code).split("\n");
	}, [code]);
	const [lines, setLines] = React.useState(plainLines);
	React.useEffect(() => {
		let active = true;
		setLines(plainLines);
		if (!language || language === "text" || language === "txt") return () => {
			active = false;
		};
		import("shiki").then(({ codeToTokensWithThemes }) => codeToTokensWithThemes(code.endsWith("\n") ? code.slice(0, -1) : code, {
			lang: language,
			themes: {
				light: "light-plus",
				dark: "dark-plus"
			}
		})).then((tokens) => {
			if (!active) return;
			setLines(tokens.map((tokenLine, lineIndex) => /* @__PURE__ */ jsx(React.Fragment, { children: tokenLine.some((token) => token.content.length > 0) ? tokenLine.map((token, index) => {
				const style = {
					"--shiki-light": token.variants.light?.color ?? "inherit",
					"--shiki-dark": token.variants.dark?.color ?? "inherit"
				};
				return /* @__PURE__ */ jsx("span", {
					className: "text-[var(--shiki-light)] dark:text-[var(--shiki-dark)]",
					style,
					children: token.content
				}, index);
			}) : "\xA0" }, lineIndex)));
		}).catch(() => {
			if (active) setLines(plainLines);
		});
		return () => {
			active = false;
		};
	}, [
		code,
		language,
		plainLines
	]);
	return lines;
}
//#endregion
export { CodeBlock, CodeBlockActions, CodeBlockContent, CodeBlockCopyButton, CodeBlockFooter, CodeBlockHeader, CodeBlockLine, CodeBlockLineIndexToggle, CodeBlockLineNumbersToggle, CodeBlockTitle, useHighlightedCode };
