import { t as Button } from "./chunks/button-D0Q6JLgL.js";
import { CheckboxRoot } from "./checkbox.js";
import { Popover, PopoverPopup, PopoverPortal, PopoverPositioner, PopoverTrigger } from "./popover.js";
import { SplitButton } from "./split-button.js";
import "react";
import { XIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/components/ui/filter-button.tsx
/**
* Opens a multi-select filter popup from a styled Button trigger.
* The trigger renders the caller's `children` through the Popover trigger
* render slot, so popup state stays owned by `skytrack-ui/popover` and no
* button is nested inside another. When values are selected, a SplitButton-style
* X segment clears this filter's values.
*/
function FilterButton({ title, clearLabel, value, onValueChange, options, variant = "outline", size = "default", children, className, disabled, ...props }) {
	const toggleOption = (optionValue, checked) => {
		onValueChange(checked ? [...value, optionValue] : value.filter((current) => current !== optionValue));
	};
	const trigger = /* @__PURE__ */ jsx(PopoverTrigger, {
		render: /* @__PURE__ */ jsx(Button, {
			type: "button",
			variant,
			size,
			"data-split-button-part": "action"
		}),
		className,
		disabled,
		...props,
		children
	});
	return /* @__PURE__ */ jsxs(Popover, { children: [value.length > 0 ? /* @__PURE__ */ jsxs(SplitButton, {
		variant,
		size,
		disabled,
		role: "group",
		"aria-label": title,
		children: [trigger, /* @__PURE__ */ jsx(Button, {
			type: "button",
			variant,
			size: {
				xs: "icon-xs",
				sm: "icon-sm",
				default: "icon",
				lg: "icon-lg"
			}[size],
			disabled,
			"data-split-button-part": "trigger",
			"aria-label": clearLabel ?? `Clear ${title}`,
			title: clearLabel ?? `Clear ${title}`,
			onClick: () => onValueChange([]),
			children: /* @__PURE__ */ jsx(XIcon, { "aria-hidden": "true" })
		})]
	}) : trigger, /* @__PURE__ */ jsx(PopoverPortal, { children: /* @__PURE__ */ jsx(PopoverPositioner, {
		side: "bottom",
		align: "start",
		sideOffset: 4,
		children: /* @__PURE__ */ jsxs(PopoverPopup, {
			className: "min-w-64 p-2",
			children: [/* @__PURE__ */ jsx("div", {
				className: "text-xs sub-heading px-2 pt-1 pb-1",
				children: title
			}), /* @__PURE__ */ jsx("div", {
				className: "flex flex-col gap-0.5",
				children: options.map((option) => {
					const checked = value.includes(option.value);
					return /* @__PURE__ */ jsxs("label", {
						className: "flex cursor-pointer select-none items-center gap-2 rounded-(--radius) px-2 py-1.5 hover:bg-accent",
						children: [/* @__PURE__ */ jsx(CheckboxRoot, {
							checked,
							disabled: option.disabled,
							onCheckedChange: (nextChecked) => toggleOption(option.value, nextChecked === true)
						}), /* @__PURE__ */ jsx("span", {
							className: "min-w-0 text-sm",
							children: option.label
						})]
					}, option.value);
				})
			})]
		})
	}) })] });
}
//#endregion
export { FilterButton };
