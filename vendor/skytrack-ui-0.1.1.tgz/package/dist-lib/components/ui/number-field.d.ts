import * as React from 'react';
import { NumberField as BaseNumberField } from '@base-ui/react/number-field';
declare function NumberField({ className, ...props }: React.ComponentProps<typeof BaseNumberField.Root>): React.JSX.Element;
declare function NumberFieldGroup({ className, ...props }: React.ComponentProps<typeof BaseNumberField.Group>): React.JSX.Element;
type NumberFieldInputProps = Omit<React.ComponentProps<typeof BaseNumberField.Input>, 'size'> & {
    size?: 'default' | 'compact';
};
declare function NumberFieldInput({ className, size, ...props }: NumberFieldInputProps): React.JSX.Element;
declare function NumberFieldDecrement({ className, children, ...props }: React.ComponentProps<typeof BaseNumberField.Decrement>): React.JSX.Element;
declare function NumberFieldIncrement({ className, children, ...props }: React.ComponentProps<typeof BaseNumberField.Increment>): React.JSX.Element;
declare function NumberFieldScrubArea({ className, ...props }: React.ComponentProps<typeof BaseNumberField.ScrubArea>): React.JSX.Element;
declare function NumberFieldScrubAreaCursor({ className, ...props }: React.ComponentProps<typeof BaseNumberField.ScrubAreaCursor>): React.JSX.Element;
export { NumberField, NumberFieldGroup, NumberFieldInput, NumberFieldDecrement, NumberFieldIncrement, NumberFieldScrubArea, NumberFieldScrubAreaCursor };
