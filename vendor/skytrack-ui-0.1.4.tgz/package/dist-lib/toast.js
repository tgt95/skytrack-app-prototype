import { t as cn } from "./chunks/utils-QluraT_M.js";
import { focusRing } from "./button.js";
import "react";
import { X } from "@phosphor-icons/react";
import { cva } from "class-variance-authority";
import { jsx } from "react/jsx-runtime";
import { Toast } from "@base-ui/react/toast";
//#region src/components/ui/toast.tsx
/** Renders no element of its own; only provides the toast manager context. */
function ToastProvider(props) {
	return /* @__PURE__ */ jsx(Toast.Provider, { ...props });
}
var toastRootVariants = cva(cn("w-full cursor-pointer rounded-md border bg-popover text-popover-foreground shadow-md select-none", "origin-bottom", "[--gap:0.5rem] [--peek:0.5rem]", "[--scale:calc(max(0,1-(var(--toast-index)*0.1)))]", "[--shrink:calc(1-var(--scale))]", "[--height:var(--toast-frontmost-height,var(--toast-height))]", "absolute right-0 bottom-0 left-auto z-[calc(1000-var(--toast-index))]", "h-[var(--height)]", "[transform:translateX(var(--toast-swipe-movement-x))_translateY(calc(var(--toast-swipe-movement-y)-(var(--toast-index)*var(--peek))-(var(--shrink)*var(--height))))_scale(var(--scale))]", "transition-[transform,opacity,height] duration-300 ease-out", "data-[expanded]:h-[var(--toast-height)]", "data-[expanded]:[transform:translateX(var(--toast-swipe-movement-x))_translateY(calc(var(--toast-offset-y)*-1-var(--toast-index)*var(--gap)+var(--toast-swipe-movement-y)))]", "data-[limited]:opacity-0", "data-[starting-style]:translate-y-[150%]", "data-[ending-style]:opacity-0", "data-[ending-style]:data-[swipe-direction=up]:[transform:translateY(calc(var(--toast-swipe-movement-y)-150%))]", "data-[ending-style]:data-[swipe-direction=down]:[transform:translateY(calc(var(--toast-swipe-movement-y)+150%))]", "data-[ending-style]:data-[swipe-direction=left]:[transform:translateX(calc(var(--toast-swipe-movement-x)-150%))]", "data-[ending-style]:data-[swipe-direction=right]:[transform:translateX(calc(var(--toast-swipe-movement-x)+150%))]", "data-[swiping]:transition-none", "data-[type=success]:border-success", "data-[type=error]:border-destructive", "data-[type=warning]:border-warning", "data-[type=loading]:border-border", focusRing), {
	variants: { 
	/** `stacked` collapses the stack behind the frontmost toast; `flat` stacks them visibly. */
layout: {
		stacked: "",
		flat: "static h-auto"
	} },
	defaultVariants: { layout: "stacked" }
});
function ToastRoot({ className, layout, ...props }) {
	return /* @__PURE__ */ jsx(Toast.Root, {
		"data-slot": "toast-root",
		className: cn(toastRootVariants({ layout }), className),
		...props
	});
}
function ToastContent({ className, ...props }) {
	return /* @__PURE__ */ jsx(Toast.Content, {
		"data-slot": "toast-content",
		className: cn("flex items-center gap-3 overflow-hidden p-3 transition-opacity duration-200", "data-[behind]:opacity-0 data-[expanded]:opacity-100", className),
		...props
	});
}
function ToastTitle({ className, ...props }) {
	return /* @__PURE__ */ jsx(Toast.Title, {
		"data-slot": "toast-title",
		className: cn("text-sm font-medium", className),
		...props
	});
}
function ToastDescription({ className, ...props }) {
	return /* @__PURE__ */ jsx(Toast.Description, {
		"data-slot": "toast-description",
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
var toastCloseVariants = cva(cn("inline-flex cursor-pointer shrink-0 items-center justify-center gap-2 whitespace-nowrap rounded-md border border-input bg-background px-3 text-sm leading-none font-medium text-foreground transition-colors select-none", "hover:bg-accent hover:text-accent-foreground", "data-[disabled]:pointer-events-none data-[disabled]:opacity-50", focusRing), {
	variants: {
		size: {
			default: "h-9 px-3",
			sm: "h-8 px-2.5 text-xs",
			icon: "size-8 p-0 [&_svg]:size-4"
		},
		variant: {
			outline: "",
			ghost: "border-transparent bg-transparent"
		}
	},
	defaultVariants: {
		size: "default",
		variant: "outline"
	}
});
function ToastClose({ className, size, variant, children, ...props }) {
	return /* @__PURE__ */ jsx(Toast.Close, {
		"data-slot": "toast-close",
		className: cn(toastCloseVariants({
			size,
			variant
		}), className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(X, { className: "size-4" })
	});
}
function ToastAction({ className, size, ...props }) {
	return /* @__PURE__ */ jsx(Toast.Action, {
		"data-slot": "toast-action",
		className: cn(toastCloseVariants({
			size,
			variant: "outline"
		}), className),
		...props
	});
}
function ToastPortal({ className, ...props }) {
	return /* @__PURE__ */ jsx(Toast.Portal, {
		"data-slot": "toast-portal",
		className: cn(className),
		...props
	});
}
/** Anchors a toast to a trigger element instead of stacking it in the viewport. */
function ToastPositioner({ className, ...props }) {
	return /* @__PURE__ */ jsx(Toast.Positioner, {
		"data-slot": "toast-positioner",
		className: cn("z-50 outline-hidden", className),
		...props
	});
}
function ToastArrow({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Toast.Arrow, {
		"data-slot": "toast-arrow",
		className: cn("flex size-4 items-center justify-center text-popover-foreground", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(X, { className: "size-3 rotate-45" })
	});
}
function ToastViewport({ className, ...props }) {
	return /* @__PURE__ */ jsx(Toast.Viewport, {
		"data-slot": "toast-viewport",
		className: cn("fixed right-4 bottom-4 z-50 mx-auto flex w-[calc(100vw-2rem)] max-w-sm flex-col-reverse outline-hidden", className),
		...props
	});
}
/** Re-exported Base UI helpers so demos never need the raw package. */
var useToastManager = Toast.useToastManager;
var createToastManager = Toast.createToastManager;
//#endregion
export { ToastAction, ToastArrow, ToastClose, ToastContent, ToastDescription, ToastPortal, ToastPositioner, ToastProvider, ToastRoot, ToastTitle, ToastViewport, createToastManager, toastCloseVariants, toastRootVariants, useToastManager };
