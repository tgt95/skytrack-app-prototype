import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import { i as CONTROL_SIZE_CLASSES, r as focusRing } from "./chunks/button-1Z23yCSW.js";
import "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Input as Input$1 } from "@base-ui/react/input";
//#region src/components/ui/input.tsx
/**
* Sits in flow beside the input, the way MUI's `InputAdornment` does: the input is
* `flex-1 min-w-0` so it shrinks and scrolls its text, and the adornment is `shrink-0`.
* Nothing is absolutely positioned and no fixed padding is reserved, so a wide
* adornment (a currency suffix, a long unit) never overlaps the value.
*/
function InputAdornment({ className, position, ...props }) {
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "input-adornment",
		"data-position": position,
		className: cn("flex h-9 shrink-0 items-center text-muted-foreground", "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", className),
		...props
	});
}
function Input({ className, size = "default", startAdornment, endAdornment, ...props }) {
	if (startAdornment == null && endAdornment == null) return /* @__PURE__ */ jsx(Input$1, {
		"data-slot": "input",
		"data-size": size,
		className: cn("flex w-full min-w-0 rounded-(--radius) border border-input bg-background px-3 py-1 text-foreground shadow-xs transition-colors", CONTROL_SIZE_CLASSES[size], "placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground", "file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground", "data-disabled:cursor-not-allowed data-disabled:opacity-50", "data-invalid:border-destructive data-invalid:ring-destructive/20", focusRing, className),
		...props
	});
	const inputClassName = typeof className === "function" ? className : void 0;
	const wrapperClassName = typeof className === "function" ? void 0 : className;
	return /* @__PURE__ */ jsxs("span", {
		"data-slot": "input-root",
		"data-size": size,
		className: cn("flex w-full items-center rounded-(--radius) border border-input bg-background transition-colors", CONTROL_SIZE_CLASSES[size], "focus-within:border-ring focus-within:ring-[3px] focus-within:ring-ring/50", "has-[[data-invalid]]:border-destructive has-[[data-invalid]]:ring-destructive/20", "has-[[data-disabled]]:cursor-not-allowed has-[[data-disabled]]:opacity-50", wrapperClassName),
		children: [
			startAdornment != null && /* @__PURE__ */ jsx(InputAdornment, {
				position: "start",
				className: "h-full pl-3",
				children: startAdornment
			}),
			/* @__PURE__ */ jsx(Input$1, {
				"data-slot": "input",
				"data-size": size,
				className: cn("flex h-full min-w-0 flex-1 rounded-(--radius) bg-transparent px-3 py-1 text-sm text-foreground outline-hidden transition-colors", "placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground", "file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground", inputClassName, startAdornment != null && "pl-2", endAdornment != null && "pr-2"),
				...props
			}),
			endAdornment != null && /* @__PURE__ */ jsx(InputAdornment, {
				position: "end",
				className: "h-full pr-3",
				children: endAdornment
			})
		]
	});
}
//#endregion
export { Input, InputAdornment };
