import { t as cn } from "./chunks/utils-QluraT_M.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { Tooltip as Tooltip$1 } from "@base-ui/react/tooltip";
//#region src/components/ui/tooltip.tsx
/**
* Tooltip — a visual hint that appears when an element is hovered or focused.
* `TooltipProvider` and `Tooltip` (Root) render no element of their own, so they
* are re-exported as-is.
*/
var TooltipProvider = Tooltip$1.Provider;
var Tooltip = Tooltip$1.Root;
/** Creates a handle that lets detached triggers control this tooltip. */
var createHandle = Tooltip$1.createHandle;
function TooltipTrigger({ className, variant, size, ...props }) {
	return /* @__PURE__ */ jsx(Tooltip$1.Trigger, {
		"data-slot": "tooltip-trigger",
		className: cn("cursor-pointer", "data-[popup-open]:bg-accent data-[popup-open]:text-accent-foreground", className),
		...props
	});
}
function TooltipPortal({ className, ...props }) {
	return /* @__PURE__ */ jsx(Tooltip$1.Portal, {
		"data-slot": "tooltip-portal",
		className: cn("z-50", className),
		...props
	});
}
function TooltipPositioner({ className, ...props }) {
	return /* @__PURE__ */ jsx(Tooltip$1.Positioner, {
		"data-slot": "tooltip-positioner",
		className: cn("z-50 h-[var(--positioner-height)] w-[var(--positioner-width)] max-w-[var(--available-width)]", className),
		...props
	});
}
function TooltipPopup({ className, ...props }) {
	return /* @__PURE__ */ jsx(Tooltip$1.Popup, {
		"data-slot": "tooltip-popup",
		className: cn("z-50 flex w-[var(--popup-width,auto)] max-w-64 origin-[var(--transform-origin)] items-center rounded-md bg-foreground px-3 py-1.5 text-xs text-background", "transition-[scale,opacity] duration-100 ease-out", "data-[starting-style]:scale-90 data-[starting-style]:opacity-0", "data-[ending-style]:scale-90 data-[ending-style]:opacity-0", "data-[instant]:transition-none", className),
		...props
	});
}
/**
* The arrow glyph: a true isoceles triangle, not a clipped rotated square.
*
* Drawn in the same 10x10 user-space box as the arrow element (`size-2.5`), so
* 1 user unit === 1 CSS pixel and the four rotations below need no per-side
* nudging. `y=5` is the popup border, because each side offsets the arrow box by
* exactly half its own size (`[-5px]`), which centres the box on that border:
*
* - base at `y=6` — 10px wide, sitting 1px *inside* the popup so the junction
*   overlaps the popup edge and cannot show a seam;
* - apex at `y=1` — 5px out from the base, 1px clear of the box edge, so no
*   overflow clip can ever truncate the tip into a blunt edge.
*
* For `side=top|left|right` the box is rotated about its centre, which mirrors
* those two offsets to the correct border; the base stays 1px inside and the
* apex stays 5px out in every orientation.
*
* `fill="currentColor"` + `text-foreground` resolves to the same `--foreground`
* token as the popup's `bg-foreground`, in both themes.
*/
function TooltipArrowGlyph(props) {
	return /* @__PURE__ */ jsx("svg", {
		width: "10",
		height: "10",
		viewBox: "0 0 10 10",
		fill: "currentColor",
		"aria-hidden": "true",
		focusable: "false",
		...props,
		children: /* @__PURE__ */ jsx("path", { d: "M0 6h10L5 1Z" })
	});
}
function TooltipArrow({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Tooltip$1.Arrow, {
		"data-slot": "tooltip-arrow",
		className: cn("pointer-events-none absolute z-10 block size-2.5 text-foreground", "data-[side=bottom]:top-[-5px]", "data-[side=top]:bottom-[-5px] data-[side=top]:rotate-180", "data-[side=left]:right-[-5px] data-[side=left]:rotate-90", "data-[side=right]:left-[-5px] data-[side=right]:-rotate-90", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(TooltipArrowGlyph, {})
	});
}
function TooltipViewport({ className, ...props }) {
	return /* @__PURE__ */ jsx(Tooltip$1.Viewport, {
		"data-slot": "tooltip-viewport",
		className: cn("relative h-full w-full overflow-clip", className),
		...props
	});
}
//#endregion
export { Tooltip, TooltipArrow, TooltipPopup, TooltipPortal, TooltipPositioner, TooltipProvider, TooltipTrigger, TooltipViewport, createHandle };
