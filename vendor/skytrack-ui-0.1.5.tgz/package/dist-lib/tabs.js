import { t as cn } from "./chunks/utils-QluraT_M.js";
import { focusRing } from "./button.js";
import "react";
import { cva } from "class-variance-authority";
import { jsx } from "react/jsx-runtime";
import { Tabs as Tabs$1 } from "@base-ui/react/tabs";
//#region src/components/ui/tabs.tsx
function Tabs({ className, ...props }) {
	return /* @__PURE__ */ jsx(Tabs$1.Root, {
		"data-slot": "tabs",
		className: cn("flex w-full max-w-lg flex-col gap-2", className),
		...props
	});
}
var tabsListVariants = cva("relative z-0 flex w-fit items-center text-muted-foreground", {
	variants: { variant: {
		filled: "gap-1 rounded-lg bg-muted p-1",
		standard: "gap-2 bg-transparent",
		outlined: "gap-1 rounded-lg border border-input bg-transparent p-1"
	} },
	defaultVariants: { variant: "filled" }
});
function TabsList({ className, variant, ...props }) {
	return /* @__PURE__ */ jsx(Tabs$1.List, {
		"data-slot": "tabs-list",
		className: cn(tabsListVariants({ variant }), className),
		...props
	});
}
var tabsTabVariants = cva(cn("relative z-10 inline-flex cursor-pointer flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-md font-medium transition-colors select-none", "hover:text-foreground", "disabled:pointer-events-none disabled:opacity-50 data-[disabled]:pointer-events-none data-[disabled]:opacity-50", focusRing), {
	variants: {
		variant: {
			filled: "data-[active]:bg-background data-[active]:text-foreground",
			standard: "data-[active]:bg-transparent data-[active]:text-primary",
			outlined: "data-[active]:bg-background data-[active]:text-foreground"
		},
		size: {
			xs: "px-2 py-0.5 text-xs",
			sm: "px-2.5 py-1 text-xs",
			default: "px-3 py-1.5 text-sm",
			lg: "px-4 py-2 text-base"
		}
	},
	defaultVariants: {
		variant: "filled",
		size: "default"
	}
});
function TabsTab({ className, variant, size, ...props }) {
	return /* @__PURE__ */ jsx(Tabs$1.Tab, {
		"data-slot": "tabs-tab",
		className: cn(tabsTabVariants({
			variant,
			size
		}), className),
		...props
	});
}
var tabsIndicatorVariants = cva(cn("absolute z-0", "transition-[left,top,width,height] duration-200 ease-out motion-reduce:transition-none"), {
	variants: { variant: {
		pill: "left-[var(--active-tab-left)] top-[var(--active-tab-top)] h-[var(--active-tab-height)] w-[var(--active-tab-width)] rounded-md bg-background",
		underline: "top-auto bottom-0 left-[var(--active-tab-left)] h-0.5 w-[var(--active-tab-width)] rounded-none bg-primary shadow-none data-[orientation=vertical]:top-[var(--active-tab-top)] data-[orientation=vertical]:bottom-auto data-[orientation=vertical]:h-[var(--active-tab-height)] data-[orientation=vertical]:w-0.5"
	} },
	defaultVariants: { variant: "pill" }
});
function TabsIndicator({ className, variant, ...props }) {
	return /* @__PURE__ */ jsx(Tabs$1.Indicator, {
		"data-slot": "tabs-indicator",
		className: cn(tabsIndicatorVariants({ variant }), className),
		...props
	});
}
function TabsPanel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Tabs$1.Panel, {
		"data-slot": "tabs-panel",
		className: cn("flex-1 rounded-lg border border-border bg-card p-4 text-sm text-card-foreground outline-none", "transition-all duration-200 data-[starting-style]:opacity-0 data-[ending-style]:opacity-0", "motion-safe:data-[starting-style]:data-[activation-direction=left]:translate-x-[-50%]", "motion-safe:data-[starting-style]:data-[activation-direction=right]:translate-x-[50%]", "motion-safe:data-[ending-style]:data-[activation-direction=left]:translate-x-[50%]", "motion-safe:data-[ending-style]:data-[activation-direction=right]:translate-x-[-50%]", focusRing, className),
		...props
	});
}
/** shadcn-style aliases. */
var TabsTrigger = TabsTab;
var TabsContent = TabsPanel;
//#endregion
export { Tabs, TabsContent, TabsIndicator, TabsList, TabsPanel, TabsTab, TabsTrigger };
