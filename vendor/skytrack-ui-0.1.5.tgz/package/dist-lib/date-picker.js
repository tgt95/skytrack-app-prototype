import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import { t as Button } from "./chunks/button-1Z23yCSW.js";
import { Calendar } from "./calendar.js";
import { Popover, PopoverPopup, PopoverPortal, PopoverPositioner, PopoverTrigger } from "./popover.js";
import * as React from "react";
import { CalendarBlankIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/components/ui/date-picker.tsx
function DatePicker(props) {
	const { value, defaultValue, onValueChange, id, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, placeholder = "Pick a date", disabled = false, className, buttonClassName, calendarClassName, calendarProps } = props;
	const [internalValue, setInternalValue] = React.useState(defaultValue);
	const [open, setOpen] = React.useState(false);
	const isControlled = Object.prototype.hasOwnProperty.call(props, "value");
	const selectedDate = isControlled ? value : internalValue;
	const handleSelect = (nextValue) => {
		if (!isControlled) setInternalValue(nextValue);
		onValueChange?.(nextValue);
		setOpen(false);
	};
	const label = selectedDate ? new Intl.DateTimeFormat(void 0, { dateStyle: "medium" }).format(selectedDate) : placeholder;
	return /* @__PURE__ */ jsxs(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ jsx("div", {
			"data-slot": "date-picker",
			className: cn("w-full sm:w-64", className),
			children: /* @__PURE__ */ jsxs(PopoverTrigger, {
				render: /* @__PURE__ */ jsx(Button, {
					variant: "outline",
					disabled,
					id,
					"data-empty": !selectedDate,
					"aria-label": ariaLabel ?? (id || ariaLabelledby ? void 0 : selectedDate ? `Selected date: ${label}` : placeholder),
					"aria-labelledby": ariaLabelledby,
					className: cn("w-full justify-start text-left font-normal data-[empty=true]:text-muted-foreground", buttonClassName)
				}),
				children: [/* @__PURE__ */ jsx(CalendarBlankIcon, { "aria-hidden": "true" }), /* @__PURE__ */ jsx("span", {
					className: "truncate",
					children: label
				})]
			})
		}), /* @__PURE__ */ jsx(PopoverPortal, { children: /* @__PURE__ */ jsx(PopoverPositioner, {
			side: "bottom",
			align: "start",
			sideOffset: 4,
			children: /* @__PURE__ */ jsx(PopoverPopup, {
				className: "w-auto p-0",
				children: /* @__PURE__ */ jsx(Calendar, {
					mode: "single",
					selected: selectedDate,
					onSelect: handleSelect,
					className: calendarClassName,
					...calendarProps
				})
			})
		}) })]
	});
}
//#endregion
export { DatePicker };
