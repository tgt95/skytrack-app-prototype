import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import "react";
import { CaretRightIcon, CheckIcon } from "@phosphor-icons/react";
import { cva } from "class-variance-authority";
import { jsx, jsxs } from "react/jsx-runtime";
import { ContextMenu as ContextMenu$1 } from "@base-ui/react/context-menu";
//#region src/components/ui/context-menu.tsx
/**
* Context menus reuse the Menu row styling so a right-clicked popup and a
* clicked popup look identical. `variant="destructive"` is the destructive item variant.
*/
var contextMenuItemVariants = cva(cn("relative flex cursor-pointer items-center gap-2 rounded-(--radius) px-2 py-1.5 text-left text-sm text-popover-foreground select-none outline-none transition-colors", "data-highlighted:bg-accent data-highlighted:text-accent-foreground", "data-disabled:pointer-events-none data-disabled:opacity-50", "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4"), {
	variants: {
		variant: {
			default: "",
			destructive: "text-destructive data-highlighted:bg-destructive data-highlighted:text-white"
		},
		inset: {
			true: "pl-8",
			false: ""
		}
	},
	defaultVariants: {
		variant: "default",
		inset: false
	}
});
function ContextMenu(props) {
	return /* @__PURE__ */ jsx(ContextMenu$1.Root, { ...props });
}
function ContextMenuTrigger({ className, ...props }) {
	return /* @__PURE__ */ jsx(ContextMenu$1.Trigger, {
		"data-slot": "context-menu-trigger",
		className,
		...props
	});
}
function ContextMenuPortal({ className, ...props }) {
	return /* @__PURE__ */ jsx(ContextMenu$1.Portal, {
		"data-slot": "context-menu-portal",
		className: cn(className),
		...props
	});
}
function ContextMenuBackdrop({ className, ...props }) {
	return /* @__PURE__ */ jsx(ContextMenu$1.Backdrop, {
		"data-slot": "context-menu-backdrop",
		className: cn("fixed inset-0 z-50 bg-foreground/20 transition-opacity duration-150", "data-starting-style:opacity-0 data-ending-style:opacity-0", className),
		...props
	});
}
function ContextMenuPositioner({ className, ...props }) {
	return /* @__PURE__ */ jsx(ContextMenu$1.Positioner, {
		"data-slot": "context-menu-positioner",
		className: cn("z-50 outline-hidden", className),
		...props
	});
}
function ContextMenuPopup({ className, ...props }) {
	return /* @__PURE__ */ jsx(ContextMenu$1.Popup, {
		"data-slot": "context-menu-popup",
		className: cn("origin-[var(--transform-origin)] rounded-(--radius) border border-border bg-popover p-1 text-popover-foreground shadow-md outline-hidden", "max-h-[var(--available-height)] min-w-[8rem] overflow-y-auto overscroll-contain", "transition-[scale,opacity] duration-100 ease-out data-instant:transition-none", "data-starting-style:scale-95 data-starting-style:opacity-0", "data-ending-style:scale-95 data-ending-style:opacity-0", className),
		...props
	});
}
function ContextMenuArrow({ className, ...props }) {
	return /* @__PURE__ */ jsx(ContextMenu$1.Arrow, {
		"data-slot": "context-menu-arrow",
		className: cn("h-2 w-2 rotate-45 rounded-(--radius) border border-border bg-popover", "data-[side=top]:-bottom-1 data-[side=top]:-rotate-135", "data-[side=bottom]:-top-1 data-[side=bottom]:rotate-45", "data-[side=left]:-right-1 data-[side=left]:rotate-225", "data-[side=right]:-left-1 data-[side=right]:rotate-135", className),
		...props
	});
}
function ContextMenuGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx(ContextMenu$1.Group, {
		"data-slot": "context-menu-group",
		className: cn(className),
		...props
	});
}
function ContextMenuGroupLabel({ className, ...props }) {
	return /* @__PURE__ */ jsx(ContextMenu$1.GroupLabel, {
		"data-slot": "context-menu-group-label",
		className: cn("px-2 py-1.5 text-xs font-medium tracking-wide text-muted-foreground select-none", className),
		...props
	});
}
function ContextMenuSeparator({ className, ...props }) {
	return /* @__PURE__ */ jsx(ContextMenu$1.Separator, {
		"data-slot": "context-menu-separator",
		className: cn("-mx-1 my-1 h-px shrink-0 bg-border", className),
		...props
	});
}
function ContextMenuItem({ className, variant, inset, ...props }) {
	return /* @__PURE__ */ jsx(ContextMenu$1.Item, {
		"data-slot": "context-menu-item",
		className: cn(contextMenuItemVariants({
			variant,
			inset
		}), className),
		...props
	});
}
function ContextMenuLinkItem({ className, variant, inset, ...props }) {
	return /* @__PURE__ */ jsx(ContextMenu$1.LinkItem, {
		"data-slot": "context-menu-link-item",
		className: cn(contextMenuItemVariants({
			variant,
			inset
		}), className),
		...props
	});
}
function ContextMenuSubmenuRoot(props) {
	return /* @__PURE__ */ jsx(ContextMenu$1.SubmenuRoot, { ...props });
}
function ContextMenuSubmenuTrigger({ className, children, variant, inset, ...props }) {
	return /* @__PURE__ */ jsxs(ContextMenu$1.SubmenuTrigger, {
		"data-slot": "context-menu-submenu-trigger",
		className: cn(contextMenuItemVariants({
			variant,
			inset
		}), "justify-between data-popup-open:bg-accent data-popup-open:text-accent-foreground", className),
		...props,
		children: [children, /* @__PURE__ */ jsx(CaretRightIcon, { className: "ml-auto" })]
	});
}
function ContextMenuRadioGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx(ContextMenu$1.RadioGroup, {
		"data-slot": "context-menu-radio-group",
		className: cn("py-0.5", className),
		...props
	});
}
function ContextMenuRadioItem({ className, variant, inset, ...props }) {
	return /* @__PURE__ */ jsx(ContextMenu$1.RadioItem, {
		"data-slot": "context-menu-radio-item",
		className: cn(contextMenuItemVariants({
			variant,
			inset
		}), className),
		...props
	});
}
function ContextMenuRadioItemIndicator({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(ContextMenu$1.RadioItemIndicator, {
		"data-slot": "context-menu-radio-item-indicator",
		className: cn("absolute left-2 flex size-4 items-center justify-center text-current", "transition-all data-starting-style:scale-50 data-starting-style:opacity-0 data-ending-style:scale-50 data-ending-style:opacity-0", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx("span", { className: "size-2 rounded-full bg-current" })
	});
}
function ContextMenuCheckboxItem({ className, variant, inset, ...props }) {
	return /* @__PURE__ */ jsx(ContextMenu$1.CheckboxItem, {
		"data-slot": "context-menu-checkbox-item",
		className: cn(contextMenuItemVariants({
			variant,
			inset
		}), className),
		...props
	});
}
function ContextMenuCheckboxItemIndicator({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(ContextMenu$1.CheckboxItemIndicator, {
		"data-slot": "context-menu-checkbox-item-indicator",
		className: cn("absolute left-2 flex size-4 items-center justify-center text-current", "transition-all data-starting-style:scale-75 data-starting-style:opacity-0 data-ending-style:scale-75 data-ending-style:opacity-0", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CheckIcon, {
			className: "size-3.5",
			weight: "bold"
		})
	});
}
function ContextMenuShortcut({ className, ...props }) {
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "context-menu-shortcut",
		className: cn("ml-auto text-xs tracking-widest text-muted-foreground", className),
		...props
	});
}
//#endregion
export { ContextMenu, ContextMenuArrow, ContextMenuBackdrop, ContextMenuCheckboxItem, ContextMenuCheckboxItemIndicator, ContextMenuGroup, ContextMenuGroupLabel, ContextMenuItem, ContextMenuLinkItem, ContextMenuPopup, ContextMenuPortal, ContextMenuPositioner, ContextMenuRadioGroup, ContextMenuRadioItem, ContextMenuRadioItemIndicator, ContextMenuSeparator, ContextMenuShortcut, ContextMenuSubmenuRoot, ContextMenuSubmenuTrigger, ContextMenuTrigger, contextMenuItemVariants };
