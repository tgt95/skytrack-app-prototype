import * as React from 'react';
import { Popover as BasePopover } from '@base-ui/react/popover';
/** Native Base UI props for `PopoverTrigger`; styling comes from the call site. */
export type PopoverTriggerProps = React.ComponentProps<typeof BasePopover.Trigger>;
/**
 * Popover — a popup anchored to a trigger.
 * `Popover` (Root) renders no element of its own, so it is re-exported as-is.
 */
declare const Popover: typeof BasePopover.Root;
/** Creates a handle that lets detached triggers control this popover. */
declare const createHandle: typeof BasePopover.createHandle;
type PopoverChangeEventDetails = Parameters<NonNullable<React.ComponentProps<typeof BasePopover.Root>['onOpenChange']>>[1];
declare function PopoverTrigger({ className, ...props }: React.ComponentProps<typeof BasePopover.Trigger>): React.JSX.Element;
declare function PopoverPortal({ className, ...props }: React.ComponentProps<typeof BasePopover.Portal>): React.JSX.Element;
declare function PopoverBackdrop({ className, ...props }: React.ComponentProps<typeof BasePopover.Backdrop>): React.JSX.Element;
declare function PopoverPositioner({ className, ...props }: React.ComponentProps<typeof BasePopover.Positioner>): React.JSX.Element;
declare function PopoverPopup({ className, ...props }: React.ComponentProps<typeof BasePopover.Popup>): React.JSX.Element;
declare function PopoverArrow({ className, children, ...props }: React.ComponentProps<typeof BasePopover.Arrow>): React.JSX.Element;
declare function PopoverTitle({ className, ...props }: React.ComponentProps<typeof BasePopover.Title>): React.JSX.Element;
declare function PopoverDescription({ className, ...props }: React.ComponentProps<typeof BasePopover.Description>): React.JSX.Element;
declare function PopoverClose({ className, ...props }: React.ComponentProps<typeof BasePopover.Close>): React.JSX.Element;
declare function PopoverViewport({ className, ...props }: React.ComponentProps<typeof BasePopover.Viewport>): React.JSX.Element;
export { Popover, createHandle, PopoverTrigger, PopoverPortal, PopoverBackdrop, PopoverPositioner, PopoverPopup, PopoverArrow, PopoverTitle, PopoverDescription, PopoverClose, PopoverViewport };
export type { PopoverChangeEventDetails };
