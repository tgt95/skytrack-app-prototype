import * as React from 'react';
import { AlertDialog as BaseAlertDialog } from '@base-ui/react/alert-dialog';
import type { VariantProps } from 'class-variance-authority';
import { buttonVariants } from '@/components/ui/button';
/** Shared variant/size props for `AlertDialogTrigger` and `AlertDialogClose`. */
export type AlertDialogButtonProps = VariantProps<typeof buttonVariants>;
/**
 * Alert Dialog — a dialog that requires a user response to proceed.
 * `AlertDialog` (Root) renders no element of its own, so it is re-exported as-is.
 */
declare const AlertDialog: typeof BaseAlertDialog.Root;
/** Creates a handle that lets detached triggers control this alert dialog. */
declare const createHandle: typeof BaseAlertDialog.createHandle;
type AlertDialogChangeEventDetails = Parameters<NonNullable<React.ComponentProps<typeof BaseAlertDialog.Root>['onOpenChange']>>[1];
declare function AlertDialogTrigger({ className, variant, size, ...props }: React.ComponentProps<typeof BaseAlertDialog.Trigger> & AlertDialogButtonProps): React.JSX.Element;
declare function AlertDialogPortal({ className, ...props }: React.ComponentProps<typeof BaseAlertDialog.Portal>): React.JSX.Element;
declare function AlertDialogBackdrop({ className, ...props }: React.ComponentProps<typeof BaseAlertDialog.Backdrop>): React.JSX.Element;
/** Convenience alias matching the shadcn naming. */
declare function AlertDialogOverlay({ className, ...props }: React.ComponentProps<typeof BaseAlertDialog.Backdrop>): React.JSX.Element;
declare function AlertDialogViewport({ className, ...props }: React.ComponentProps<typeof BaseAlertDialog.Viewport>): React.JSX.Element;
declare function AlertDialogPopup({ className, ...props }: React.ComponentProps<typeof BaseAlertDialog.Popup>): React.JSX.Element;
declare function AlertDialogHeader({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
declare function AlertDialogFooter({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
declare function AlertDialogTitle({ className, ...props }: React.ComponentProps<typeof BaseAlertDialog.Title>): React.JSX.Element;
declare function AlertDialogDescription({ className, ...props }: React.ComponentProps<typeof BaseAlertDialog.Description>): React.JSX.Element;
declare function AlertDialogClose({ className, variant, size, ...props }: React.ComponentProps<typeof BaseAlertDialog.Close> & AlertDialogButtonProps): React.JSX.Element;
export { AlertDialog, createHandle, AlertDialogTrigger, AlertDialogPortal, AlertDialogBackdrop, AlertDialogOverlay, AlertDialogViewport, AlertDialogPopup, AlertDialogHeader, AlertDialogFooter, AlertDialogTitle, AlertDialogDescription, AlertDialogClose };
export type { AlertDialogChangeEventDetails };
