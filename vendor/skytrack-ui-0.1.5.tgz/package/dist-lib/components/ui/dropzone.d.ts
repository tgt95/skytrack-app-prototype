import * as React from 'react';
export type DropzoneProps = Omit<React.ComponentProps<'div'>, 'onDrop' | 'onDragEnter' | 'onDragOver' | 'onDragLeave'> & {
    accept?: string;
    multiple?: boolean;
    disabled?: boolean;
    hint?: React.ReactNode;
    buttonLabel?: string;
    onFilesSelected?: (files: File[]) => void;
};
declare function Dropzone({ accept, multiple, disabled, hint, buttonLabel, onFilesSelected, className, ...props }: DropzoneProps): React.JSX.Element;
export { Dropzone };
