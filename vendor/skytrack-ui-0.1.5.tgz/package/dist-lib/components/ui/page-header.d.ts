import * as React from 'react';
export type PageHeaderProps = Omit<React.ComponentProps<'header'>, 'title'> & {
    /** Breadcrumb composition, usually built with the SkyTrack Breadcrumb parts. */
    breadcrumbs?: React.ReactNode;
    /** Page title rendered as an h1 with the `.h3` visual style. */
    title: React.ReactNode;
    /** Page-level actions, usually built with SkyTrack Toolbar parts. */
    toolbar?: React.ReactNode;
    /** Optional lower content, such as a caller-composed SkyTrack Tabs instance. */
    children?: React.ReactNode;
};
/** Page heading composition. Breadcrumbs and Toolbar are caller-composed; children can hold Tabs. */
declare function PageHeader({ breadcrumbs, title, toolbar, className, children, ...props }: PageHeaderProps): React.JSX.Element;
export { PageHeader };
