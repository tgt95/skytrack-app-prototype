import * as React from 'react';
import { Menubar as BaseMenubar } from '@base-ui/react/menubar';
/**
 * Container for a row of `Menu.Root` instances. Menus themselves come from
 * `@/components/ui/menu`; this only styles the bar that holds the triggers.
 */
declare function Menubar({ className, ...props }: React.ComponentProps<typeof BaseMenubar>): React.JSX.Element;
export { Menubar };
