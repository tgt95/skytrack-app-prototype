import * as React from 'react';
import { type DayPickerProps } from 'react-day-picker';
type DistributiveOmit<T, K extends PropertyKey> = T extends unknown ? Omit<T, K> : never;
export type CalendarProps = DistributiveOmit<DayPickerProps, 'captionLayout' | 'navLayout'> & {
    className?: string;
};
declare function Calendar({ className, classNames, components, ...props }: CalendarProps): React.JSX.Element;
export { Calendar };
