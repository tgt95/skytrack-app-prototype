import * as React from 'react';
import { Toggle as BaseToggle } from '@base-ui/react/toggle';
import { type VariantProps } from 'class-variance-authority';
export declare const toggleVariants: (props?: ({
    variant?: "brand" | "default" | "outline" | "segmented" | null | undefined;
    size?: "default" | "lg" | "sm" | "xs" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
type ToggleProps = React.ComponentProps<typeof BaseToggle> & VariantProps<typeof toggleVariants>;
declare function Toggle({ className, variant, size, ...props }: ToggleProps): React.JSX.Element;
export { Toggle };
