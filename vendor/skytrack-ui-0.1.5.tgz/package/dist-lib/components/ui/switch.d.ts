import * as React from 'react';
import { Switch as BaseSwitch } from '@base-ui/react/switch';
import { type VariantProps } from 'class-variance-authority';
export declare const switchVariants: (props?: ({
    size?: "default" | "sm" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export declare const switchThumbVariants: (props?: ({
    size?: "default" | "sm" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
type SwitchProps = React.ComponentProps<typeof BaseSwitch.Root> & VariantProps<typeof switchVariants>;
declare function Switch({ className, size, ...props }: SwitchProps): React.JSX.Element;
type SwitchThumbProps = React.ComponentProps<typeof BaseSwitch.Thumb> & VariantProps<typeof switchThumbVariants>;
declare function SwitchThumb({ className, size, ...props }: SwitchThumbProps): React.JSX.Element;
export { Switch, SwitchThumb };
