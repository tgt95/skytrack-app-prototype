import * as React from 'react';
import type { DayPickerProps } from 'react-day-picker';
type DistributiveOmit<T, K extends PropertyKey> = T extends unknown ? Omit<T, K> : never;
export type DatePickerProps = {
    id?: string;
    'aria-label'?: string;
    'aria-labelledby'?: string;
    value?: Date;
    defaultValue?: Date;
    onValueChange?: (value: Date | undefined) => void;
    placeholder?: string;
    disabled?: boolean;
    className?: string;
    buttonClassName?: string;
    calendarClassName?: string;
    calendarProps?: DistributiveOmit<Extract<DayPickerProps, {
        mode: 'single';
    }>, 'mode' | 'selected' | 'onSelect' | 'captionLayout' | 'navLayout'>;
};
declare function DatePicker(props: DatePickerProps): React.JSX.Element;
export { DatePicker };
