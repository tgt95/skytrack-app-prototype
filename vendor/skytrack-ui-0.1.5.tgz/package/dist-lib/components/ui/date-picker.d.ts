import * as React from 'react';
import { type DateRange, type DayPickerProps } from 'react-day-picker';
type DistributiveOmit<T, K extends PropertyKey> = T extends unknown ? Omit<T, K> : never;
export type DatePickerProps = {
    id?: string;
    'aria-label'?: string;
    'aria-labelledby'?: string;
    value?: Date;
    defaultValue?: Date;
    onValueChange?: (value: Date | undefined) => void;
    placeholder?: string;
    disabled?: boolean;
    className?: string;
    buttonClassName?: string;
    calendarClassName?: string;
    /** Accessible name for the calendar button that opens the popover. */
    calendarButtonLabel?: string;
    calendarProps?: DistributiveOmit<Extract<DayPickerProps, {
        mode: 'single';
    }>, 'mode' | 'selected' | 'onSelect' | 'captionLayout' | 'navLayout'>;
};
export type DateRangePickerProps = {
    id?: string;
    'aria-label'?: string;
    'aria-labelledby'?: string;
    value?: DateRange;
    defaultValue?: DateRange;
    onValueChange?: (value: DateRange | undefined) => void;
    placeholder?: string;
    disabled?: boolean;
    className?: string;
    buttonClassName?: string;
    calendarClassName?: string;
    calendarProps?: DistributiveOmit<Extract<DayPickerProps, {
        mode: 'range';
    }>, 'mode' | 'selected' | 'onSelect' | 'captionLayout' | 'navLayout'>;
};
export type DateWeekPickerProps = {
    id?: string;
    'aria-label'?: string;
    'aria-labelledby'?: string;
    /** Any date inside the selected week; the value is normalized to that week's Monday. */
    value?: Date;
    defaultValue?: Date;
    onValueChange?: (value: Date | undefined) => void;
    placeholder?: string;
    disabled?: boolean;
    className?: string;
    buttonClassName?: string;
    calendarClassName?: string;
    calendarProps?: DistributiveOmit<Extract<DayPickerProps, {
        mode: 'range';
    }>, 'mode' | 'selected' | 'onSelect' | 'captionLayout' | 'navLayout'>;
};
declare function DatePicker(props: DatePickerProps): React.JSX.Element;
declare function DateRangePicker(props: DateRangePickerProps): React.JSX.Element;
declare function DateWeekPicker(props: DateWeekPickerProps): React.JSX.Element;
export { DatePicker, DateRangePicker, DateWeekPicker };
