import * as React from 'react';
import { Toast as BaseToast } from '@base-ui/react/toast';
import { type VariantProps } from 'class-variance-authority';
/** Props of the `Toast` root for a single toast object. */
export type ToastRootProps<Data extends object = any> = BaseToast.Root.Props & {
    toast: BaseToast.Root.ToastObject<Data>;
};
/** Renders no element of its own; only provides the toast manager context. */
declare function ToastProvider(props: React.ComponentProps<typeof BaseToast.Provider>): React.JSX.Element;
export declare const toastRootVariants: (props?: ({
    layout?: "flat" | "stacked" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
type ToastRootComponentProps = React.ComponentProps<typeof BaseToast.Root> & VariantProps<typeof toastRootVariants>;
declare function ToastRoot({ className, layout, ...props }: ToastRootComponentProps): React.JSX.Element;
declare function ToastContent({ className, ...props }: React.ComponentProps<typeof BaseToast.Content>): React.JSX.Element;
declare function ToastTitle({ className, ...props }: React.ComponentProps<typeof BaseToast.Title>): React.JSX.Element;
declare function ToastDescription({ className, ...props }: React.ComponentProps<typeof BaseToast.Description>): React.JSX.Element;
export declare const toastCloseVariants: (props?: ({
    size?: "default" | "icon" | "sm" | null | undefined;
    variant?: "ghost" | "outline" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
type ToastCloseProps = React.ComponentProps<typeof BaseToast.Close> & VariantProps<typeof toastCloseVariants>;
declare function ToastClose({ className, size, variant, children, ...props }: ToastCloseProps): React.JSX.Element;
declare function ToastAction({ className, size, variant, ...props }: React.ComponentProps<typeof BaseToast.Action> & VariantProps<typeof toastCloseVariants>): React.JSX.Element;
declare function ToastPortal({ className, ...props }: React.ComponentProps<typeof BaseToast.Portal>): React.JSX.Element;
/** Anchors a toast to a trigger element instead of stacking it in the viewport. */
declare function ToastPositioner({ className, ...props }: React.ComponentProps<typeof BaseToast.Positioner>): React.JSX.Element;
declare function ToastArrow({ className, children, ...props }: React.ComponentProps<typeof BaseToast.Arrow>): React.JSX.Element;
declare function ToastViewport({ className, ...props }: React.ComponentProps<typeof BaseToast.Viewport>): React.JSX.Element;
/** Re-exported Base UI helpers so demos never need the raw package. */
export declare const useToastManager: typeof BaseToast.useToastManager;
export declare const createToastManager: typeof BaseToast.createToastManager;
export { ToastProvider, ToastViewport, ToastRoot, ToastContent, ToastTitle, ToastDescription, ToastClose, ToastAction, ToastPortal, ToastPositioner, ToastArrow };
