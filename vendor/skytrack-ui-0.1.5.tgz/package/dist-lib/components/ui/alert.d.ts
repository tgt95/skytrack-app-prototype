import * as React from 'react';
import { type VariantProps } from 'class-variance-authority';
export declare const alertVariants: (props?: ({
    variant?: "default" | "destructive" | "info" | "success" | "warning" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type AlertProps = React.ComponentProps<'div'> & VariantProps<typeof alertVariants>;
declare function Alert({ className, variant, role, ...props }: AlertProps): React.JSX.Element;
declare function AlertTitle({ className, ...props }: React.ComponentProps<'h5'>): React.JSX.Element;
declare function AlertDescription({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
declare function AlertAction({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
export { Alert, AlertTitle, AlertDescription, AlertAction };
