import * as React from 'react';
import { Select as BaseSelect } from '@base-ui/react/select';
import { type VariantProps } from 'class-variance-authority';
/** Props of the `Select` root, generic over the value type and `multiple` mode. */
export type SelectRootProps<Value, Multiple extends boolean | undefined = false> = BaseSelect.Root.Props<Value, Multiple>;
declare function Select<Value, Multiple extends boolean | undefined = false>(props: SelectRootProps<Value, Multiple>): React.JSX.Element;
declare function SelectLabel({ className, ...props }: React.ComponentProps<typeof BaseSelect.Label>): React.JSX.Element;
export declare const selectTriggerVariants: (props?: ({
    size?: "default" | "sm" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
type SelectTriggerProps = React.ComponentProps<typeof BaseSelect.Trigger> & VariantProps<typeof selectTriggerVariants>;
declare function SelectTrigger({ className, size, ...props }: SelectTriggerProps): React.JSX.Element;
declare function SelectValue({ className, ...props }: React.ComponentProps<typeof BaseSelect.Value>): React.JSX.Element;
declare function SelectIcon({ className, children, ...props }: React.ComponentProps<typeof BaseSelect.Icon>): React.JSX.Element;
declare function SelectPortal({ className, ...props }: React.ComponentProps<typeof BaseSelect.Portal>): React.JSX.Element;
declare function SelectBackdrop({ className, ...props }: React.ComponentProps<typeof BaseSelect.Backdrop>): React.JSX.Element;
declare function SelectPositioner({ className, side, align, sideOffset, alignItemWithTrigger, ...props }: React.ComponentProps<typeof BaseSelect.Positioner>): React.JSX.Element;
declare function SelectPopup({ className, ...props }: React.ComponentProps<typeof BaseSelect.Popup>): React.JSX.Element;
declare function SelectList({ className, ...props }: React.ComponentProps<typeof BaseSelect.List>): React.JSX.Element;
declare function SelectItem({ className, children, ...props }: React.ComponentProps<typeof BaseSelect.Item>): React.JSX.Element;
declare function SelectItemText({ className, ...props }: React.ComponentProps<typeof BaseSelect.ItemText>): React.JSX.Element;
declare function SelectItemIndicator({ className, children, ...props }: React.ComponentProps<typeof BaseSelect.ItemIndicator>): React.JSX.Element;
declare function SelectArrow({ className, children, ...props }: React.ComponentProps<typeof BaseSelect.Arrow>): React.JSX.Element;
declare function SelectScrollUpArrow({ className, children, ...props }: React.ComponentProps<typeof BaseSelect.ScrollUpArrow>): React.JSX.Element;
declare function SelectScrollDownArrow({ className, children, ...props }: React.ComponentProps<typeof BaseSelect.ScrollDownArrow>): React.JSX.Element;
declare function SelectGroup({ className, ...props }: React.ComponentProps<typeof BaseSelect.Group>): React.JSX.Element;
declare function SelectGroupLabel({ className, ...props }: React.ComponentProps<typeof BaseSelect.GroupLabel>): React.JSX.Element;
declare function SelectSeparator({ className, ...props }: React.ComponentProps<typeof BaseSelect.Separator>): React.JSX.Element;
export { Select, SelectLabel, SelectTrigger, SelectValue, SelectIcon, SelectPortal, SelectBackdrop, SelectPositioner, SelectPopup, SelectList, SelectItem, SelectItemText, SelectItemIndicator, SelectArrow, SelectScrollUpArrow, SelectScrollDownArrow, SelectGroup, SelectGroupLabel, SelectSeparator };
