import * as React from 'react';
import { Combobox as BaseCombobox } from '@base-ui/react/combobox';
import { type VariantProps } from 'class-variance-authority';
/** Props of the `Combobox` root, generic over value type, `multiple` mode and item type. */
export type ComboboxRootProps<Value, Multiple extends boolean | undefined = false, Item = Value> = BaseCombobox.Root.Props<Value, Multiple, Item>;
declare function Combobox<Value, Multiple extends boolean | undefined = false, Item = Value>(props: ComboboxRootProps<Value, Multiple, Item>): React.JSX.Element;
declare function ComboboxLabel({ className, ...props }: React.ComponentProps<typeof BaseCombobox.Label>): React.JSX.Element;
export declare const comboboxInputGroupVariants: (props?: ({
    size?: "default" | "sm" | null | undefined;
    shape?: "chips" | "input" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
type ComboboxInputGroupProps = React.ComponentProps<typeof BaseCombobox.InputGroup> & VariantProps<typeof comboboxInputGroupVariants>;
declare function ComboboxInputGroup({ className, size, shape, ...props }: ComboboxInputGroupProps): React.JSX.Element;
declare function ComboboxInput({ className, ...props }: React.ComponentProps<typeof BaseCombobox.Input>): React.JSX.Element;
declare function ComboboxTrigger({ className, children, ...props }: React.ComponentProps<typeof BaseCombobox.Trigger>): React.JSX.Element;
/** Standalone trigger used by the input-inside-popup pattern. */
declare function ComboboxTriggerButton({ className, size, children, ...props }: React.ComponentProps<typeof BaseCombobox.Trigger> & VariantProps<typeof comboboxInputGroupVariants>): React.JSX.Element;
declare function ComboboxIcon({ className, children, ...props }: React.ComponentProps<typeof BaseCombobox.Icon>): React.JSX.Element;
declare function ComboboxClear({ className, children, ...props }: React.ComponentProps<typeof BaseCombobox.Clear>): React.JSX.Element;
/** Renders the selected label (or a render function). Renders no element of its own. */
declare function ComboboxValue(props: React.ComponentProps<typeof BaseCombobox.Value>): React.JSX.Element;
declare function ComboboxChips({ className, ...props }: React.ComponentProps<typeof BaseCombobox.Chips>): React.JSX.Element;
declare function ComboboxChip({ className, ...props }: React.ComponentProps<typeof BaseCombobox.Chip>): React.JSX.Element;
declare function ComboboxChipRemove({ className, children, ...props }: React.ComponentProps<typeof BaseCombobox.ChipRemove>): React.JSX.Element;
declare function ComboboxPortal({ className, ...props }: React.ComponentProps<typeof BaseCombobox.Portal>): React.JSX.Element;
declare function ComboboxBackdrop({ className, ...props }: React.ComponentProps<typeof BaseCombobox.Backdrop>): React.JSX.Element;
declare function ComboboxPositioner({ className, ...props }: React.ComponentProps<typeof BaseCombobox.Positioner>): React.JSX.Element;
declare function ComboboxPopup({ className, ...props }: React.ComponentProps<typeof BaseCombobox.Popup>): React.JSX.Element;
declare function ComboboxArrow({ className, children, ...props }: React.ComponentProps<typeof BaseCombobox.Arrow>): React.JSX.Element;
declare function ComboboxStatus({ className, ...props }: React.ComponentProps<typeof BaseCombobox.Status>): React.JSX.Element;
declare function ComboboxEmpty({ className, children, ...props }: React.ComponentProps<typeof BaseCombobox.Empty>): React.JSX.Element;
declare function ComboboxList({ className, ...props }: React.ComponentProps<typeof BaseCombobox.List>): React.JSX.Element;
declare function ComboboxRow({ className, ...props }: React.ComponentProps<typeof BaseCombobox.Row>): React.JSX.Element;
declare function ComboboxItem({ className, children, ...props }: React.ComponentProps<typeof BaseCombobox.Item>): React.JSX.Element;
declare function ComboboxItemIndicator({ className, children, ...props }: React.ComponentProps<typeof BaseCombobox.ItemIndicator>): React.JSX.Element;
declare function ComboboxGroup({ className, ...props }: React.ComponentProps<typeof BaseCombobox.Group>): React.JSX.Element;
declare function ComboboxGroupLabel({ className, ...props }: React.ComponentProps<typeof BaseCombobox.GroupLabel>): React.JSX.Element;
declare function ComboboxSeparator({ className, ...props }: React.ComponentProps<typeof BaseCombobox.Separator>): React.JSX.Element;
/** Renders the filtered items of the enclosing group/list. Renders no element of its own. */
declare function ComboboxCollection(props: React.ComponentProps<typeof BaseCombobox.Collection>): React.JSX.Element;
export { Combobox, ComboboxLabel, ComboboxInputGroup, ComboboxInput, ComboboxTrigger, ComboboxTriggerButton, ComboboxIcon, ComboboxClear, ComboboxValue, ComboboxChips, ComboboxChip, ComboboxChipRemove, ComboboxPortal, ComboboxBackdrop, ComboboxPositioner, ComboboxPopup, ComboboxArrow, ComboboxStatus, ComboboxEmpty, ComboboxList, ComboboxRow, ComboboxItem, ComboboxItemIndicator, ComboboxGroup, ComboboxGroupLabel, ComboboxSeparator, ComboboxCollection };
/** Re-exported Base UI helpers so demos never need the raw package. */
export declare const useComboboxFilter: typeof BaseCombobox.useFilter;
export declare const useComboboxFilteredItems: typeof BaseCombobox.useFilteredItems;
export declare const createComboboxItems: typeof BaseCombobox.createItems;
