import * as React from 'react';
import { CheckboxGroup as BaseCheckboxGroup } from '@base-ui/react/checkbox-group';
declare function CheckboxGroup({ className, ...props }: React.ComponentProps<typeof BaseCheckboxGroup>): React.JSX.Element;
export { CheckboxGroup };
