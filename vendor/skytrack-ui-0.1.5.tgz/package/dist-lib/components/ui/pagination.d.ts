import * as React from 'react';
declare function Pagination({ className, ...props }: React.ComponentProps<'nav'>): React.JSX.Element;
declare function PaginationContent({ className, ...props }: React.ComponentProps<'ul'>): React.JSX.Element;
declare function PaginationItem({ className, ...props }: React.ComponentProps<'li'>): React.JSX.Element;
type PaginationLinkProps = React.ComponentProps<'a'> & {
    isActive?: boolean;
    size?: 'default' | 'sm' | 'lg' | 'icon';
};
declare function PaginationLink({ className, isActive, size, ...props }: PaginationLinkProps): React.JSX.Element;
type PaginationDirectionProps = PaginationLinkProps & {
    text?: string;
};
declare function PaginationPrevious({ className, text, ...props }: PaginationDirectionProps): React.JSX.Element;
declare function PaginationNext({ className, text, ...props }: PaginationDirectionProps): React.JSX.Element;
declare function PaginationEllipsis({ className, ...props }: React.ComponentProps<'span'>): React.JSX.Element;
export { Pagination, PaginationContent, PaginationEllipsis, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious };
