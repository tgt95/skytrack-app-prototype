import * as React from 'react';
import { Button as BaseButton } from '@base-ui/react/button';
import { type VariantProps } from 'class-variance-authority';
/** Shared focus ring + disabled styles. Reuse in every interactive component. */
export declare const focusRing = "outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:border-ring";
/** Keep existing button-subpath imports working while shared controls use the common module. */
export { CONTROL_SIZE_CLASSES as controlSizeClasses } from '@/components/ui/control-sizes';
export type { ControlSize } from '@/components/ui/control-sizes';
export declare const buttonVariants: (props?: ({
    variant?: "default" | "destructive" | "ghost" | "link" | "outline" | "secondary" | null | undefined;
    size?: "default" | "icon" | "icon-lg" | "icon-sm" | "icon-xs" | "lg" | "sm" | "xs" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type ButtonProps = React.ComponentProps<typeof BaseButton> & VariantProps<typeof buttonVariants>;
declare function Button({ className, variant, size, ...props }: ButtonProps): React.JSX.Element;
export { Button };
