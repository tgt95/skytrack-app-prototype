import * as React from 'react';
import { Radio } from '@base-ui/react/radio';
import { RadioGroup as BaseRadioGroup } from '@base-ui/react/radio-group';
declare function RadioRoot({ className, children, ...props }: React.ComponentProps<typeof Radio.Root>): React.JSX.Element;
declare function RadioIndicator({ className, ...props }: React.ComponentProps<typeof Radio.Indicator>): React.JSX.Element;
declare function RadioGroup({ className, ...props }: React.ComponentProps<typeof BaseRadioGroup>): React.JSX.Element;
export { RadioRoot, RadioIndicator, RadioGroup };
