import * as React from 'react';
import { type VariantProps } from 'class-variance-authority';
export declare const badgeVariants: (props?: ({
    status?: "default" | "error" | "outline" | "processing" | "secondary" | "success" | "warning" | null | undefined;
    size?: "default" | "sm" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type BadgeProps = React.ComponentProps<'span'> & VariantProps<typeof badgeVariants> & {
    /** Visual variant alias for standalone badges. */
    variant?: 'default' | 'outline';
    /** Count rendered inside the pill. Omit it when using `dot`. */
    count?: React.ReactNode;
    /** A numeric count above this renders as `{maxCount}+`. Default 99. */
    maxCount?: number;
    /** Render a count of 0 instead of hiding the badge. Default false. */
    showZero?: boolean;
    /** Render a 6px status dot instead of the count. Ignores `count` and `size`. */
    dot?: boolean;
    animationPing?: boolean;
};
/**
 * Count / dot / status badge.
 * Two modes: anchor (`<Badge count={n}><Icon/></Badge>`) vs label pill (`<Badge count='text' />`).
 *
 * `className` targets the PILL (the count or dot), never the anchor wrapper — size the
 * anchor through `children`. With no `children` the pill renders standalone (inline, not
 * absolutely positioned); with `children` it is anchored to the child's top-end corner.
 * Any other span props (`id`, `aria-label`, handlers, ...) land on the pill.
 */
declare function Badge({ className, status, variant, size, count, maxCount, showZero, dot, animationPing, children, ...props }: BadgeProps): React.JSX.Element | null;
export { Badge };
