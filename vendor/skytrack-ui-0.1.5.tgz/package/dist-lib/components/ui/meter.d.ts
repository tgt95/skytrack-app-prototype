import * as React from 'react';
import { Meter as BaseMeter } from '@base-ui/react/meter';
declare function Meter({ className, ...props }: React.ComponentProps<typeof BaseMeter.Root>): React.JSX.Element;
declare function MeterLabel({ className, ...props }: React.ComponentProps<typeof BaseMeter.Label>): React.JSX.Element;
declare function MeterValue({ className, ...props }: React.ComponentProps<typeof BaseMeter.Value>): React.JSX.Element;
declare function MeterTrack({ className, ...props }: React.ComponentProps<typeof BaseMeter.Track>): React.JSX.Element;
declare function MeterIndicator({ className, ...props }: React.ComponentProps<typeof BaseMeter.Indicator>): React.JSX.Element;
export { Meter, MeterLabel, MeterValue, MeterTrack, MeterIndicator };
