import * as React from 'react';
import { type VariantProps } from 'class-variance-authority';
import { type ButtonProps } from '@/components/ui/button';
export type AttachmentState = 'idle' | 'uploading' | 'processing' | 'error' | 'done';
export type AttachmentSize = 'default' | 'sm' | 'xs';
export type AttachmentOrientation = 'horizontal' | 'vertical';
declare const attachmentVariants: (props?: ({
    size?: "default" | "sm" | "xs" | null | undefined;
    orientation?: "horizontal" | "vertical" | null | undefined;
    state?: "done" | "error" | "idle" | "processing" | "uploading" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type AttachmentProps = React.ComponentProps<'div'> & VariantProps<typeof attachmentVariants> & {
    state?: AttachmentState;
};
declare function Attachment({ className, size, orientation, state, ...props }: AttachmentProps): React.JSX.Element;
export type AttachmentMediaProps = React.ComponentProps<'div'> & {
    variant?: 'icon' | 'image';
};
declare function AttachmentMedia({ variant, className, ...props }: AttachmentMediaProps): React.JSX.Element;
declare function AttachmentContent({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
declare function AttachmentTitle({ className, ...props }: React.ComponentProps<'p'>): React.JSX.Element;
declare function AttachmentDescription({ className, ...props }: React.ComponentProps<'p'>): React.JSX.Element;
declare function AttachmentActions({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
type AttachmentActionProps = Omit<ButtonProps, 'size'> & {
    size?: ButtonProps['size'];
};
declare function AttachmentAction({ className, size, variant, ...props }: AttachmentActionProps): React.JSX.Element;
export type AttachmentTriggerProps = React.ComponentProps<'button'> & {
    render?: React.ReactElement;
};
declare function AttachmentTrigger({ className, render, ...props }: AttachmentTriggerProps): React.JSX.Element;
declare function AttachmentGroup({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
export { Attachment, AttachmentAction, AttachmentActions, AttachmentContent, AttachmentDescription, AttachmentGroup, AttachmentMedia, AttachmentTitle, AttachmentTrigger };
