import * as React from 'react';
import { Collapsible as BaseCollapsible } from '@base-ui/react/collapsible';
declare function Collapsible({ className, ...props }: React.ComponentProps<typeof BaseCollapsible.Root>): React.JSX.Element;
declare function CollapsibleTrigger({ className, ...props }: React.ComponentProps<typeof BaseCollapsible.Trigger>): React.JSX.Element;
declare function CollapsiblePanel({ className, ...props }: React.ComponentProps<typeof BaseCollapsible.Panel>): React.JSX.Element;
export { Collapsible, CollapsibleTrigger, CollapsiblePanel };
