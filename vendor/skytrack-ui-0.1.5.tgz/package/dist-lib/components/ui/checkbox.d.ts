import * as React from 'react';
import { Checkbox } from '@base-ui/react/checkbox';
declare function CheckboxRoot({ className, children, ...props }: React.ComponentProps<typeof Checkbox.Root>): React.JSX.Element;
declare function CheckboxIndicator({ className, children, ...props }: React.ComponentProps<typeof Checkbox.Indicator>): React.JSX.Element;
export { CheckboxRoot, CheckboxIndicator };
