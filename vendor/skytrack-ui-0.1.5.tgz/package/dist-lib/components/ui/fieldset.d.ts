import * as React from 'react';
import { Fieldset } from '@base-ui/react/fieldset';
declare function FieldsetRoot({ className, ...props }: React.ComponentProps<typeof Fieldset.Root>): React.JSX.Element;
declare function FieldsetLegend({ className, ...props }: React.ComponentProps<typeof Fieldset.Legend>): React.JSX.Element;
export { FieldsetRoot, FieldsetLegend };
