import * as React from 'react';
import { type VariantProps } from 'class-variance-authority';
import { type ButtonProps } from '@/components/ui/button';
type CodeBlockSize = 'default' | 'sm' | 'xs';
declare const codeBlockVariants: (props?: ({
    variant?: "default" | "destructive" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type CodeBlockProps = React.ComponentProps<'div'> & VariantProps<typeof codeBlockVariants> & {
    size?: CodeBlockSize;
};
declare function CodeBlock({ className, size, variant, children, ...props }: CodeBlockProps): React.JSX.Element;
declare function CodeBlockHeader({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
declare function CodeBlockTitle({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
declare function CodeBlockActions({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
export type CodeBlockCopyButtonProps = Omit<ButtonProps, 'children'> & {
    value: string;
    copyLabel?: string;
    copiedLabel?: string;
    copyFailedLabel?: string;
};
declare function CodeBlockCopyButton({ value, className, onClick, copyLabel, copiedLabel, copyFailedLabel, variant, size, ...props }: CodeBlockCopyButtonProps): React.JSX.Element;
export type CodeBlockContentProps = Omit<React.ComponentProps<'pre'>, 'children'> & {
    children?: React.ReactNode;
    wrap?: boolean;
    lineNumbers?: boolean;
    startLine?: number;
};
declare function CodeBlockContent({ children, wrap, lineNumbers, startLine, tabIndex, style, className, ...props }: CodeBlockContentProps): React.JSX.Element;
export type CodeBlockLineProps = React.ComponentProps<'span'> & {
    variant?: 'default' | 'added' | 'removed' | 'highlighted';
    'data-line-number'?: string;
};
declare function CodeBlockLine({ variant, className, children, ...props }: CodeBlockLineProps): React.JSX.Element;
declare function CodeBlockFooter({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
export declare function useHighlightedCode(code: string, language: string): React.ReactNode[];
export { CodeBlock, CodeBlockActions, CodeBlockContent, CodeBlockCopyButton, CodeBlockFooter, CodeBlockHeader, CodeBlockLine, CodeBlockTitle };
