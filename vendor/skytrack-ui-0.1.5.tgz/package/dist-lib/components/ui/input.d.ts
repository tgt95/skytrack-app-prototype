import * as React from 'react';
import { Input as BaseInput } from '@base-ui/react/input';
type InputAdornmentProps = React.ComponentProps<'span'> & {
    position: 'start' | 'end';
};
/**
 * Sits in flow beside the input, the way MUI's `InputAdornment` does: the input is
 * `flex-1 min-w-0` so it shrinks and scrolls its text, and the adornment is `shrink-0`.
 * Nothing is absolutely positioned and no fixed padding is reserved, so a wide
 * adornment (a currency suffix, a long unit) never overlaps the value.
 */
declare function InputAdornment({ className, position, ...props }: InputAdornmentProps): React.JSX.Element;
type InputProps = React.ComponentProps<typeof BaseInput> & {
    startAdornment?: React.ReactNode;
    endAdornment?: React.ReactNode;
};
declare function Input({ className, startAdornment, endAdornment, ...props }: InputProps): React.JSX.Element;
export { Input, InputAdornment };
export type { InputProps, InputAdornmentProps };
