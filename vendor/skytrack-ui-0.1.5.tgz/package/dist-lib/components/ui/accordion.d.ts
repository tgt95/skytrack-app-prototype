import * as React from 'react';
import { Accordion as BaseAccordion } from '@base-ui/react/accordion';
declare function Accordion({ className, ...props }: React.ComponentProps<typeof BaseAccordion.Root>): React.JSX.Element;
declare function AccordionItem({ className, ...props }: React.ComponentProps<typeof BaseAccordion.Item>): React.JSX.Element;
declare function AccordionHeader({ className, ...props }: React.ComponentProps<typeof BaseAccordion.Header>): React.JSX.Element;
declare function AccordionTrigger({ className, children, ...props }: React.ComponentProps<typeof BaseAccordion.Trigger>): React.JSX.Element;
declare function AccordionContent(props: React.ComponentProps<typeof BaseAccordion.Panel>): React.JSX.Element;
declare function AccordionPanel(props: React.ComponentProps<typeof BaseAccordion.Panel>): React.JSX.Element;
export { Accordion, AccordionItem, AccordionHeader, AccordionTrigger, AccordionContent, AccordionPanel };
