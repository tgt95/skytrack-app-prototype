import * as React from 'react';
import { Accordion as BaseAccordion } from '@base-ui/react/accordion';
declare function Accordion({ className, ...props }: React.ComponentProps<typeof BaseAccordion.Root>): React.JSX.Element;
declare function AccordionItem({ className, ...props }: React.ComponentProps<typeof BaseAccordion.Item>): React.JSX.Element;
declare function AccordionHeader({ className, ...props }: React.ComponentProps<typeof BaseAccordion.Header>): React.JSX.Element;
type AccordionTriggerProps = React.ComponentProps<typeof BaseAccordion.Trigger> & {
    variant?: 'default' | 'compact';
};
declare function AccordionTrigger({ className, children, variant, ...props }: AccordionTriggerProps): React.JSX.Element;
declare function AccordionPanel({ className, ...props }: React.ComponentProps<typeof BaseAccordion.Panel>): React.JSX.Element;
export { Accordion, AccordionItem, AccordionHeader, AccordionTrigger, AccordionPanel };
