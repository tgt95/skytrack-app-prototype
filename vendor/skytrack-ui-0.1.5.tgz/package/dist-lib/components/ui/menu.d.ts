import * as React from 'react';
import { Menu as BaseMenu } from '@base-ui/react/menu';
import { type VariantProps } from 'class-variance-authority';
/**
 * Shared row styling for every menu item part (Item, LinkItem, CheckboxItem,
 * RadioItem, SubmenuTrigger). `variant="destructive"` is the destructive item variant.
 */
export declare const menuItemVariants: (props?: ({
    variant?: "default" | "destructive" | null | undefined;
    inset?: boolean | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type MenuItemVariantProps = VariantProps<typeof menuItemVariants>;
/**
 * `Menu` and `MenuTrigger` keep Base UI's `Payload` generic so that
 * `Menu.createHandle<Payload>()` + the payload render function stay typed.
 */
declare function Menu<Payload = unknown>(props: BaseMenu.Root.Props<Payload>): React.JSX.Element;
declare function MenuTrigger<Payload = unknown>({ className, render, ...props }: BaseMenu.Trigger.Props<Payload>): React.JSX.Element;
declare function MenuPortal({ className, ...props }: React.ComponentProps<typeof BaseMenu.Portal>): React.JSX.Element;
declare function MenuBackdrop({ className, ...props }: React.ComponentProps<typeof BaseMenu.Backdrop>): React.JSX.Element;
declare function MenuPositioner({ className, ...props }: React.ComponentProps<typeof BaseMenu.Positioner>): React.JSX.Element;
declare function MenuPopup({ className, ...props }: React.ComponentProps<typeof BaseMenu.Popup>): React.JSX.Element;
declare function MenuArrow({ className, ...props }: React.ComponentProps<typeof BaseMenu.Arrow>): React.JSX.Element;
declare function MenuViewport({ className, ...props }: React.ComponentProps<typeof BaseMenu.Viewport>): React.JSX.Element;
declare function MenuGroup({ className, ...props }: React.ComponentProps<typeof BaseMenu.Group>): React.JSX.Element;
declare function MenuGroupLabel({ className, ...props }: React.ComponentProps<typeof BaseMenu.GroupLabel>): React.JSX.Element;
declare function MenuSeparator({ className, ...props }: React.ComponentProps<typeof BaseMenu.Separator>): React.JSX.Element;
type MenuItemProps = React.ComponentProps<typeof BaseMenu.Item> & MenuItemVariantProps;
declare function MenuItem({ className, variant, inset, ...props }: MenuItemProps): React.JSX.Element;
type MenuLinkItemProps = React.ComponentProps<typeof BaseMenu.LinkItem> & MenuItemVariantProps;
declare function MenuLinkItem({ className, variant, inset, ...props }: MenuLinkItemProps): React.JSX.Element;
declare function MenuSubmenuRoot(props: React.ComponentProps<typeof BaseMenu.SubmenuRoot>): React.JSX.Element;
type MenuSubmenuTriggerProps = React.ComponentProps<typeof BaseMenu.SubmenuTrigger> & MenuItemVariantProps;
declare function MenuSubmenuTrigger({ className, children, variant, inset, ...props }: MenuSubmenuTriggerProps): React.JSX.Element;
declare function MenuRadioGroup({ className, ...props }: React.ComponentProps<typeof BaseMenu.RadioGroup>): React.JSX.Element;
type MenuRadioItemProps = React.ComponentProps<typeof BaseMenu.RadioItem> & MenuItemVariantProps;
declare function MenuRadioItem({ className, variant, inset, ...props }: MenuRadioItemProps): React.JSX.Element;
declare function MenuRadioItemIndicator({ className, children, ...props }: React.ComponentProps<typeof BaseMenu.RadioItemIndicator>): React.JSX.Element;
type MenuCheckboxItemProps = React.ComponentProps<typeof BaseMenu.CheckboxItem> & MenuItemVariantProps;
declare function MenuCheckboxItem({ className, variant, inset, ...props }: MenuCheckboxItemProps): React.JSX.Element;
declare function MenuCheckboxItemIndicator({ className, children, ...props }: React.ComponentProps<typeof BaseMenu.CheckboxItemIndicator>): React.JSX.Element;
declare function MenuShortcut({ className, ...props }: React.ComponentProps<'span'>): React.JSX.Element;
/** Base UI helper for detached triggers (`Menu.createHandle()` in the docs). */
declare function createMenuHandle<Payload = unknown>(): BaseMenu.Handle<Payload>;
type MenuRootHandle<Payload = unknown> = BaseMenu.Handle<Payload>;
export { Menu, MenuTrigger, MenuPortal, MenuBackdrop, MenuPositioner, MenuPopup, MenuArrow, MenuViewport, MenuGroup, MenuGroupLabel, MenuSeparator, MenuItem, MenuLinkItem, MenuSubmenuRoot, MenuSubmenuTrigger, MenuRadioGroup, MenuRadioItem, MenuRadioItemIndicator, MenuCheckboxItem, MenuCheckboxItemIndicator, MenuShortcut, createMenuHandle };
export type { MenuRootHandle };
