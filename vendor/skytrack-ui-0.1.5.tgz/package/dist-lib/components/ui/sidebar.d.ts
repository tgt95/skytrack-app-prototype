import * as React from 'react';
import { Button as BaseButton } from '@base-ui/react/button';
export declare const SIDEBAR_WIDTH = "16rem";
export declare const SIDEBAR_WIDTH_ICON = "3rem";
export declare const SIDEBAR_WIDTH_MOBILE = "18rem";
export declare const SIDEBAR_KEYBOARD_SHORTCUT = "b";
type SidebarState = 'expanded' | 'collapsed';
type SidebarSide = 'left' | 'right';
type SidebarVariant = 'sidebar' | 'floating' | 'inset';
type SidebarCollapsible = 'offcanvas' | 'icon' | 'none';
type SidebarContextValue = {
    state: SidebarState;
    open: boolean;
    setOpen: (open: boolean) => void;
    openMobile: boolean;
    setOpenMobile: (open: boolean) => void;
    isMobile: boolean;
    toggleSidebar: () => void;
};
export declare function useSidebar(): SidebarContextValue;
export type SidebarProviderProps = React.ComponentProps<'div'> & {
    defaultOpen?: boolean;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
};
declare function SidebarProvider({ defaultOpen, open: openProp, onOpenChange, className, style, children, ...props }: SidebarProviderProps): React.JSX.Element;
export type SidebarProps = Omit<React.ComponentProps<'aside'>, 'ref'> & {
    side?: SidebarSide;
    variant?: SidebarVariant;
    collapsible?: SidebarCollapsible;
    /** Adds classes to the desktop width spacer. Useful for previews in bounded containers. */
    gapClassName?: string;
    /** Adds classes to the desktop positioning wrapper. */
    containerClassName?: string;
};
declare function Sidebar({ side, variant, collapsible, gapClassName, containerClassName, className, children, dir, style, ...props }: SidebarProps): React.JSX.Element;
declare function SidebarTrigger({ className, onClick, ...props }: React.ComponentProps<typeof BaseButton>): React.JSX.Element;
declare function SidebarRail({ className, ...props }: React.ComponentProps<'button'>): React.JSX.Element;
declare function SidebarInset({ className, ...props }: React.ComponentProps<'main'>): React.JSX.Element;
declare function SidebarHeader({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
declare function SidebarFooter({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
declare function SidebarContent({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
declare function SidebarGroup({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
type SidebarGroupLabelProps = Pick<React.ComponentProps<'div'>, 'children' | 'className' | 'id' | 'title' | 'aria-label' | 'aria-labelledby'> & {
    render?: React.ReactElement;
};
declare function SidebarGroupLabel({ className, render, children, ...props }: SidebarGroupLabelProps): React.JSX.Element;
declare function SidebarGroupAction({ className, ...props }: React.ComponentProps<typeof BaseButton>): React.JSX.Element;
declare function SidebarGroupContent({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
declare function SidebarMenu({ className, ...props }: React.ComponentProps<'ul'>): React.JSX.Element;
declare function SidebarMenuItem({ className, ...props }: React.ComponentProps<'li'>): React.JSX.Element;
export type SidebarMenuButtonProps = React.ComponentProps<typeof BaseButton> & {
    isActive?: boolean;
    size?: 'default' | 'sm' | 'lg';
    variant?: 'default' | 'outline';
    tooltip?: string;
};
declare function SidebarMenuButton({ className, isActive, size, variant, tooltip, ...props }: SidebarMenuButtonProps): React.JSX.Element;
declare function SidebarMenuAction({ className, ...props }: React.ComponentProps<typeof BaseButton>): React.JSX.Element;
type SidebarMenuBadgeProps = React.ComponentProps<'span'> & {
    render?: React.ReactElement;
};
declare function SidebarMenuBadge({ className, render, children, ...props }: SidebarMenuBadgeProps): React.JSX.Element;
declare function SidebarMenuSkeleton({ className, showIcon, ...props }: React.ComponentProps<'div'> & {
    showIcon?: boolean;
}): React.JSX.Element;
declare function SidebarMenuSub({ className, ...props }: React.ComponentProps<'ul'>): React.JSX.Element;
declare function SidebarMenuSubItem({ className, ...props }: React.ComponentProps<'li'>): React.JSX.Element;
export type SidebarMenuSubButtonProps = React.ComponentProps<typeof BaseButton> & {
    isActive?: boolean;
    size?: 'sm' | 'md';
};
declare function SidebarMenuSubButton({ className, isActive, size, ...props }: SidebarMenuSubButtonProps): React.JSX.Element;
export { SidebarProvider, Sidebar, SidebarTrigger, SidebarRail, SidebarInset, SidebarHeader, SidebarFooter, SidebarContent, SidebarGroup, SidebarGroupLabel, SidebarGroupAction, SidebarGroupContent, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarMenuAction, SidebarMenuBadge, SidebarMenuSkeleton, SidebarMenuSub, SidebarMenuSubItem, SidebarMenuSubButton };
