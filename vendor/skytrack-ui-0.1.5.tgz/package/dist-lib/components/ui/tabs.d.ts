import * as React from 'react';
import { Tabs as BaseTabs } from '@base-ui/react/tabs';
import { type VariantProps } from 'class-variance-authority';
type TabsRootProps = React.ComponentProps<typeof BaseTabs.Root>;
declare function Tabs({ className, orientation, ...props }: TabsRootProps): React.JSX.Element;
declare const tabsListVariants: (props?: ({
    variant?: "filled" | "line" | "pill" | null | undefined;
    width?: "full" | "hug" | null | undefined;
    size?: "default" | "lg" | "sm" | "xs" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type TabsListVariantProps = VariantProps<typeof tabsListVariants>;
type TabsSize = 'xs' | 'sm' | 'default' | 'lg';
type TabsIndicatorSide = 'left' | 'right';
type TabsListProps = React.ComponentProps<typeof BaseTabs.List> & TabsListVariantProps & {
    indicatorSide?: TabsIndicatorSide;
    size?: TabsSize;
};
declare function TabsList({ children, className, variant, indicatorSide, size, width, ...props }: TabsListProps): React.JSX.Element;
declare const tabsTabVariants: (props?: ({
    variant?: "filled" | "line" | "pill" | null | undefined;
    size?: "default" | "lg" | "sm" | "xs" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type TabsTabVariantProps = VariantProps<typeof tabsTabVariants>;
declare function TabsTab({ className, style, variant, size, ...props }: React.ComponentProps<typeof BaseTabs.Tab> & TabsTabVariantProps): React.JSX.Element;
declare const tabsIndicatorVariants: (props?: ({
    variant?: "line" | "pill" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type TabsIndicatorVariantProps = VariantProps<typeof tabsIndicatorVariants>;
declare function TabsIndicator({ className, variant, ...props }: React.ComponentProps<typeof BaseTabs.Indicator> & TabsIndicatorVariantProps): React.JSX.Element;
declare function TabsPanel({ className, ...props }: React.ComponentProps<typeof BaseTabs.Panel>): React.JSX.Element;
/** shadcn-style aliases. */
declare const TabsTrigger: typeof TabsTab;
declare const TabsContent: typeof TabsPanel;
export { Tabs, TabsList, TabsTab, TabsIndicator, TabsPanel, TabsTrigger, TabsContent };
