import * as React from 'react';
import { Tabs as BaseTabs } from '@base-ui/react/tabs';
import { type VariantProps } from 'class-variance-authority';
declare function Tabs({ className, ...props }: React.ComponentProps<typeof BaseTabs.Root>): React.JSX.Element;
declare const tabsListVariants: (props?: ({
    variant?: "filled" | "outlined" | "standard" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type TabsListVariantProps = VariantProps<typeof tabsListVariants>;
declare function TabsList({ className, variant, ...props }: React.ComponentProps<typeof BaseTabs.List> & TabsListVariantProps): React.JSX.Element;
declare const tabsTabVariants: (props?: ({
    variant?: "filled" | "outlined" | "standard" | null | undefined;
    size?: "default" | "lg" | "sm" | "xs" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type TabsTabVariantProps = VariantProps<typeof tabsTabVariants>;
declare function TabsTab({ className, variant, size, ...props }: React.ComponentProps<typeof BaseTabs.Tab> & TabsTabVariantProps): React.JSX.Element;
declare const tabsIndicatorVariants: (props?: ({
    variant?: "pill" | "underline" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type TabsIndicatorVariantProps = VariantProps<typeof tabsIndicatorVariants>;
declare function TabsIndicator({ className, variant, ...props }: React.ComponentProps<typeof BaseTabs.Indicator> & TabsIndicatorVariantProps): React.JSX.Element;
declare function TabsPanel({ className, ...props }: React.ComponentProps<typeof BaseTabs.Panel>): React.JSX.Element;
/** shadcn-style aliases. */
declare const TabsTrigger: typeof TabsTab;
declare const TabsContent: typeof TabsPanel;
export { Tabs, TabsList, TabsTab, TabsIndicator, TabsPanel, TabsTrigger, TabsContent };
