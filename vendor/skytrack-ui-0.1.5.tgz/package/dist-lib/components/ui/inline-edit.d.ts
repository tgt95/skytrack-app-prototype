import * as React from 'react';
import { useRender } from '@base-ui/react/use-render';
export type InlineEditRootProps = Omit<React.ComponentProps<'div'>, 'defaultValue' | 'onChange'> & {
    value?: string;
    defaultValue?: string;
    onValueChange?: (value: string) => void;
    editing?: boolean;
    defaultEditing?: boolean;
    onEditingChange?: (editing: boolean) => void;
    disabled?: boolean;
    label?: string;
};
declare function InlineEdit({ children, className, value: valueProp, defaultValue, onValueChange, editing: editingProp, defaultEditing, onEditingChange, disabled, label, ...props }: InlineEditRootProps): React.JSX.Element;
export type InlineEditTriggerProps = useRender.ComponentProps<'button', {
    editing: boolean;
    value: string;
}>;
declare function InlineEditTrigger({ children, disabled, onClick, render, ...props }: InlineEditTriggerProps): React.ReactElement<unknown, string | React.JSXElementConstructor<any>>;
export type InlineEditInputProps = Omit<useRender.ComponentProps<'textarea'>, 'value' | 'defaultValue'>;
declare function InlineEditInput({ className, id, onBlur, onChange, onKeyDown, ref, render, rows, ...props }: InlineEditInputProps): React.ReactElement<unknown, string | React.JSXElementConstructor<any>> | null;
export { InlineEdit, InlineEditTrigger, InlineEditInput };
