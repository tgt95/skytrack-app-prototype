import * as React from 'react';
import { Drawer as BaseDrawer } from '@base-ui/react/drawer';
import { type VariantProps } from 'class-variance-authority';
import { buttonVariants } from '@/components/ui/button';
/** Shared variant/size props for `DrawerTrigger` and `DrawerClose`. */
export type DrawerButtonProps = VariantProps<typeof buttonVariants>;
/**
 * Drawer — a panel that slides in from the edge of the screen, with
 * swipe-to-dismiss gestures. `Drawer.Root`, `Drawer.Provider` and
 * `Drawer.VirtualKeyboardProvider` render no element of their own, so they are
 * re-exported as-is.
 */
declare const Drawer: typeof BaseDrawer.Root;
declare const DrawerProvider: typeof BaseDrawer.Provider;
declare const DrawerVirtualKeyboardProvider: typeof BaseDrawer.VirtualKeyboardProvider;
/** Creates a handle that lets detached triggers control this drawer. */
declare const createHandle: typeof BaseDrawer.createHandle;
type DrawerChangeEventDetails = Parameters<NonNullable<React.ComponentProps<typeof BaseDrawer.Root>['onOpenChange']>>[1];
type DrawerSnapPoint = NonNullable<React.ComponentProps<typeof BaseDrawer.Root>['snapPoints']>[number];
/**
 * Side variants for the positioning container and the panel itself.
 * Keep `side` in sync with `swipeDirection` on `Drawer.Root`.
 */
export declare const drawerSideVariants: (props?: ({
    side?: "bottom" | "left" | "right" | "top" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export declare const drawerPopupVariants: (props?: ({
    side?: "bottom" | "left" | "right" | "top" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type DrawerSideProps = VariantProps<typeof drawerSideVariants>;
declare function DrawerTrigger({ className, variant, size, ...props }: React.ComponentProps<typeof BaseDrawer.Trigger> & DrawerButtonProps): React.JSX.Element;
declare function DrawerSwipeArea({ className, ...props }: React.ComponentProps<typeof BaseDrawer.SwipeArea>): React.JSX.Element;
declare function DrawerPortal({ className, ...props }: React.ComponentProps<typeof BaseDrawer.Portal>): React.JSX.Element;
declare function DrawerBackdrop({ className, ...props }: React.ComponentProps<typeof BaseDrawer.Backdrop>): React.JSX.Element;
declare function DrawerViewport({ className, side, ...props }: React.ComponentProps<typeof BaseDrawer.Viewport> & DrawerSideProps): React.JSX.Element;
declare function DrawerPopup({ className, side, ...props }: React.ComponentProps<typeof BaseDrawer.Popup> & DrawerSideProps): React.JSX.Element;
declare function DrawerContent({ className, ...props }: React.ComponentProps<typeof BaseDrawer.Content>): React.JSX.Element;
declare function DrawerTitle({ className, ...props }: React.ComponentProps<typeof BaseDrawer.Title>): React.JSX.Element;
declare function DrawerDescription({ className, ...props }: React.ComponentProps<typeof BaseDrawer.Description>): React.JSX.Element;
declare function DrawerClose({ className, variant, size, ...props }: React.ComponentProps<typeof BaseDrawer.Close> & DrawerButtonProps): React.JSX.Element;
declare function DrawerIndentBackground({ className, ...props }: React.ComponentProps<typeof BaseDrawer.IndentBackground>): React.JSX.Element;
declare function DrawerIndent({ className, ...props }: React.ComponentProps<typeof BaseDrawer.Indent>): React.JSX.Element;
export { Drawer, DrawerProvider, DrawerVirtualKeyboardProvider, createHandle, DrawerTrigger, DrawerSwipeArea, DrawerPortal, DrawerBackdrop, DrawerViewport, DrawerPopup, DrawerContent, DrawerTitle, DrawerDescription, DrawerClose, DrawerIndent, DrawerIndentBackground };
export type { DrawerChangeEventDetails, DrawerSnapPoint };
