import * as React from 'react';
import { Avatar as BaseAvatar } from '@base-ui/react/avatar';
declare function Avatar({ className, ...props }: React.ComponentProps<typeof BaseAvatar.Root>): React.JSX.Element;
declare function AvatarImage({ className, ...props }: React.ComponentProps<typeof BaseAvatar.Image>): React.JSX.Element;
declare function AvatarFallback({ className, ...props }: React.ComponentProps<typeof BaseAvatar.Fallback>): React.JSX.Element;
export { Avatar, AvatarImage, AvatarFallback };
