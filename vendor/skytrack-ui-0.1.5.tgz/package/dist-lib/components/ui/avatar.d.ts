import * as React from 'react';
import { Avatar as BaseAvatar } from '@base-ui/react/avatar';
import type { ControlSize } from '@/components/ui/control-sizes';
type AvatarProps = React.ComponentProps<typeof BaseAvatar.Root> & {
    size?: ControlSize;
};
declare function Avatar({ className, size, ...props }: AvatarProps): React.JSX.Element;
declare function AvatarImage({ className, ...props }: React.ComponentProps<typeof BaseAvatar.Image>): React.JSX.Element;
declare function AvatarFallback({ className, ...props }: React.ComponentProps<typeof BaseAvatar.Fallback>): React.JSX.Element;
export { Avatar, AvatarImage, AvatarFallback };
