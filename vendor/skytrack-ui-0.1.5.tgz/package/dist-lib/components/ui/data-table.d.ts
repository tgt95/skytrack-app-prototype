import * as React from 'react';
import { type ColumnDef, type RowData } from '@tanstack/react-table';
declare const dataTableFeatures: {
    columnFilteringFeature: import("@tanstack/table-core").TableFeature;
    globalFilteringFeature: import("@tanstack/table-core").TableFeature;
    filteredRowModel: (table: import("@tanstack/table-core").Table<any, any>) => () => import("@tanstack/table-core").RowModel<any, any>;
    rowSortingFeature: import("@tanstack/table-core").TableFeature;
    sortedRowModel: (table: import("@tanstack/table-core").Table<any, any>) => () => import("@tanstack/table-core").RowModel<any, any>;
    rowPaginationFeature: import("@tanstack/table-core").TableFeature;
    paginatedRowModel: (table: import("@tanstack/table-core").Table<any, any>) => () => import("@tanstack/table-core").RowModel<any, any>;
    columnVisibilityFeature: import("@tanstack/table-core").TableFeature;
    rowSelectionFeature: import("@tanstack/table-core").TableFeature;
    filterFns: {
        includesString: import("@tanstack/table-core").CreatedFilterFn<any, any>;
    };
    sortFns: {
        alphanumeric: import("@tanstack/table-core").CreatedSortFn<any, any>;
    };
};
type DataTableAlignment = 'left' | 'center' | 'right';
type DataTableColumnMeta = {
    align?: DataTableAlignment;
};
export type DataTableColumnDef<TData extends RowData> = ColumnDef<typeof dataTableFeatures, TData, any> & {
    meta?: DataTableColumnMeta;
};
export type DataTableProps<TData extends RowData> = {
    columns: DataTableColumnDef<TData>[];
    data: TData[];
    enableRowSelection?: boolean;
    getRowId?: (originalRow: TData, index: number) => string;
    pageSize?: number;
    searchPlaceholder?: string;
    emptyMessage?: React.ReactNode;
    className?: string;
};
declare function DataTable<TData extends RowData>({ columns, data, enableRowSelection, getRowId, pageSize, searchPlaceholder, emptyMessage, className }: DataTableProps<TData>): React.JSX.Element;
export { DataTable };
