import * as React from 'react';
import { OTPField as BaseOTPField } from '@base-ui/react/otp-field';
declare function OTPField({ className, ...props }: React.ComponentProps<typeof BaseOTPField.Root>): React.JSX.Element;
declare function OTPFieldInput({ className, ...props }: React.ComponentProps<typeof BaseOTPField.Input>): React.JSX.Element;
declare function OTPFieldSeparator({ className, ...props }: React.ComponentProps<typeof BaseOTPField.Separator>): React.JSX.Element;
export { OTPField, OTPFieldInput, OTPFieldSeparator };
