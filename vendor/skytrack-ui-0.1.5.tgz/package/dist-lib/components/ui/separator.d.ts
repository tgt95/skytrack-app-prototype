import * as React from 'react';
import { Separator as BaseSeparator } from '@base-ui/react/separator';
declare function Separator({ className, orientation, ...props }: React.ComponentProps<typeof BaseSeparator>): React.JSX.Element;
export { Separator };
