import * as React from 'react';
import { ContextMenu as BaseContextMenu } from '@base-ui/react/context-menu';
import { type VariantProps } from 'class-variance-authority';
/**
 * Context menus reuse the Menu row styling so a right-clicked popup and a
 * clicked popup look identical. `variant="destructive"` is the destructive item variant.
 */
export declare const contextMenuItemVariants: (props?: ({
    variant?: "default" | "destructive" | null | undefined;
    inset?: boolean | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type ContextMenuItemVariantProps = VariantProps<typeof contextMenuItemVariants>;
declare function ContextMenu(props: React.ComponentProps<typeof BaseContextMenu.Root>): React.JSX.Element;
declare function ContextMenuTrigger({ className, ...props }: React.ComponentProps<typeof BaseContextMenu.Trigger>): React.JSX.Element;
declare function ContextMenuPortal({ className, ...props }: React.ComponentProps<typeof BaseContextMenu.Portal>): React.JSX.Element;
declare function ContextMenuBackdrop({ className, ...props }: React.ComponentProps<typeof BaseContextMenu.Backdrop>): React.JSX.Element;
declare function ContextMenuPositioner({ className, ...props }: React.ComponentProps<typeof BaseContextMenu.Positioner>): React.JSX.Element;
declare function ContextMenuPopup({ className, ...props }: React.ComponentProps<typeof BaseContextMenu.Popup>): React.JSX.Element;
declare function ContextMenuArrow({ className, ...props }: React.ComponentProps<typeof BaseContextMenu.Arrow>): React.JSX.Element;
declare function ContextMenuGroup({ className, ...props }: React.ComponentProps<typeof BaseContextMenu.Group>): React.JSX.Element;
declare function ContextMenuGroupLabel({ className, ...props }: React.ComponentProps<typeof BaseContextMenu.GroupLabel>): React.JSX.Element;
declare function ContextMenuSeparator({ className, ...props }: React.ComponentProps<typeof BaseContextMenu.Separator>): React.JSX.Element;
type ContextMenuItemProps = React.ComponentProps<typeof BaseContextMenu.Item> & ContextMenuItemVariantProps;
declare function ContextMenuItem({ className, variant, inset, ...props }: ContextMenuItemProps): React.JSX.Element;
type ContextMenuLinkItemProps = React.ComponentProps<typeof BaseContextMenu.LinkItem> & ContextMenuItemVariantProps;
declare function ContextMenuLinkItem({ className, variant, inset, ...props }: ContextMenuLinkItemProps): React.JSX.Element;
declare function ContextMenuSubmenuRoot(props: React.ComponentProps<typeof BaseContextMenu.SubmenuRoot>): React.JSX.Element;
type ContextMenuSubmenuTriggerProps = React.ComponentProps<typeof BaseContextMenu.SubmenuTrigger> & ContextMenuItemVariantProps;
declare function ContextMenuSubmenuTrigger({ className, children, variant, inset, ...props }: ContextMenuSubmenuTriggerProps): React.JSX.Element;
declare function ContextMenuRadioGroup({ className, ...props }: React.ComponentProps<typeof BaseContextMenu.RadioGroup>): React.JSX.Element;
type ContextMenuRadioItemProps = React.ComponentProps<typeof BaseContextMenu.RadioItem> & ContextMenuItemVariantProps;
declare function ContextMenuRadioItem({ className, variant, inset, ...props }: ContextMenuRadioItemProps): React.JSX.Element;
declare function ContextMenuRadioItemIndicator({ className, children, ...props }: React.ComponentProps<typeof BaseContextMenu.RadioItemIndicator>): React.JSX.Element;
type ContextMenuCheckboxItemProps = React.ComponentProps<typeof BaseContextMenu.CheckboxItem> & ContextMenuItemVariantProps;
declare function ContextMenuCheckboxItem({ className, variant, inset, ...props }: ContextMenuCheckboxItemProps): React.JSX.Element;
declare function ContextMenuCheckboxItemIndicator({ className, children, ...props }: React.ComponentProps<typeof BaseContextMenu.CheckboxItemIndicator>): React.JSX.Element;
declare function ContextMenuShortcut({ className, ...props }: React.ComponentProps<'span'>): React.JSX.Element;
export { ContextMenu, ContextMenuTrigger, ContextMenuPortal, ContextMenuBackdrop, ContextMenuPositioner, ContextMenuPopup, ContextMenuArrow, ContextMenuGroup, ContextMenuGroupLabel, ContextMenuSeparator, ContextMenuItem, ContextMenuLinkItem, ContextMenuSubmenuRoot, ContextMenuSubmenuTrigger, ContextMenuRadioGroup, ContextMenuRadioItem, ContextMenuRadioItemIndicator, ContextMenuCheckboxItem, ContextMenuCheckboxItemIndicator, ContextMenuShortcut };
