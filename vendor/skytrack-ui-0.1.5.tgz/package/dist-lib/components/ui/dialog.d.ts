import * as React from 'react';
import { Dialog as BaseDialog } from '@base-ui/react/dialog';
import type { VariantProps } from 'class-variance-authority';
import { buttonVariants } from '@/components/ui/button';
/** Shared variant/size props for `DialogTrigger` and `DialogClose`. */
export type DialogButtonProps = VariantProps<typeof buttonVariants>;
/**
 * Dialog — a popup that opens on top of the entire page.
 * `Dialog` (Root) renders no element of its own, so it is re-exported as-is.
 */
declare const Dialog: <Payload>(props: BaseDialog.Root.Props<Payload>) => React.JSX.Element;
/** Creates a handle that lets detached triggers control this dialog. */
declare const createHandle: typeof BaseDialog.createHandle;
type DialogChangeEventDetails = Parameters<NonNullable<React.ComponentProps<typeof BaseDialog.Root>['onOpenChange']>>[1];
declare function DialogTrigger({ className, variant, size, ...props }: React.ComponentProps<typeof BaseDialog.Trigger> & DialogButtonProps): React.JSX.Element;
declare function DialogPortal({ className, ...props }: React.ComponentProps<typeof BaseDialog.Portal>): React.JSX.Element;
declare function DialogBackdrop({ className, ...props }: React.ComponentProps<typeof BaseDialog.Backdrop>): React.JSX.Element;
/** Convenience alias matching the shadcn naming. */
declare function DialogOverlay({ className, ...props }: React.ComponentProps<typeof BaseDialog.Backdrop>): React.JSX.Element;
declare function DialogViewport({ className, ...props }: React.ComponentProps<typeof BaseDialog.Viewport>): React.JSX.Element;
declare function DialogPopup({ className, ...props }: React.ComponentProps<typeof BaseDialog.Popup>): React.JSX.Element;
declare function DialogHeader({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
declare function DialogFooter({ className, ...props }: React.ComponentProps<'div'>): React.JSX.Element;
declare function DialogTitle({ className, ...props }: React.ComponentProps<typeof BaseDialog.Title>): React.JSX.Element;
declare function DialogDescription({ className, ...props }: React.ComponentProps<typeof BaseDialog.Description>): React.JSX.Element;
declare function DialogClose({ className, variant, size, ...props }: React.ComponentProps<typeof BaseDialog.Close> & DialogButtonProps): React.JSX.Element;
export { Dialog, createHandle, DialogTrigger, DialogPortal, DialogBackdrop, DialogOverlay, DialogViewport, DialogPopup, DialogHeader, DialogFooter, DialogTitle, DialogDescription, DialogClose };
export type { DialogChangeEventDetails };
