import * as React from 'react';
import { ScrollArea as BaseScrollArea } from '@base-ui/react/scroll-area';
declare function ScrollArea({ className, ...props }: React.ComponentProps<typeof BaseScrollArea.Root>): React.JSX.Element;
declare function ScrollAreaViewport({ className, ...props }: React.ComponentProps<typeof BaseScrollArea.Viewport>): React.JSX.Element;
declare function ScrollAreaContent({ className, ...props }: React.ComponentProps<typeof BaseScrollArea.Content>): React.JSX.Element;
declare function ScrollAreaScrollbar({ className, ...props }: React.ComponentProps<typeof BaseScrollArea.Scrollbar>): React.JSX.Element;
declare function ScrollAreaThumb({ className, ...props }: React.ComponentProps<typeof BaseScrollArea.Thumb>): React.JSX.Element;
declare function ScrollAreaCorner({ className, ...props }: React.ComponentProps<typeof BaseScrollArea.Corner>): React.JSX.Element;
export { ScrollArea, ScrollAreaViewport, ScrollAreaContent, ScrollAreaScrollbar, ScrollAreaThumb, ScrollAreaCorner };
