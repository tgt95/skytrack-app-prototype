import * as React from 'react';
import { Tooltip as BaseTooltip } from '@base-ui/react/tooltip';
/** Native Base UI props for `TooltipTrigger`; styling comes from the call site. */
export type TooltipTriggerProps = React.ComponentProps<typeof BaseTooltip.Trigger>;
/**
 * Tooltip — a visual hint that appears when an element is hovered or focused.
 * `TooltipProvider` and `Tooltip` (Root) render no element of their own, so they
 * are re-exported as-is.
 */
declare const TooltipProvider: React.FC<import("@base-ui/react").TooltipProviderProps>;
declare const Tooltip: <Payload>(props: BaseTooltip.Root.Props<Payload>) => React.JSX.Element;
/** Creates a handle that lets detached triggers control this tooltip. */
declare const createHandle: typeof BaseTooltip.createHandle;
type TooltipChangeEventDetails = Parameters<NonNullable<React.ComponentProps<typeof BaseTooltip.Root>['onOpenChange']>>[1];
declare function TooltipTrigger({ className, ...props }: React.ComponentProps<typeof BaseTooltip.Trigger>): React.JSX.Element;
declare function TooltipPortal({ className, ...props }: React.ComponentProps<typeof BaseTooltip.Portal>): React.JSX.Element;
declare function TooltipPositioner({ className, ...props }: React.ComponentProps<typeof BaseTooltip.Positioner>): React.JSX.Element;
declare function TooltipPopup({ className, ...props }: React.ComponentProps<typeof BaseTooltip.Popup>): React.JSX.Element;
declare function TooltipArrow({ className, children, ...props }: React.ComponentProps<typeof BaseTooltip.Arrow>): React.JSX.Element;
declare function TooltipViewport({ className, ...props }: React.ComponentProps<typeof BaseTooltip.Viewport>): React.JSX.Element;
export { TooltipProvider, Tooltip, createHandle, TooltipTrigger, TooltipPortal, TooltipPositioner, TooltipPopup, TooltipArrow, TooltipViewport };
export type { TooltipChangeEventDetails };
