import * as React from 'react';
import { Progress as BaseProgress } from '@base-ui/react/progress';
declare function Progress({ className, ...props }: React.ComponentProps<typeof BaseProgress.Root>): React.JSX.Element;
declare function ProgressLabel({ className, ...props }: React.ComponentProps<typeof BaseProgress.Label>): React.JSX.Element;
declare function ProgressValue({ className, ...props }: React.ComponentProps<typeof BaseProgress.Value>): React.JSX.Element;
declare function ProgressTrack({ className, ...props }: React.ComponentProps<typeof BaseProgress.Track>): React.JSX.Element;
declare function ProgressIndicator({ className, ...props }: React.ComponentProps<typeof BaseProgress.Indicator>): React.JSX.Element;
export { Progress, ProgressLabel, ProgressValue, ProgressTrack, ProgressIndicator };
