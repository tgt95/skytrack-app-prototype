import * as React from 'react';
import { PreviewCard as BasePreviewCard } from '@base-ui/react/preview-card';
/** Native Base UI props for `PreviewCardTrigger`; styling comes from the call site. */
export type PreviewCardTriggerProps = React.ComponentProps<typeof BasePreviewCard.Trigger>;
/**
 * Preview Card — a link that shows a destination preview on hover or focus.
 * `PreviewCard` (Root) renders no element of its own, so it is re-exported as-is.
 */
declare const PreviewCard: <Payload>(props: BasePreviewCard.Root.Props<Payload>) => React.JSX.Element;
/** Creates a handle that lets detached triggers control this preview card. */
declare const createHandle: typeof BasePreviewCard.createHandle;
type PreviewCardChangeEventDetails = Parameters<NonNullable<React.ComponentProps<typeof BasePreviewCard.Root>['onOpenChange']>>[1];
declare function PreviewCardTrigger({ className, ...props }: React.ComponentProps<typeof BasePreviewCard.Trigger>): React.JSX.Element;
declare function PreviewCardPortal({ className, ...props }: React.ComponentProps<typeof BasePreviewCard.Portal>): React.JSX.Element;
declare function PreviewCardBackdrop({ className, ...props }: React.ComponentProps<typeof BasePreviewCard.Backdrop>): React.JSX.Element;
declare function PreviewCardPositioner({ className, ...props }: React.ComponentProps<typeof BasePreviewCard.Positioner>): React.JSX.Element;
declare function PreviewCardPopup({ className, ...props }: React.ComponentProps<typeof BasePreviewCard.Popup>): React.JSX.Element;
declare function PreviewCardArrow({ className, children, ...props }: React.ComponentProps<typeof BasePreviewCard.Arrow>): React.JSX.Element;
declare function PreviewCardViewport({ className, ...props }: React.ComponentProps<typeof BasePreviewCard.Viewport>): React.JSX.Element;
export { PreviewCard, createHandle, PreviewCardTrigger, PreviewCardPortal, PreviewCardBackdrop, PreviewCardPositioner, PreviewCardPopup, PreviewCardArrow, PreviewCardViewport };
export type { PreviewCardChangeEventDetails };
