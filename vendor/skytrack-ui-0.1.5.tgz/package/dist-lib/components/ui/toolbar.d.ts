import * as React from 'react';
import { Toolbar as BaseToolbar } from '@base-ui/react/toolbar';
import { type VariantProps } from 'class-variance-authority';
export declare const toolbarButtonVariants: (props?: ({
    isActivated?: boolean | null | undefined;
    size?: "default" | "icon" | "lg" | "sm" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export type ToolbarButtonVariantProps = VariantProps<typeof toolbarButtonVariants>;
declare function Toolbar({ className, ...props }: React.ComponentProps<typeof BaseToolbar.Root>): React.JSX.Element;
declare function ToolbarGroup({ className, ...props }: React.ComponentProps<typeof BaseToolbar.Group>): React.JSX.Element;
declare function ToolbarSeparator({ className, ...props }: React.ComponentProps<typeof BaseToolbar.Separator>): React.JSX.Element;
type ToolbarButtonProps = React.ComponentProps<typeof BaseToolbar.Button> & ToolbarButtonVariantProps;
declare function ToolbarButton({ className, isActivated, size, ...props }: ToolbarButtonProps): React.JSX.Element;
declare function ToolbarLink({ className, ...props }: React.ComponentProps<typeof BaseToolbar.Link>): React.JSX.Element;
declare function ToolbarInput({ className, ...props }: React.ComponentProps<typeof BaseToolbar.Input>): React.JSX.Element;
export { Toolbar, ToolbarGroup, ToolbarSeparator, ToolbarButton, ToolbarLink, ToolbarInput };
