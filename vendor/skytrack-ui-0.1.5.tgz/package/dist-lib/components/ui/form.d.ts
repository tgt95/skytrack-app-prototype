import * as React from 'react';
import { Form as BaseForm } from '@base-ui/react/form';
declare function Form({ className, ...props }: React.ComponentProps<typeof BaseForm>): React.JSX.Element;
export { Form };
