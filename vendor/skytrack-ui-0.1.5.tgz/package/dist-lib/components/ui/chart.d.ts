import * as React from 'react';
import * as Recharts from 'recharts';
export type ChartConfig = Record<string, {
    label?: React.ReactNode;
    color?: string;
    icon?: React.ComponentType<{
        className?: string;
    }>;
}>;
type ChartContextValue = {
    config: ChartConfig;
};
declare function useChart(): ChartContextValue;
export type ChartContainerProps = React.ComponentProps<'div'> & {
    config: ChartConfig;
    children: React.ReactElement;
};
declare function ChartContainer({ config, children, className, style, ...props }: ChartContainerProps): React.JSX.Element;
declare function ChartTooltipContent({ active, payload, label, hideLabel, className }: {
    active?: boolean;
    payload?: Array<{
        dataKey?: string | number;
        name?: string | number;
        value?: string | number;
        color?: string;
    }>;
    label?: React.ReactNode;
    hideLabel?: boolean;
    className?: string;
}): React.JSX.Element | null;
declare function ChartLegendContent({ payload, className }: {
    payload?: Array<{
        dataKey?: string | number;
        value?: string | number;
        color?: string;
    }>;
    className?: string;
}): React.JSX.Element | null;
declare const ChartTooltip: typeof Recharts.Tooltip;
declare const ChartLegend: React.MemoExoticComponent<(outsideProps: Recharts.LegendProps) => React.ReactPortal | null>;
export { ChartContainer, ChartLegend, ChartLegendContent, ChartTooltip, ChartTooltipContent, useChart };
