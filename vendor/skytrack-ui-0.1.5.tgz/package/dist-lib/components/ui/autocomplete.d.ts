import * as React from 'react';
import { Autocomplete as BaseAutocomplete } from '@base-ui/react/autocomplete';
import { type VariantProps } from 'class-variance-authority';
/**
 * Props of the `Autocomplete` root, generic over the item value type.
 * Accepts a flat item list or a grouped one (`{ value, items }[]`).
 */
export type AutocompleteRootProps<ItemValue> = BaseAutocomplete.Root.Props<ItemValue>;
type AutocompleteGroup<Item> = {
    [key: string]: unknown;
    items: readonly Item[];
};
declare function Autocomplete<ItemValue>(props: AutocompleteRootProps<ItemValue>): React.JSX.Element;
export declare const autocompleteInputVariants: (props?: ({
    context?: "group" | "standalone" | null | undefined;
    size?: "default" | "sm" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
type AutocompleteInputProps = React.ComponentProps<typeof BaseAutocomplete.Input> & VariantProps<typeof autocompleteInputVariants>;
declare function AutocompleteInput({ className, context, size, ...props }: AutocompleteInputProps): React.JSX.Element;
export declare const autocompleteInputGroupVariants: (props?: ({
    size?: "default" | "sm" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
type AutocompleteInputGroupProps = React.ComponentProps<typeof BaseAutocomplete.InputGroup> & VariantProps<typeof autocompleteInputGroupVariants>;
declare function AutocompleteInputGroup({ className, size, ...props }: AutocompleteInputGroupProps): React.JSX.Element;
declare function AutocompleteTrigger({ className, children, ...props }: React.ComponentProps<typeof BaseAutocomplete.Trigger>): React.JSX.Element;
/** Standalone trigger used by the input-inside-popup pattern. */
declare function AutocompleteTriggerButton({ className, children, ...props }: React.ComponentProps<typeof BaseAutocomplete.Trigger>): React.JSX.Element;
declare function AutocompleteIcon({ className, children, ...props }: React.ComponentProps<typeof BaseAutocomplete.Icon>): React.JSX.Element;
declare function AutocompleteClear({ className, children, ...props }: React.ComponentProps<typeof BaseAutocomplete.Clear>): React.JSX.Element;
/** Renders the current input value. Renders no element of its own. */
declare function AutocompleteValue(props: React.ComponentProps<typeof BaseAutocomplete.Value>): React.JSX.Element;
declare function AutocompletePortal({ className, ...props }: React.ComponentProps<typeof BaseAutocomplete.Portal>): React.JSX.Element;
declare function AutocompleteBackdrop({ className, ...props }: React.ComponentProps<typeof BaseAutocomplete.Backdrop>): React.JSX.Element;
declare function AutocompletePositioner({ className, ...props }: React.ComponentProps<typeof BaseAutocomplete.Positioner>): React.JSX.Element;
declare function AutocompletePopup({ className, ...props }: React.ComponentProps<typeof BaseAutocomplete.Popup>): React.JSX.Element;
declare function AutocompleteArrow({ className, children, ...props }: React.ComponentProps<typeof BaseAutocomplete.Arrow>): React.JSX.Element;
declare function AutocompleteStatus({ className, ...props }: React.ComponentProps<typeof BaseAutocomplete.Status>): React.JSX.Element;
declare function AutocompleteEmpty({ className, children, ...props }: React.ComponentProps<typeof BaseAutocomplete.Empty>): React.JSX.Element;
declare function AutocompleteList({ className, ...props }: React.ComponentProps<typeof BaseAutocomplete.List>): React.JSX.Element;
declare function AutocompleteRow({ className, ...props }: React.ComponentProps<typeof BaseAutocomplete.Row>): React.JSX.Element;
declare function AutocompleteItem({ className, children, ...props }: React.ComponentProps<typeof BaseAutocomplete.Item>): React.JSX.Element;
declare function AutocompleteGroup({ className, ...props }: React.ComponentProps<typeof BaseAutocomplete.Group>): React.JSX.Element;
declare function AutocompleteGroupLabel({ className, ...props }: React.ComponentProps<typeof BaseAutocomplete.GroupLabel>): React.JSX.Element;
declare function AutocompleteSeparator({ className, ...props }: React.ComponentProps<typeof BaseAutocomplete.Separator>): React.JSX.Element;
/** Renders the filtered items of the enclosing group/list. Renders no element of its own. */
declare function AutocompleteCollection(props: React.ComponentProps<typeof BaseAutocomplete.Collection>): React.JSX.Element;
/** Re-exported Base UI helpers so demos never need the raw package. */
export declare const useAutocompleteFilter: typeof import("@base-ui/react/internals/filter").getFilter;
export declare const useAutocompleteFilteredItems: typeof BaseAutocomplete.useFilteredItems;
export { Autocomplete, AutocompleteInputGroup, AutocompleteInput, AutocompleteTrigger, AutocompleteTriggerButton, AutocompleteIcon, AutocompleteClear, AutocompleteValue, AutocompletePortal, AutocompleteBackdrop, AutocompletePositioner, AutocompletePopup, AutocompleteArrow, AutocompleteStatus, AutocompleteEmpty, AutocompleteList, AutocompleteRow, AutocompleteItem, AutocompleteGroup, AutocompleteGroupLabel, AutocompleteSeparator, AutocompleteCollection };
