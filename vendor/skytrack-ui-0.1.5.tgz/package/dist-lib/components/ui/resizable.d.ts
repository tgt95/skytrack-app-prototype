import * as React from 'react';
import { Group as ResizablePrimitiveGroup, Panel as ResizablePrimitivePanel, Separator as ResizablePrimitiveSeparator } from 'react-resizable-panels';
declare function ResizablePanelGroup({ className, orientation, ...props }: React.ComponentProps<typeof ResizablePrimitiveGroup>): React.JSX.Element;
declare function ResizablePanel({ className, ...props }: React.ComponentProps<typeof ResizablePrimitivePanel>): React.JSX.Element;
type ResizableHandleProps = React.ComponentProps<typeof ResizablePrimitiveSeparator> & {
    withHandle?: boolean;
};
declare function ResizableHandle({ className, withHandle, ...props }: ResizableHandleProps): React.JSX.Element;
export { ResizableHandle, ResizablePanel, ResizablePanelGroup };
export type { ResizableHandleProps };
