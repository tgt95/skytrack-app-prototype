import * as React from 'react';
import { ToggleGroup as BaseToggleGroup } from '@base-ui/react/toggle-group';
type ToggleGroupContextValue = {
    variant?: 'default' | 'outline' | 'segmented' | 'brand' | null;
    size?: 'xs' | 'sm' | 'default' | 'lg' | null;
};
export declare const ToggleGroupContext: React.Context<ToggleGroupContextValue | null>;
type ToggleGroupProps = React.ComponentProps<typeof BaseToggleGroup> & ToggleGroupContextValue;
declare function ToggleGroup({ className, variant, size, ...props }: ToggleGroupProps): React.JSX.Element;
export { ToggleGroup };
