import { i as CONTROL_SIZE_CLASSES, n as buttonVariants, r as focusRing, t as Button } from "./chunks/button-1Z23yCSW.js";
export { Button, buttonVariants, CONTROL_SIZE_CLASSES as controlSizeClasses, focusRing };
