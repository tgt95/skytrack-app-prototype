import { t as cn } from "./chunks/utils-QluraT_M.js";
import "react";
import { Button as Button$1 } from "@base-ui/react/button";
import { cva } from "class-variance-authority";
import { jsx } from "react/jsx-runtime";
//#region src/components/ui/button.tsx
/** Shared focus ring + disabled styles. Reuse in every interactive component. */
var focusRing = "outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:border-ring";
var buttonVariants = cva(cn("inline-flex cursor-pointer shrink-0 items-center justify-center gap-2 whitespace-nowrap rounded-(--radius) text-sm font-medium transition-colors select-none", "disabled:pointer-events-none disabled:opacity-50 data-[disabled]:pointer-events-none data-[disabled]:opacity-50", "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", focusRing), {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			destructive: "bg-destructive text-(--foreground-inverse) hover:bg-destructive/90 focus-visible:ring-destructive/30",
			outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:hover:bg-input/50",
			secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 px-4 py-2 has-[>svg]:px-3",
			xs: "h-6 gap-1.5 px-3 text-xs has-[>svg]:px-2.5",
			sm: "h-8 gap-1.5 px-3 text-sm has-[>svg]:px-2.5",
			lg: "h-10 px-6 has-[>svg]:px-4",
			icon: "size-9",
			"icon-xs": "size-6",
			"icon-sm": "size-8",
			"icon-lg": "size-10"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, ...props }) {
	return /* @__PURE__ */ jsx(Button$1, {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
//#endregion
export { Button, buttonVariants, focusRing };
