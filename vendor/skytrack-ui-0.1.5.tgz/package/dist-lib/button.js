import { t as cn } from "./chunks/utils-Cr_eCEw3.js";
import { t as focusRing } from "./chunks/focus-ring-BwICtWf4.js";
import { t as CONTROL_SIZE_CLASSES } from "./chunks/control-sizes-DMOxFGLI.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { cva } from "class-variance-authority";
import { Button as Button$1 } from "@base-ui/react/button";
//#region src/components/ui/button.tsx
var buttonVariants = cva(cn("inline-flex cursor-pointer shrink-0 items-center justify-center gap-2 whitespace-nowrap rounded-(--radius) text-sm font-medium transition-colors select-none", "disabled:pointer-events-none disabled:opacity-50 data-disabled:pointer-events-none data-disabled:opacity-50", "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", focusRing), {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			destructive: "bg-destructive text-(--foreground-inverse) hover:bg-destructive/90 focus-visible:ring-destructive/30",
			outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:hover:bg-input/50",
			secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: cn(CONTROL_SIZE_CLASSES.default, "px-4 py-2 has-[>svg]:px-3"),
			xs: cn(CONTROL_SIZE_CLASSES.xs, "gap-1.5 px-3 has-[>svg]:px-2.5"),
			sm: cn(CONTROL_SIZE_CLASSES.sm, "gap-1.5 px-3 has-[>svg]:px-2.5"),
			lg: cn(CONTROL_SIZE_CLASSES.lg, "px-6 has-[>svg]:px-4"),
			icon: "size-9",
			"icon-xs": "size-6",
			"icon-sm": "size-8",
			"icon-lg": "size-10"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, ...props }) {
	return /* @__PURE__ */ jsx(Button$1, {
		"data-slot": "button",
		"data-size": size ?? "default",
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
//#endregion
export { Button, buttonVariants, CONTROL_SIZE_CLASSES as controlSizeClasses, focusRing };
