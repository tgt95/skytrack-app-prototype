import { t as cn } from "./chunks/utils-QluraT_M.js";
import * as React from "react";
import { jsx } from "react/jsx-runtime";
import { ToggleGroup as ToggleGroup$1 } from "@base-ui/react/toggle-group";
//#region src/components/ui/toggle-group.tsx
var ToggleGroupContext = React.createContext(null);
function ToggleGroup({ className, variant, size, ...props }) {
	return /* @__PURE__ */ jsx(ToggleGroupContext.Provider, {
		value: {
			variant,
			size
		},
		children: /* @__PURE__ */ jsx(ToggleGroup$1, {
			"data-slot": "toggle-group",
			className: cn("flex items-center rounded-(--radius) border border-border", variant === "segmented" && "gap-1 bg-background p-0.5", "data-[orientation=vertical]:flex-col", className),
			...props
		})
	});
}
//#endregion
export { ToggleGroup, ToggleGroupContext };
