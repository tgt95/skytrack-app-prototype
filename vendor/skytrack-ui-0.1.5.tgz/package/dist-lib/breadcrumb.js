import { t as cn } from "./chunks/utils-QluraT_M.js";
import "react";
import { CaretRightIcon, DotsThreeIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
import { useRender } from "@base-ui/react/use-render";
//#region src/components/ui/breadcrumb.tsx
function Breadcrumb({ className, ...props }) {
	return /* @__PURE__ */ jsx("nav", {
		"data-slot": "breadcrumb",
		"aria-label": "breadcrumb",
		className: cn(className),
		...props
	});
}
function BreadcrumbList({ className, ...props }) {
	return /* @__PURE__ */ jsx("ol", {
		"data-slot": "breadcrumb-list",
		className: cn("flex flex-wrap items-center gap-1.5 text-sm text-muted-foreground sm:gap-2.5", className),
		...props
	});
}
function BreadcrumbItem({ className, ...props }) {
	return /* @__PURE__ */ jsx("li", {
		"data-slot": "breadcrumb-item",
		className: cn("inline-flex items-center gap-1.5", className),
		...props
	});
}
function BreadcrumbLink({ className, render, ...props }) {
	return useRender({
		defaultTagName: "a",
		render,
		props: {
			"data-slot": "breadcrumb-link",
			className: cn("text-muted-foreground transition-colors hover:text-foreground", className),
			...props
		}
	});
}
function BreadcrumbPage({ className, ...props }) {
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "breadcrumb-page",
		role: "link",
		"aria-current": "page",
		"aria-disabled": "true",
		className: cn("font-normal text-foreground", className),
		...props
	});
}
function BreadcrumbSeparator({ className, children, ...props }) {
	return /* @__PURE__ */ jsx("li", {
		"data-slot": "breadcrumb-separator",
		role: "presentation",
		"aria-hidden": "true",
		className: cn("[&>svg]:size-3.5", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretRightIcon, {})
	});
}
function BreadcrumbEllipsis({ className, ...props }) {
	return /* @__PURE__ */ jsxs("span", {
		"data-slot": "breadcrumb-ellipsis",
		role: "presentation",
		"aria-hidden": "true",
		className: cn("flex size-8 items-center justify-center text-muted-foreground", className),
		...props,
		children: [/* @__PURE__ */ jsx(DotsThreeIcon, { className: "size-4" }), /* @__PURE__ */ jsx("span", {
			className: "sr-only",
			children: "More pages"
		})]
	});
}
//#endregion
export { Breadcrumb, BreadcrumbEllipsis, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator };
