import { t as cn } from "./chunks/utils-QluraT_M.js";
import "react";
import { cva } from "class-variance-authority";
import { jsx } from "react/jsx-runtime";
//#region src/components/ui/alert.tsx
var alertVariants = cva("relative flex w-full items-start gap-3 rounded-md border p-4 text-sm", {
	variants: { variant: {
		default: "border-border bg-card text-card-foreground [&>svg]:text-foreground",
		info: "border-info/40 bg-info/10 text-foreground [&>svg]:text-info",
		success: "border-success/40 bg-success/10 text-foreground [&>svg]:text-success",
		warning: "border-warning/40 bg-warning/10 text-foreground [&>svg]:text-warning",
		destructive: "border-destructive/40 bg-destructive/10 text-foreground [&>svg]:text-destructive"
	} },
	defaultVariants: { variant: "default" }
});
function Alert({ className, variant, role = "alert", ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "alert",
		role,
		className: cn(alertVariants({ variant }), className),
		...props
	});
}
function AlertTitle({ className, ...props }) {
	return /* @__PURE__ */ jsx("h5", {
		"data-slot": "alert-title",
		className: cn("font-medium leading-none tracking-tight text-foreground", className),
		...props
	});
}
function AlertDescription({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "alert-description",
		className: cn("text-sm text-muted-foreground [&_p]:leading-relaxed", className),
		...props
	});
}
function AlertAction({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "alert-action",
		className: cn("ml-auto shrink-0 self-center", className),
		...props
	});
}
//#endregion
export { Alert, AlertAction, AlertDescription, AlertTitle, alertVariants };
