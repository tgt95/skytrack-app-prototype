import { t as cn } from "./chunks/utils-QluraT_M.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { Meter as Meter$1 } from "@base-ui/react/meter";
//#region src/components/ui/meter.tsx
function Meter({ className, ...props }) {
	return /* @__PURE__ */ jsx(Meter$1.Root, {
		"data-slot": "meter",
		className: cn("grid w-60 max-w-full grid-cols-2 gap-y-2", className),
		...props
	});
}
function MeterLabel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Meter$1.Label, {
		"data-slot": "meter-label",
		className: cn("text-sm font-normal text-foreground", className),
		...props
	});
}
function MeterValue({ className, ...props }) {
	return /* @__PURE__ */ jsx(Meter$1.Value, {
		"data-slot": "meter-value",
		className: cn("text-right text-sm text-foreground", className),
		...props
	});
}
function MeterTrack({ className, ...props }) {
	return /* @__PURE__ */ jsx(Meter$1.Track, {
		"data-slot": "meter-track",
		className: cn("col-span-2 h-3 overflow-hidden bg-muted", className),
		...props
	});
}
function MeterIndicator({ className, ...props }) {
	return /* @__PURE__ */ jsx(Meter$1.Indicator, {
		"data-slot": "meter-indicator",
		className: cn("bg-primary transition-[width] duration-500", className),
		...props
	});
}
//#endregion
export { Meter, MeterIndicator, MeterLabel, MeterTrack, MeterValue };
