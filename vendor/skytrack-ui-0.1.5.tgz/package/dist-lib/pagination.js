import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import { n as buttonVariants } from "./chunks/button-1Z23yCSW.js";
import "react";
import { CaretLeftIcon, CaretRightIcon, DotsThreeIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/components/ui/pagination.tsx
function Pagination({ className, ...props }) {
	return /* @__PURE__ */ jsx("nav", {
		"aria-label": "pagination",
		"data-slot": "pagination",
		className: cn("mx-auto flex w-full justify-center", className),
		...props
	});
}
function PaginationContent({ className, ...props }) {
	return /* @__PURE__ */ jsx("ul", {
		"data-slot": "pagination-content",
		className: cn("flex flex-row items-center gap-1", className),
		...props
	});
}
function PaginationItem({ className, ...props }) {
	return /* @__PURE__ */ jsx("li", {
		"data-slot": "pagination-item",
		className: cn(className),
		...props
	});
}
function PaginationLink({ className, isActive = false, size = "icon", ...props }) {
	return /* @__PURE__ */ jsx("a", {
		"aria-current": isActive ? "page" : void 0,
		"data-slot": "pagination-link",
		"data-active": isActive,
		className: cn(buttonVariants({
			variant: isActive ? "outline" : "ghost",
			size
		}), "aria-disabled:pointer-events-none aria-disabled:opacity-50", className),
		...props
	});
}
function PaginationPrevious({ className, text = "Previous", ...props }) {
	return /* @__PURE__ */ jsxs(PaginationLink, {
		"aria-label": "Go to previous page",
		size: "default",
		className: cn("gap-1 px-2.5 sm:pl-2.5", className),
		...props,
		children: [/* @__PURE__ */ jsx(CaretLeftIcon, { "aria-hidden": "true" }), /* @__PURE__ */ jsx("span", {
			className: "hidden sm:block",
			children: text
		})]
	});
}
function PaginationNext({ className, text = "Next", ...props }) {
	return /* @__PURE__ */ jsxs(PaginationLink, {
		"aria-label": "Go to next page",
		size: "default",
		className: cn("gap-1 px-2.5 sm:pr-2.5", className),
		...props,
		children: [/* @__PURE__ */ jsx("span", {
			className: "hidden sm:block",
			children: text
		}), /* @__PURE__ */ jsx(CaretRightIcon, { "aria-hidden": "true" })]
	});
}
function PaginationEllipsis({ className, ...props }) {
	return /* @__PURE__ */ jsxs("span", {
		"aria-hidden": "true",
		"data-slot": "pagination-ellipsis",
		className: cn("flex size-9 items-center justify-center text-muted-foreground", className),
		...props,
		children: [/* @__PURE__ */ jsx(DotsThreeIcon, { className: "size-4" }), /* @__PURE__ */ jsx("span", {
			className: "sr-only",
			children: "More pages"
		})]
	});
}
//#endregion
export { Pagination, PaginationContent, PaginationEllipsis, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious };
