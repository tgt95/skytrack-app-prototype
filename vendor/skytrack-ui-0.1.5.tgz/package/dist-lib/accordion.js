import { t as cn } from "./chunks/utils-QluraT_M.js";
import { focusRing } from "./button.js";
import "react";
import { Accordion as Accordion$1 } from "@base-ui/react/accordion";
import { CaretDownIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/components/ui/accordion.tsx
function Accordion({ className, ...props }) {
	return /* @__PURE__ */ jsx(Accordion$1.Root, {
		"data-slot": "accordion",
		className: cn("flex w-full flex-col", className),
		...props
	});
}
function AccordionItem({ className, ...props }) {
	return /* @__PURE__ */ jsx(Accordion$1.Item, {
		"data-slot": "accordion-item",
		className: cn("border-b border-border last:border-b-0", className),
		...props
	});
}
function AccordionHeader({ className, ...props }) {
	return /* @__PURE__ */ jsx(Accordion$1.Header, {
		"data-slot": "accordion-header",
		className: cn("flex", className),
		...props
	});
}
function AccordionTrigger({ className, children, ...props }) {
	return /* @__PURE__ */ jsxs(Accordion$1.Trigger, {
		"data-slot": "accordion-trigger",
		className: cn("flex w-full flex-1 cursor-pointer items-center justify-between gap-4 rounded-md py-4 text-left text-sm font-medium text-foreground transition-colors select-none", "hover:underline", "disabled:pointer-events-none disabled:opacity-50 data-[disabled]:pointer-events-none data-[disabled]:opacity-50", "[&[data-panel-open]>svg]:rotate-180", "[&>svg]:pointer-events-none [&>svg]:shrink-0 [&>svg:not([class*='size-'])]:size-4", focusRing, className),
		...props,
		children: [children, /* @__PURE__ */ jsx(CaretDownIcon, {
			"aria-hidden": "true",
			className: "size-4 shrink-0 text-muted-foreground transition-transform duration-200"
		})]
	});
}
function accordionContent(dataSlot, { className, ...props }) {
	return /* @__PURE__ */ jsx(Accordion$1.Panel, {
		"data-slot": dataSlot,
		className: cn("h-[var(--accordion-panel-height)] overflow-hidden text-sm transition-[height] duration-200 ease-out", "data-[ending-style]:h-0 data-[starting-style]:h-0", className),
		...props
	});
}
function AccordionContent(props) {
	return accordionContent("accordion-content", props);
}
function AccordionPanel(props) {
	return accordionContent("accordion-panel", props);
}
//#endregion
export { Accordion, AccordionContent, AccordionHeader, AccordionItem, AccordionPanel, AccordionTrigger };
