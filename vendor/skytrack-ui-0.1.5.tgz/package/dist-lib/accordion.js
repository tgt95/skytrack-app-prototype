import { t as cn } from "./chunks/utils-QluraT_M.js";
import { focusRing } from "./button.js";
import "react";
import { Accordion as Accordion$1 } from "@base-ui/react/accordion";
import { CaretDown } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/components/ui/accordion.tsx
function Accordion({ className, ...props }) {
	return /* @__PURE__ */ jsx(Accordion$1.Root, {
		"data-slot": "accordion",
		className: cn("flex w-full flex-col", className),
		...props
	});
}
function AccordionItem({ className, ...props }) {
	return /* @__PURE__ */ jsx(Accordion$1.Item, {
		"data-slot": "accordion-item",
		className: cn("border-b border-border last:border-b-0", className),
		...props
	});
}
function AccordionHeader({ className, ...props }) {
	return /* @__PURE__ */ jsx(Accordion$1.Header, {
		"data-slot": "accordion-header",
		className: cn("flex", className),
		...props
	});
}
function AccordionTrigger({ className, children, variant = "default", ...props }) {
	return /* @__PURE__ */ jsxs(Accordion$1.Trigger, {
		"data-slot": "accordion-trigger",
		className: cn("flex cursor-pointer flex-1 items-center justify-between transition-colors select-none", variant === "compact" ? "min-h-[34px] gap-2 rounded-none py-1 text-left text-[11px] font-semibold text-muted-foreground hover:no-underline [&>svg]:size-3" : "gap-4 rounded-md py-4 text-left text-sm font-medium hover:underline", "disabled:pointer-events-none disabled:opacity-50 data-[disabled]:pointer-events-none data-[disabled]:opacity-50", "[&[data-panel-open]>svg]:rotate-180", "[&>svg]:pointer-events-none [&>svg]:shrink-0 [&>svg:not([class*='size-'])]:size-4", focusRing, className),
		...props,
		children: [children, /* @__PURE__ */ jsx(CaretDown, { className: "text-muted-foreground transition-transform duration-200" })]
	});
}
function AccordionPanel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Accordion$1.Panel, {
		"data-slot": "accordion-panel",
		className: cn("h-[var(--accordion-panel-height)] overflow-hidden text-sm transition-[height] duration-200 ease-out", "data-[ending-style]:h-0 data-[starting-style]:h-0", className),
		...props
	});
}
//#endregion
export { Accordion, AccordionHeader, AccordionItem, AccordionPanel, AccordionTrigger };
