import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import { t as Button } from "./chunks/button-1Z23yCSW.js";
import { Menu, MenuCheckboxItem, MenuCheckboxItemIndicator, MenuPopup, MenuPortal, MenuPositioner, MenuTrigger } from "./menu.js";
import { CheckboxRoot } from "./checkbox.js";
import { Input } from "./input.js";
import { Pagination, PaginationContent, PaginationItem, PaginationNext, PaginationPrevious } from "./pagination.js";
import "react";
import { CaretDownIcon, CaretUpDownIcon, CaretUpIcon, CheckIcon, MagnifyingGlassIcon, SlidersHorizontalIcon, XIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
import { columnFilteringFeature, columnVisibilityFeature, createFilteredRowModel, createPaginatedRowModel, createSortedRowModel, filterFn_includesString, globalFilteringFeature, rowPaginationFeature, rowSelectionFeature, rowSortingFeature, sortFn_alphanumeric, tableFeatures, useTable } from "@tanstack/react-table";
//#region src/components/ui/data-table.tsx
var dataTableFeatures = tableFeatures({
	columnFilteringFeature,
	globalFilteringFeature,
	filteredRowModel: createFilteredRowModel(),
	rowSortingFeature,
	sortedRowModel: createSortedRowModel(),
	rowPaginationFeature,
	paginatedRowModel: createPaginatedRowModel(),
	columnVisibilityFeature,
	rowSelectionFeature,
	filterFns: { includesString: filterFn_includesString },
	sortFns: { alphanumeric: sortFn_alphanumeric }
});
var alignmentClasses = {
	left: "text-left",
	center: "text-center",
	right: "text-right"
};
function DataTable({ columns, data, enableRowSelection = false, getRowId, pageSize = 10, searchPlaceholder = "Search records", emptyMessage = "No results found.", className }) {
	const table = useTable({
		features: dataTableFeatures,
		columns,
		data,
		getRowId,
		initialState: { pagination: {
			pageIndex: 0,
			pageSize
		} },
		globalFilterFn: "includesString",
		defaultColumn: { sortFn: "alphanumeric" }
	});
	const pageRows = table.getRowModel().rows;
	const rowCount = table.getRowCount();
	const pageIndex = table.state.pagination.pageIndex;
	const firstRow = rowCount === 0 ? 0 : pageIndex * table.state.pagination.pageSize + 1;
	const lastRow = rowCount === 0 ? 0 : firstRow + pageRows.length - 1;
	const query = table.state.globalFilter ?? "";
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "data-table",
		className: cn("flex w-full min-w-0 flex-col gap-4", className),
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ jsx(Input, {
					"aria-label": searchPlaceholder,
					placeholder: searchPlaceholder,
					startAdornment: /* @__PURE__ */ jsx(MagnifyingGlassIcon, { "aria-hidden": "true" }),
					endAdornment: query !== "" ? /* @__PURE__ */ jsx(Button, {
						type: "button",
						size: "icon-xs",
						variant: "ghost",
						"aria-label": "Clear filter",
						onClick: () => table.setGlobalFilter(""),
						children: /* @__PURE__ */ jsx(XIcon, { "aria-hidden": "true" })
					}) : void 0,
					className: "w-full sm:max-w-64",
					value: query,
					onChange: (event) => table.setGlobalFilter(event.currentTarget.value)
				}), /* @__PURE__ */ jsxs(Menu, { children: [/* @__PURE__ */ jsxs(MenuTrigger, {
					render: /* @__PURE__ */ jsx(Button, {
						type: "button",
						variant: "outline",
						size: "sm"
					}),
					children: [/* @__PURE__ */ jsx(SlidersHorizontalIcon, { "aria-hidden": "true" }), "Columns"]
				}), /* @__PURE__ */ jsx(MenuPortal, { children: /* @__PURE__ */ jsx(MenuPositioner, {
					side: "bottom",
					align: "end",
					sideOffset: 4,
					children: /* @__PURE__ */ jsx(MenuPopup, { children: table.getAllLeafColumns().filter((column) => column.getCanHide()).map((column) => /* @__PURE__ */ jsxs(MenuCheckboxItem, {
						inset: true,
						checked: column.getIsVisible(),
						onCheckedChange: (checked) => column.toggleVisibility(checked),
						children: [/* @__PURE__ */ jsx(MenuCheckboxItemIndicator, { children: /* @__PURE__ */ jsx(CheckIcon, {
							className: "size-3.5",
							weight: "bold"
						}) }), typeof column.columnDef.header === "string" ? column.columnDef.header : column.id]
					}, column.id)) })
				}) })] })]
			}),
			/* @__PURE__ */ jsx("div", {
				className: "w-full overflow-x-auto rounded-(--radius) border border-border",
				children: /* @__PURE__ */ jsxs("table", {
					className: "w-full min-w-[640px] border-collapse text-left text-sm",
					children: [/* @__PURE__ */ jsx("thead", {
						className: "bg-muted text-muted-foreground",
						children: table.getHeaderGroups().map((headerGroup) => /* @__PURE__ */ jsxs("tr", {
							className: "border-b border-border",
							children: [enableRowSelection && /* @__PURE__ */ jsx("th", {
								scope: "col",
								className: "w-10 px-3 py-2",
								children: headerGroup.id === table.getHeaderGroups()[0]?.id && /* @__PURE__ */ jsx(CheckboxRoot, {
									"aria-label": "Select all rows on this page",
									checked: table.getIsAllPageRowsSelected(),
									indeterminate: table.getIsSomePageRowsSelected() && !table.getIsAllPageRowsSelected(),
									onCheckedChange: (checked) => table.toggleAllPageRowsSelected(checked === true)
								})
							}), headerGroup.headers.map((header) => {
								const sorted = header.column.getIsSorted();
								const SortIcon = sorted === "asc" ? CaretUpIcon : sorted === "desc" ? CaretDownIcon : CaretUpDownIcon;
								const align = header.column.columnDef.meta?.align ?? "left";
								return /* @__PURE__ */ jsx("th", {
									scope: "col",
									colSpan: header.colSpan,
									"aria-sort": sorted === "asc" ? "ascending" : sorted === "desc" ? "descending" : void 0,
									className: cn("px-3 py-2 font-medium", alignmentClasses[align]),
									children: header.isPlaceholder ? null : header.column.getCanSort() ? /* @__PURE__ */ jsxs("button", {
										type: "button",
										className: "inline-flex cursor-pointer items-center gap-1.5 text-left outline-none hover:text-foreground focus-visible:underline",
										onClick: header.column.getToggleSortingHandler(),
										children: [/* @__PURE__ */ jsx(table.FlexRender, { header }), /* @__PURE__ */ jsx(SortIcon, {
											"aria-hidden": "true",
											className: "size-3.5"
										})]
									}) : /* @__PURE__ */ jsx(table.FlexRender, { header })
								}, header.id);
							})]
						}, headerGroup.id))
					}), /* @__PURE__ */ jsx("tbody", { children: pageRows.length ? pageRows.map((row) => /* @__PURE__ */ jsxs("tr", {
						"data-selected": row.getIsSelected() || void 0,
						className: "border-b border-border last:border-0 hover:bg-muted/40 data-[selected=true]:bg-accent/50",
						children: [enableRowSelection && /* @__PURE__ */ jsx("td", {
							className: "px-3 py-2",
							children: /* @__PURE__ */ jsx(CheckboxRoot, {
								"aria-label": `Select row ${row.id}`,
								checked: row.getIsSelected(),
								disabled: !row.getCanSelect(),
								onCheckedChange: (checked) => row.toggleSelected(checked === true)
							})
						}), row.getVisibleCells().map((cell) => /* @__PURE__ */ jsx("td", {
							className: cn("px-3 py-2 align-middle", alignmentClasses[cell.column.columnDef.meta?.align ?? "left"]),
							children: /* @__PURE__ */ jsx(table.FlexRender, { cell })
						}, cell.id))]
					}, row.id)) : /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", {
						colSpan: table.getVisibleLeafColumns().length + Number(enableRowSelection),
						className: "h-24 px-3 text-center text-muted-foreground",
						children: emptyMessage
					}) }) })]
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ jsxs("p", {
					className: "text-sm text-muted-foreground",
					children: [
						"Showing ",
						firstRow,
						"–",
						lastRow,
						" of ",
						rowCount,
						" rows",
						enableRowSelection && ` · ${Object.keys(table.state.rowSelection).length} selected`
					]
				}), /* @__PURE__ */ jsx(Pagination, {
					className: "mx-0 w-auto justify-end",
					children: /* @__PURE__ */ jsxs(PaginationContent, { children: [
						/* @__PURE__ */ jsx(PaginationItem, { children: /* @__PURE__ */ jsx(PaginationPrevious, {
							href: "#",
							"aria-disabled": !table.getCanPreviousPage(),
							onClick: (event) => {
								event.preventDefault();
								if (table.getCanPreviousPage()) table.previousPage();
							}
						}) }),
						/* @__PURE__ */ jsx(PaginationItem, { children: /* @__PURE__ */ jsxs("span", {
							className: "px-2 text-sm tabular-nums text-muted-foreground",
							children: [
								"Page ",
								Math.min(pageIndex + 1, Math.max(table.getPageCount(), 1)),
								" of ",
								Math.max(table.getPageCount(), 1)
							]
						}) }),
						/* @__PURE__ */ jsx(PaginationItem, { children: /* @__PURE__ */ jsx(PaginationNext, {
							href: "#",
							"aria-disabled": !table.getCanNextPage(),
							onClick: (event) => {
								event.preventDefault();
								if (table.getCanNextPage()) table.nextPage();
							}
						}) })
					] })
				})]
			})
		]
	});
}
//#endregion
export { DataTable };
