import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import * as React from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import * as Recharts from "recharts";
//#region src/components/ui/chart.tsx
var ChartContext = React.createContext(null);
function useChart() {
	const context = React.useContext(ChartContext);
	if (!context) throw new Error("Chart components must be rendered inside <ChartContainer>.");
	return context;
}
function ChartContainer({ config, children, className, style, ...props }) {
	const colors = Object.fromEntries(Object.entries(config).filter(([, item]) => item.color).map(([key, item]) => [`--color-${key}`, item.color]));
	return /* @__PURE__ */ jsx(ChartContext.Provider, {
		value: { config },
		children: /* @__PURE__ */ jsx("div", {
			"data-slot": "chart-container",
			className: cn("relative flex w-full items-center justify-center text-xs", className),
			style: {
				...colors,
				...style
			},
			...props,
			children: /* @__PURE__ */ jsx(Recharts.ResponsiveContainer, { children })
		})
	});
}
function ChartTooltipContent({ active, payload, label, hideLabel = false, className }) {
	const { config } = useChart();
	if (!active || !payload?.length) return null;
	return /* @__PURE__ */ jsxs("div", {
		className: cn("grid min-w-32 gap-1.5 border border-border bg-popover px-3 py-2 text-xs text-popover-foreground shadow-md", className),
		children: [!hideLabel && /* @__PURE__ */ jsx("div", {
			className: "font-medium",
			children: label
		}), /* @__PURE__ */ jsx("div", {
			className: "grid gap-1",
			children: payload.map((item, index) => {
				const key = String(item.dataKey ?? item.name ?? index);
				const entry = config[key];
				const Icon = entry?.icon;
				return /* @__PURE__ */ jsxs("div", {
					className: "flex items-center gap-2",
					children: [
						Icon ? /* @__PURE__ */ jsx(Icon, { className: "size-3.5" }) : /* @__PURE__ */ jsx("span", {
							className: "size-2.5",
							style: { backgroundColor: item.color ?? entry?.color }
						}),
						/* @__PURE__ */ jsx("span", {
							className: "flex-1 text-muted-foreground",
							children: entry?.label ?? item.name ?? key
						}),
						/* @__PURE__ */ jsx("span", {
							className: "font-mono font-medium tabular-nums",
							children: item.value
						})
					]
				}, `${key}-${index}`);
			})
		})]
	});
}
function ChartLegendContent({ payload, className }) {
	const { config } = useChart();
	if (!payload?.length) return null;
	return /* @__PURE__ */ jsx("div", {
		className: cn("flex flex-wrap items-center justify-center gap-x-4 gap-y-2", className),
		children: payload.map((item, index) => {
			const key = String(item.dataKey ?? item.value ?? index);
			const entry = config[key];
			const Icon = entry?.icon;
			return /* @__PURE__ */ jsxs("span", {
				className: "flex items-center gap-1.5 text-muted-foreground",
				children: [Icon ? /* @__PURE__ */ jsx(Icon, { className: "size-3.5" }) : /* @__PURE__ */ jsx("span", {
					className: "size-2.5",
					style: { backgroundColor: item.color ?? entry?.color }
				}), entry?.label ?? item.value ?? key]
			}, `${key}-${index}`);
		})
	});
}
var ChartTooltip = Recharts.Tooltip;
var ChartLegend = Recharts.Legend;
//#endregion
export { ChartContainer, ChartLegend, ChartLegendContent, ChartTooltip, ChartTooltipContent, useChart };
