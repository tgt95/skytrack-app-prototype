type DatePartOrder = 'day' | 'month' | 'year';
/**
 * Reads the day/month/year order a locale uses for numeric dates, so typed dates such as
 * `03/04/2026` are interpreted the same way the locale displays them.
 */
export declare function getNumericDatePartOrder(locale?: string): DatePartOrder[];
/**
 * Parses a date typed into a Date Picker field. Accepts ISO (`2026-11-11`), numeric dates in
 * either the locale order or an unambiguous day-first/month-first order (`11/11/2026`,
 * `11-11-2026`, `11.11.2026`), and month-name dates (`11 Nov 2026`, `Nov 11, 2026`).
 * Returns `undefined` when the text is empty or is not a real calendar date.
 */
export declare function parseDateInput(value: string, locale?: string): Date | undefined;
export {};
