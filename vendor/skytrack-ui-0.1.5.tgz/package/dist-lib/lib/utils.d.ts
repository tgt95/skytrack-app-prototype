import { type ClassValue } from 'clsx';
/** Merge class names; later Tailwind classes override earlier ones. */
export declare function cn(...inputs: ClassValue[]): string;
