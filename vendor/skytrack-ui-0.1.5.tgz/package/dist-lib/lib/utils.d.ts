import { type ClassValue } from 'clsx';
/** Merge class names; later Tailwind classes override earlier ones. */
type StatefulClassName = (state: any) => string | undefined;
export declare function cn(...inputs: ClassValue[]): string;
export declare function cn(...inputs: [...ClassValue[], ClassValue | StatefulClassName]): string | StatefulClassName;
export {};
