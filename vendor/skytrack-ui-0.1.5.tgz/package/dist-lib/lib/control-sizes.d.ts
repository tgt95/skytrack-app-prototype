/** Shared heights and typography for controls aligned with the standard control sizes. */
export type ControlSize = 'xs' | 'sm' | 'default' | 'lg';
export declare const CONTROL_SIZE_CLASSES: Record<ControlSize, string>;
