import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { Avatar as Avatar$1 } from "@base-ui/react/avatar";
//#region src/components/ui/avatar.tsx
var AVATAR_SIZE_CLASSES = {
	xs: "size-6",
	sm: "size-8",
	default: "size-9",
	lg: "size-10"
};
function Avatar({ className, size = "default", ...props }) {
	return /* @__PURE__ */ jsx(Avatar$1.Root, {
		"data-slot": "avatar",
		"data-size": size,
		className: cn("group/avatar relative flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-muted text-sm font-medium text-muted-foreground select-none", AVATAR_SIZE_CLASSES[size], className),
		...props
	});
}
function AvatarImage({ className, ...props }) {
	return /* @__PURE__ */ jsx(Avatar$1.Image, {
		"data-slot": "avatar-image",
		className: cn("size-full object-cover", className),
		...props
	});
}
function AvatarFallback({ className, ...props }) {
	return /* @__PURE__ */ jsx(Avatar$1.Fallback, {
		"data-slot": "avatar-fallback",
		className: cn("flex size-full items-center justify-center text-sm group-data-[size=xs]/avatar:text-[10px] group-data-[size=sm]/avatar:text-xs group-data-[size=lg]/avatar:text-base", className),
		...props
	});
}
//#endregion
export { Avatar, AvatarFallback, AvatarImage };
