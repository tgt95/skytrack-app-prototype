import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { Avatar as Avatar$1 } from "@base-ui/react/avatar";
//#region src/components/ui/avatar.tsx
function Avatar({ className, ...props }) {
	return /* @__PURE__ */ jsx(Avatar$1.Root, {
		"data-slot": "avatar",
		className: cn("relative flex size-8 shrink-0 items-center justify-center overflow-hidden rounded-full bg-muted text-sm font-medium text-muted-foreground select-none", className),
		...props
	});
}
function AvatarImage({ className, ...props }) {
	return /* @__PURE__ */ jsx(Avatar$1.Image, {
		"data-slot": "avatar-image",
		className: cn("size-full object-cover", className),
		...props
	});
}
function AvatarFallback({ className, ...props }) {
	return /* @__PURE__ */ jsx(Avatar$1.Fallback, {
		"data-slot": "avatar-fallback",
		className: cn("flex size-full items-center justify-center text-sm", className),
		...props
	});
}
//#endregion
export { Avatar, AvatarFallback, AvatarImage };
