import { t as cn } from "./utils-Cr_eCEw3.js";
import { t as focusRing } from "./focus-ring-BwICtWf4.js";
import { Calendar } from "../calendar.js";
import { Input } from "../input.js";
import { Popover, PopoverPopup, PopoverPortal, PopoverPositioner, PopoverTrigger } from "../popover.js";
import * as React from "react";
import { CalendarBlankIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
import { dateMatchModifiers } from "react-day-picker";
//#region src/lib/date-input.ts
var ISO_PATTERN = /^(\d{4})-(\d{1,2})-(\d{1,2})$/;
var NUMERIC_PATTERN = /^\d{1,4}[/.-]\d{1,2}[/.-]\d{1,4}$/;
var MONTH_NAME_PATTERN = /[a-z]{3,}/i;
var FOUR_DIGIT_YEAR_PATTERN = /\d{4}/;
function createLocalDate(year, month, day) {
	if (!Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day)) return void 0;
	if (month < 1 || month > 12 || day < 1 || day > 31) return void 0;
	const date = /* @__PURE__ */ new Date(0);
	date.setFullYear(year, month - 1, day);
	date.setHours(0, 0, 0, 0);
	if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) return void 0;
	return date;
}
function normalizeYear(year) {
	if (year >= 100) return year;
	return year <= 68 ? 2e3 + year : 1900 + year;
}
/**
* Reads the day/month/year order a locale uses for numeric dates, so typed dates such as
* `03/04/2026` are interpreted the same way the locale displays them.
*/
function getNumericDatePartOrder(locale) {
	const parts = new Intl.DateTimeFormat(locale, {
		year: "numeric",
		month: "numeric",
		day: "numeric"
	}).formatToParts(new Date(2001, 1, 3)).map((part) => part.type).filter((type) => type === "day" || type === "month" || type === "year");
	return parts.length === 3 ? parts : [
		"day",
		"month",
		"year"
	];
}
function parseNumericDate(text, order) {
	if (!NUMERIC_PATTERN.test(text)) return void 0;
	const [first, second, third] = text.split(/[/.-]/);
	let year;
	let firstValue;
	let secondValue;
	if (first.length === 4) {
		year = Number(first);
		firstValue = Number(second);
		secondValue = Number(third);
	} else {
		year = normalizeYear(Number(third));
		firstValue = Number(first);
		secondValue = Number(second);
	}
	const [dayOrder] = order.filter((part) => part !== "year");
	let day = dayOrder === "day" ? firstValue : secondValue;
	let month = dayOrder === "day" ? secondValue : firstValue;
	if (firstValue > 12 && secondValue <= 12) {
		day = firstValue;
		month = secondValue;
	} else if (secondValue > 12 && firstValue <= 12) {
		day = secondValue;
		month = firstValue;
	}
	return createLocalDate(year, month, day);
}
function getMonthNames(locale) {
	return Array.from({ length: 12 }, (_, month) => {
		const date = new Date(2001, month, 1);
		return [new Intl.DateTimeFormat(locale, { month: "long" }).format(date), new Intl.DateTimeFormat(locale, { month: "short" }).format(date)];
	});
}
function normalizeMonthName(name) {
	return name.replace(/\./g, "").trim().toLowerCase();
}
function parseMonthNameDate(text, locale) {
	if (!MONTH_NAME_PATTERN.test(text) || !FOUR_DIGIT_YEAR_PATTERN.test(text)) return void 0;
	const dayFirst = /^(\d{1,2})\s+([A-Za-z]+)\.?,?\s+(\d{4})$/.exec(text);
	const monthFirst = /^([A-Za-z]+)\.?\s+(\d{1,2}),?\s+(\d{4})$/.exec(text);
	if (!dayFirst && !monthFirst) return void 0;
	const day = Number(dayFirst?.[1] ?? monthFirst?.[2]);
	const monthName = dayFirst?.[2] ?? monthFirst?.[1] ?? "";
	const year = Number(dayFirst?.[3] ?? monthFirst?.[3]);
	const normalizedName = normalizeMonthName(monthName);
	const monthIndex = getMonthNames(locale).findIndex((names) => names.some((name) => normalizeMonthName(name) === normalizedName));
	if (monthIndex === -1) return void 0;
	return createLocalDate(year, monthIndex + 1, day);
}
/**
* Parses a date typed into a Date Picker field. Accepts ISO (`2026-11-11`), numeric dates in
* either the locale order or an unambiguous day-first/month-first order (`11/11/2026`,
* `11-11-2026`, `11.11.2026`), and month-name dates (`11 Nov 2026`, `Nov 11, 2026`).
* Returns `undefined` when the text is empty or is not a real calendar date.
*/
function parseDateInput(value, locale) {
	const text = value.trim();
	if (!text) return void 0;
	const isoMatch = ISO_PATTERN.exec(text);
	if (isoMatch) return createLocalDate(Number(isoMatch[1]), Number(isoMatch[2]), Number(isoMatch[3]));
	if (NUMERIC_PATTERN.test(text)) return parseNumericDate(text, getNumericDatePartOrder(locale));
	return parseMonthNameDate(text, locale);
}
/** Separator the range picker displays and inserts once a start date is complete. */
var DATE_RANGE_SEPARATOR = " – ";
/** En dash, em dash, or a hyphen padded with spaces. A bare hyphen is left alone so ISO dates type cleanly. */
var RANGE_SEPARATOR_PATTERN = /\s*[–—]\s*|\s+-\s+/;
/** True when the text already contains a range separator, so typing should not add another. */
function hasDateRangeSeparator(value) {
	return RANGE_SEPARATOR_PATTERN.test(value);
}
var COMPLETE_DATE_PATTERNS = [
	/^\d{4}-\d{1,2}-\d{1,2}$/,
	/^\d{1,2}[/.-]\d{1,2}[/.-]\d{4}$/,
	/^\d{1,2}\s+[a-z]{3,}\.?,?\s+\d{4}$/i,
	/^[a-z]{3,}\.?\s+\d{1,2},?\s+\d{4}$/i
];
/**
* True when the text reads as a whole date with an unambiguous four-digit year.
*
* The range field uses this to decide a typed start date is finished and the end date can
* follow. It is deliberately stricter than `parseDateInput`, which already accepts
* `11/11/2` as 2002: completing on any successful parse would insert the range separator
* while the user is still typing the year.
*/
function isCompleteDateText(value, locale) {
	const text = value.trim();
	if (!text) return false;
	return COMPLETE_DATE_PATTERNS.some((pattern) => pattern.test(text)) && parseDateInput(text, locale) !== void 0;
}
/**
* Parses a typed date range such as `11 Nov 2026 – 15 Nov 2026`.
*
* - A single date is accepted and returned as `{ from }`, matching a first click in the calendar.
* - An empty end half (`11 Nov 2026 – `) is also `{ from }`, so typing does not need to finish.
*
* Order is not checked here: an end date before the start date still parses, because whether
* that range is selectable is the caller's rule. The range picker rejects it as unavailable.
*/
function parseDateRangeInput(value, locale) {
	const text = value.trim();
	if (!text) return void 0;
	const separator = RANGE_SEPARATOR_PATTERN.exec(text);
	if (!separator) {
		const single = parseDateInput(text, locale);
		return single ? { from: single } : void 0;
	}
	const startText = text.slice(0, separator.index).trim();
	const endText = text.slice(separator.index + separator[0].length).trim();
	const from = parseDateInput(startText, locale);
	if (!from) return void 0;
	if (!endText) return { from };
	const to = parseDateInput(endText, locale);
	if (!to) return void 0;
	return {
		from,
		to
	};
}
//#endregion
//#region src/lib/date-field.ts
function useDateField(options) {
	const { value, format, parse, commit, isUnavailable, completeText, onCommitFromKeyboard, onRequestOpen } = options;
	const [draft, setDraft] = React.useState(null);
	const [invalid, setInvalid] = React.useState(false);
	const selectAllOnMouseUpRef = React.useRef(false);
	const formattedValue = format(value);
	const inputValue = draft ?? formattedValue;
	const commitDraft = () => {
		if (draft === null) return true;
		if (draft === formattedValue) {
			setDraft(null);
			setInvalid(false);
			return true;
		}
		const text = draft.trim();
		if (!text) {
			commit(void 0);
			setDraft(null);
			setInvalid(false);
			return true;
		}
		const parsed = parse(text);
		if (parsed === void 0 || isUnavailable?.(parsed)) {
			setInvalid(true);
			return false;
		}
		commit(parsed);
		setDraft(null);
		setInvalid(false);
		return true;
	};
	const handleFocus = (event) => {
		setDraft(formattedValue);
		setInvalid(false);
		selectAllOnMouseUpRef.current = true;
		event.currentTarget.select();
	};
	const handleMouseUp = (event) => {
		if (!selectAllOnMouseUpRef.current) return;
		event.preventDefault();
		selectAllOnMouseUpRef.current = false;
	};
	const handleBlur = () => {
		selectAllOnMouseUpRef.current = false;
		if (commitDraft()) return;
		setDraft(null);
		setInvalid(false);
	};
	const handleKeyDown = (event) => {
		if (event.key === "Enter") {
			event.preventDefault();
			if (commitDraft()) onCommitFromKeyboard?.();
			return;
		}
		if (event.key === "Escape") {
			if (draft !== null) {
				setDraft(null);
				setInvalid(false);
			}
			return;
		}
		if (event.key === "ArrowDown") onRequestOpen?.();
	};
	const handleChange = (event) => {
		const raw = event.target.value;
		const next = completeText ? completeText(raw, event.target.selectionStart === raw.length) : raw;
		setDraft(next);
		const parsed = parse(next.trim());
		setInvalid(parsed !== void 0 && isUnavailable?.(parsed) === true);
	};
	const reset = () => {
		setDraft(null);
		setInvalid(false);
	};
	return {
		inputValue,
		invalid,
		draft,
		reset,
		handlers: {
			onFocus: handleFocus,
			onBlur: handleBlur,
			onChange: handleChange,
			onKeyDown: handleKeyDown,
			onMouseUp: handleMouseUp
		}
	};
}
//#endregion
//#region src/lib/iso-week.ts
/** Monday that starts the ISO-8601 week containing `date`. */
function startOfISOWeek(date) {
	const start = new Date(date.getFullYear(), date.getMonth(), date.getDate());
	start.setDate(start.getDate() - (start.getDay() + 6) % 7);
	return start;
}
/** Sunday that ends the ISO-8601 week starting on `weekStart`. */
function endOfISOWeek(weekStart) {
	const end = new Date(weekStart.getFullYear(), weekStart.getMonth(), weekStart.getDate());
	end.setDate(end.getDate() + 6);
	return end;
}
/** ISO-8601 week-year and week number for a date, e.g. `2026, Week 45`. */
function getISOWeek(date) {
	const thursday = new Date(date.getFullYear(), date.getMonth(), date.getDate());
	const dayNumber = thursday.getDay() || 7;
	thursday.setDate(thursday.getDate() + 4 - dayNumber);
	const weekYear = thursday.getFullYear();
	const yearStart = new Date(weekYear, 0, 1);
	return {
		weekYear,
		week: Math.ceil(((thursday.getTime() - yearStart.getTime()) / 864e5 + 1) / 7)
	};
}
/** Week label shown in the week picker, e.g. `2026, Week 45`. */
function formatWeekLabel(date) {
	const { weekYear, week } = getISOWeek(date);
	return `${weekYear}, Week ${week}`;
}
var WEEK_LABEL_PATTERN = /^(\d{4})\s*,?\s*week\s*(\d{1,2})$/i;
/** Monday that starts the given ISO week-year and week number. */
function startOfISOWeekFromWeekNumber(weekYear, week) {
	const weekOne = startOfISOWeek(new Date(weekYear, 0, 4));
	const start = new Date(weekOne.getFullYear(), weekOne.getMonth(), weekOne.getDate());
	start.setDate(start.getDate() + (week - 1) * 7);
	return start;
}
/**
* Parses typed text in the week picker. Accepts either the week label it displays
* (`2026, Week 45`, `2026 week 45`) or any date, which is normalised to the Monday of
* its ISO week. Returns `undefined` for empty text, impossible dates, week numbers
* outside 1–53, and week numbers that do not exist in that ISO week-year.
*/
function parseWeekInput(value, locale) {
	const text = value.trim();
	if (!text) return void 0;
	const label = WEEK_LABEL_PATTERN.exec(text);
	if (label) {
		const weekYear = Number(label[1]);
		const week = Number(label[2]);
		if (!Number.isInteger(week) || week < 1 || week > 53) return void 0;
		const start = startOfISOWeekFromWeekNumber(weekYear, week);
		return getISOWeek(start).weekYear === weekYear && getISOWeek(start).week === week ? start : void 0;
	}
	const date = parseDateInput(text, locale);
	return date ? startOfISOWeek(date) : void 0;
}
//#endregion
//#region src/lib/use-media-query.ts
/**
* Tracks a CSS media query from JavaScript.
*
* Components that change structure (not just styling) at a breakpoint need this: Tailwind can
* hide a second calendar month, but the component has to stop rendering it to keep a popover
* inside a small viewport. The first render reads the query synchronously so an open overlay
* never paints at the wrong size, and `false` is returned when `matchMedia` is unavailable
* (server render, jsdom without the harness stub).
*/
function useMediaQuery(query) {
	const [matches, setMatches] = React.useState(() => {
		if (typeof window === "undefined" || typeof window.matchMedia !== "function") return false;
		return window.matchMedia(query).matches;
	});
	React.useEffect(() => {
		if (typeof window === "undefined" || typeof window.matchMedia !== "function") return;
		const mediaQuery = window.matchMedia(query);
		const update = () => setMatches(mediaQuery.matches);
		update();
		mediaQuery.addEventListener("change", update);
		return () => mediaQuery.removeEventListener("change", update);
	}, [query]);
	return matches;
}
//#endregion
//#region src/components/ui/date-picker.tsx
/**
* Base UI flips `align` from start to end when a popup is wider than its trigger and the
* viewport is tight, which pushes the calendar away from the input's left edge. Shifting keeps
* the popup's left edge on the input and only nudges it when it would leave the viewport.
*/
var calendarCollisionAvoidance = { align: "shift" };
/**
* Base UI anchors a popup to the element it renders, which for an adorned Input is the inner
* text box, not the visible field. Anchor to the `input-root` wrapper so the calendar starts on
* the field's left edge instead of the text area after the icon.
*/
function resolveFieldAnchor(element) {
	return element?.closest("[data-slot=\"input-root\"]") ?? element;
}
/** Locale the fields format with, and therefore the locale typed dates are read in. */
var DATE_LOCALE = new Intl.DateTimeFormat(void 0, { dateStyle: "medium" }).resolvedOptions().locale;
/**
* How many months a picker calendar may show.
*
* Two months sit side by side from `sm` up but stack below it, and a stacked pair is taller than
* a phone viewport, which clips the popover under the fold. The pickers therefore render one
* month below `sm` even when the caller asks for more.
*/
function usePickerNumberOfMonths(calendarProps) {
	return useMediaQuery("(max-width: 639px)") ? 1 : calendarProps?.numberOfMonths;
}
/**
* The text field every picker shares: an editable input plus a separate calendar button that
* opens the popover. The button is a real `<button>` (not the input wearing `role="button"`),
* and the input keeps native text-box semantics so typing works the same in all three pickers.
*/
function DatePickerField({ slot, inputRef, field, value, placeholder, disabled, empty, accessibleName, id, ariaLabel, ariaLabelledby, calendarButtonLabel, open, onOpenChange, className, inputClassName, popupClassName, children }) {
	const anchor = React.useCallback(() => resolveFieldAnchor(inputRef.current), [inputRef]);
	return /* @__PURE__ */ jsxs(Popover, {
		open,
		onOpenChange,
		children: [/* @__PURE__ */ jsx("div", {
			"data-slot": slot,
			className: cn("w-full", className),
			children: /* @__PURE__ */ jsx(Input, {
				ref: inputRef,
				disabled,
				id,
				type: "text",
				value,
				placeholder,
				autoComplete: "off",
				spellCheck: false,
				"data-empty": empty,
				"data-invalid": field.invalid ? "" : void 0,
				"aria-invalid": field.invalid || void 0,
				"aria-label": ariaLabel ?? (id || ariaLabelledby ? void 0 : accessibleName),
				"aria-labelledby": ariaLabelledby,
				className: cn("w-full", inputClassName),
				startAdornment: /* @__PURE__ */ jsx(PopoverTrigger, {
					render: /* @__PURE__ */ jsx("button", {
						type: "button",
						disabled,
						"aria-label": calendarButtonLabel,
						className: cn("-ms-1 inline-flex size-7 shrink-0 cursor-pointer items-center justify-center rounded-(--radius) text-muted-foreground transition-colors", "hover:text-foreground disabled:pointer-events-none disabled:opacity-50", focusRing)
					}),
					children: /* @__PURE__ */ jsx(CalendarBlankIcon, { "aria-hidden": "true" })
				}),
				...field.handlers
			})
		}), /* @__PURE__ */ jsx(PopoverPortal, { children: /* @__PURE__ */ jsx(PopoverPositioner, {
			anchor,
			side: "bottom",
			align: "start",
			sideOffset: 4,
			collisionAvoidance: calendarCollisionAvoidance,
			children: /* @__PURE__ */ jsx(PopoverPopup, {
				className: cn("w-auto max-w-none p-0", popupClassName),
				children
			})
		}) })]
	});
}
function DatePicker(props) {
	const { value, defaultValue, onValueChange, id, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, placeholder = "Pick a date", disabled = false, className, buttonClassName, calendarClassName, calendarButtonLabel = "Open calendar", calendarProps } = props;
	const [internalValue, setInternalValue] = React.useState(defaultValue);
	const [open, setOpen] = React.useState(false);
	const inputRef = React.useRef(null);
	const isControlled = Object.prototype.hasOwnProperty.call(props, "value");
	const selectedDate = isControlled ? value : internalValue;
	const formatter = React.useMemo(() => new Intl.DateTimeFormat(void 0, { dateStyle: "medium" }), []);
	const formatDate = React.useCallback((date) => date ? formatter.format(date) : "", [formatter]);
	const numberOfMonths = usePickerNumberOfMonths(calendarProps);
	const commitValue = (nextValue) => {
		if (!isControlled) setInternalValue(nextValue);
		onValueChange?.(nextValue);
	};
	const field = useDateField({
		value: selectedDate,
		format: formatDate,
		parse: (text) => parseDateInput(text, DATE_LOCALE),
		commit: commitValue,
		isUnavailable: (date) => calendarProps?.disabled != null && dateMatchModifiers(date, calendarProps.disabled),
		onCommitFromKeyboard: () => setOpen(false),
		onRequestOpen: () => setOpen(true)
	});
	return /* @__PURE__ */ jsx(DatePickerField, {
		slot: "date-picker",
		inputRef,
		field,
		value: field.inputValue,
		placeholder,
		disabled,
		empty: !selectedDate,
		accessibleName: selectedDate ? `Selected date: ${formatDate(selectedDate)}` : placeholder,
		id,
		ariaLabel,
		ariaLabelledby,
		calendarButtonLabel,
		open,
		onOpenChange: setOpen,
		className,
		inputClassName: buttonClassName,
		children: /* @__PURE__ */ jsx(Calendar, {
			mode: "single",
			selected: selectedDate,
			onSelect: (nextValue) => {
				commitValue(nextValue);
				field.reset();
				setOpen(false);
			},
			className: calendarClassName,
			...calendarProps,
			numberOfMonths
		})
	});
}
function DateRangePicker(props) {
	const { value, defaultValue, onValueChange, id, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, placeholder = "Pick a date range", disabled = false, className, buttonClassName, calendarClassName, calendarButtonLabel = "Open calendar", calendarProps } = props;
	const [internalValue, setInternalValue] = React.useState(defaultValue);
	const [open, setOpen] = React.useState(false);
	const inputRef = React.useRef(null);
	const isControlled = Object.prototype.hasOwnProperty.call(props, "value");
	const selectedRange = isControlled ? value : internalValue;
	const formatDate = React.useCallback((date) => new Intl.DateTimeFormat(void 0, { dateStyle: "medium" }).format(date), []);
	const numberOfMonths = usePickerNumberOfMonths(calendarProps);
	const formatRange = (range) => {
		if (!range?.from) return "";
		if (range.to) return `${formatDate(range.from)}${DATE_RANGE_SEPARATOR}${formatDate(range.to)}`;
		return `${formatDate(range.from)}${DATE_RANGE_SEPARATOR}Select end date`;
	};
	const isUnavailableDate = (date) => calendarProps?.disabled != null && dateMatchModifiers(date, calendarProps.disabled);
	const commitValue = (nextValue) => {
		if (!isControlled) setInternalValue(nextValue);
		onValueChange?.(nextValue);
	};
	const field = useDateField({
		value: selectedRange,
		format: formatRange,
		parse: (text) => parseDateRangeInput(text, DATE_LOCALE),
		commit: commitValue,
		isUnavailable: (range) => {
			if (!range.from) return true;
			if (range.to != null && range.to.getTime() < range.from.getTime()) return true;
			return isUnavailableDate(range.from) || range.to != null && isUnavailableDate(range.to);
		},
		completeText: (text, caretAtEnd) => {
			if (!caretAtEnd || hasDateRangeSeparator(text) || !isCompleteDateText(text, DATE_LOCALE)) return text;
			return `${text.trim()}${DATE_RANGE_SEPARATOR}`;
		},
		onCommitFromKeyboard: () => setOpen(false),
		onRequestOpen: () => setOpen(true)
	});
	return /* @__PURE__ */ jsx(DatePickerField, {
		slot: "date-range-picker",
		inputRef,
		field,
		value: field.inputValue,
		placeholder,
		disabled,
		empty: !selectedRange?.from,
		accessibleName: formatRange(selectedRange) || placeholder,
		id,
		ariaLabel,
		ariaLabelledby,
		calendarButtonLabel,
		open,
		onOpenChange: setOpen,
		className,
		inputClassName: buttonClassName,
		popupClassName: "max-w-none",
		children: /* @__PURE__ */ jsx(Calendar, {
			mode: "range",
			selected: selectedRange,
			onSelect: (nextRange) => {
				const normalizedRange = !selectedRange?.from && nextRange?.from && nextRange.to && nextRange.from.toDateString() === nextRange.to.toDateString() ? { from: nextRange.from } : nextRange;
				commitValue(normalizedRange);
				field.reset();
				if (normalizedRange?.from && normalizedRange.to) setOpen(false);
			},
			className: calendarClassName,
			...calendarProps,
			numberOfMonths
		})
	});
}
function DateWeekPicker(props) {
	const { value, defaultValue, onValueChange, id, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, placeholder = "Pick a week", disabled = false, className, buttonClassName, calendarClassName, calendarButtonLabel = "Open calendar", calendarProps } = props;
	const [internalValue, setInternalValue] = React.useState(defaultValue);
	const [open, setOpen] = React.useState(false);
	const inputRef = React.useRef(null);
	const isControlled = Object.prototype.hasOwnProperty.call(props, "value");
	const selectedDate = isControlled ? value : internalValue;
	const weekStart = selectedDate ? startOfISOWeek(selectedDate) : void 0;
	const weekEnd = weekStart ? endOfISOWeek(weekStart) : void 0;
	const formatWeek = React.useCallback((date) => date ? formatWeekLabel(startOfISOWeek(date)) : "", []);
	const numberOfMonths = usePickerNumberOfMonths(calendarProps);
	const commitValue = (nextValue) => {
		if (!isControlled) setInternalValue(nextValue);
		onValueChange?.(nextValue);
	};
	const field = useDateField({
		value: selectedDate,
		format: formatWeek,
		parse: (text) => parseWeekInput(text, DATE_LOCALE),
		commit: commitValue,
		isUnavailable: (date) => {
			if (calendarProps?.disabled == null) return false;
			const start = startOfISOWeek(date);
			return dateMatchModifiers(start, calendarProps.disabled) || dateMatchModifiers(endOfISOWeek(start), calendarProps.disabled);
		},
		onCommitFromKeyboard: () => setOpen(false),
		onRequestOpen: () => setOpen(true)
	});
	return /* @__PURE__ */ jsx(DatePickerField, {
		slot: "date-week-picker",
		inputRef,
		field,
		value: field.inputValue,
		placeholder,
		disabled,
		empty: !weekStart,
		accessibleName: weekStart ? `Selected ${formatWeek(weekStart)}` : placeholder,
		id,
		ariaLabel,
		ariaLabelledby,
		calendarButtonLabel,
		open,
		onOpenChange: setOpen,
		className,
		inputClassName: buttonClassName,
		popupClassName: "max-w-none",
		children: /* @__PURE__ */ jsx(Calendar, {
			...calendarProps,
			mode: "range",
			selected: weekStart && weekEnd ? {
				from: weekStart,
				to: weekEnd
			} : void 0,
			weekStartsOn: 1,
			onSelect: (_range, triggerDate) => {
				if (!triggerDate) return;
				commitValue(startOfISOWeek(triggerDate));
				field.reset();
				setOpen(false);
			},
			className: calendarClassName,
			numberOfMonths
		})
	});
}
//#endregion
export { DateRangePicker as n, DateWeekPicker as r, DatePicker as t };
