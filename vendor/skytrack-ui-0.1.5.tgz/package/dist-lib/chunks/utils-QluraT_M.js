import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
//#region src/lib/utils.ts
/** Merge class names; later Tailwind classes override earlier ones. */
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
//#endregion
export { cn as t };
