//#region src/lib/control-sizes.ts
var CONTROL_SIZE_CLASSES = {
	xs: "h-6 text-xs",
	sm: "h-8 text-sm",
	default: "h-9 text-sm",
	lg: "h-10 text-sm"
};
//#endregion
export { CONTROL_SIZE_CLASSES as t };
