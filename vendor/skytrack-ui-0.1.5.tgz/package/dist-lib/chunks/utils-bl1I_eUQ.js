import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
//#region src/lib/utils.ts
function cn(...inputs) {
	if (inputs.find((input) => typeof input === "function")) return (state) => twMerge(clsx(inputs.map((input) => typeof input === "function" ? input(state) : input)));
	return twMerge(clsx(inputs));
}
//#endregion
export { cn as t };
