import { t as cn } from "./utils-Cr_eCEw3.js";
import { t as focusRing } from "./focus-ring-BwICtWf4.js";
import { Calendar } from "../calendar.js";
import { Input } from "../input.js";
import { Popover, PopoverPopup, PopoverPortal, PopoverPositioner, PopoverTrigger } from "../popover.js";
import * as React from "react";
import { CalendarBlankIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
import { dateMatchModifiers } from "react-day-picker";
//#region src/lib/date-input.ts
var ISO_PATTERN = /^(\d{4})-(\d{1,2})-(\d{1,2})$/;
var NUMERIC_PATTERN = /^\d{1,4}[/.-]\d{1,2}[/.-]\d{1,4}$/;
var MONTH_NAME_PATTERN = /[a-z]{3,}/i;
var FOUR_DIGIT_YEAR_PATTERN = /\d{4}/;
function createLocalDate(year, month, day) {
	if (!Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day)) return void 0;
	if (month < 1 || month > 12 || day < 1 || day > 31) return void 0;
	const date = /* @__PURE__ */ new Date(0);
	date.setFullYear(year, month - 1, day);
	date.setHours(0, 0, 0, 0);
	if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) return void 0;
	return date;
}
function normalizeYear(year) {
	if (year >= 100) return year;
	return year <= 68 ? 2e3 + year : 1900 + year;
}
/**
* Reads the day/month/year order a locale uses for numeric dates, so typed dates such as
* `03/04/2026` are interpreted the same way the locale displays them.
*/
function getNumericDatePartOrder(locale) {
	const parts = new Intl.DateTimeFormat(locale, {
		year: "numeric",
		month: "numeric",
		day: "numeric"
	}).formatToParts(new Date(2001, 1, 3)).map((part) => part.type).filter((type) => type === "day" || type === "month" || type === "year");
	return parts.length === 3 ? parts : [
		"day",
		"month",
		"year"
	];
}
function parseNumericDate(text, order) {
	if (!NUMERIC_PATTERN.test(text)) return void 0;
	const [first, second, third] = text.split(/[/.-]/);
	let year;
	let firstValue;
	let secondValue;
	if (first.length === 4) {
		year = Number(first);
		firstValue = Number(second);
		secondValue = Number(third);
	} else {
		year = normalizeYear(Number(third));
		firstValue = Number(first);
		secondValue = Number(second);
	}
	const [dayOrder] = order.filter((part) => part !== "year");
	let day = dayOrder === "day" ? firstValue : secondValue;
	let month = dayOrder === "day" ? secondValue : firstValue;
	if (firstValue > 12 && secondValue <= 12) {
		day = firstValue;
		month = secondValue;
	} else if (secondValue > 12 && firstValue <= 12) {
		day = secondValue;
		month = firstValue;
	}
	return createLocalDate(year, month, day);
}
function getMonthNames(locale) {
	return Array.from({ length: 12 }, (_, month) => {
		const date = new Date(2001, month, 1);
		return [new Intl.DateTimeFormat(locale, { month: "long" }).format(date), new Intl.DateTimeFormat(locale, { month: "short" }).format(date)];
	});
}
function normalizeMonthName(name) {
	return name.replace(/\./g, "").trim().toLowerCase();
}
function parseMonthNameDate(text, locale) {
	if (!MONTH_NAME_PATTERN.test(text) || !FOUR_DIGIT_YEAR_PATTERN.test(text)) return void 0;
	const dayFirst = /^(\d{1,2})\s+([A-Za-z]+)\.?,?\s+(\d{4})$/.exec(text);
	const monthFirst = /^([A-Za-z]+)\.?\s+(\d{1,2}),?\s+(\d{4})$/.exec(text);
	if (!dayFirst && !monthFirst) return void 0;
	const day = Number(dayFirst?.[1] ?? monthFirst?.[2]);
	const monthName = dayFirst?.[2] ?? monthFirst?.[1] ?? "";
	const year = Number(dayFirst?.[3] ?? monthFirst?.[3]);
	const normalizedName = normalizeMonthName(monthName);
	const monthIndex = getMonthNames(locale).findIndex((names) => names.some((name) => normalizeMonthName(name) === normalizedName));
	if (monthIndex === -1) return void 0;
	return createLocalDate(year, monthIndex + 1, day);
}
/**
* Parses a date typed into a Date Picker field. Accepts ISO (`2026-11-11`), numeric dates in
* either the locale order or an unambiguous day-first/month-first order (`11/11/2026`,
* `11-11-2026`, `11.11.2026`), and month-name dates (`11 Nov 2026`, `Nov 11, 2026`).
* Returns `undefined` when the text is empty or is not a real calendar date.
*/
function parseDateInput(value, locale) {
	const text = value.trim();
	if (!text) return void 0;
	const isoMatch = ISO_PATTERN.exec(text);
	if (isoMatch) return createLocalDate(Number(isoMatch[1]), Number(isoMatch[2]), Number(isoMatch[3]));
	if (NUMERIC_PATTERN.test(text)) return parseNumericDate(text, getNumericDatePartOrder(locale));
	return parseMonthNameDate(text, locale);
}
//#endregion
//#region src/components/ui/date-picker.tsx
/**
* Base UI flips `align` from start to end when a popup is wider than its trigger and the
* viewport is tight, which pushes the calendar away from the input's left edge. Shifting keeps
* the popup's left edge on the input and only nudges it when it would leave the viewport.
*/
var calendarCollisionAvoidance = { align: "shift" };
/**
* Base UI anchors a popup to the element it renders, which for an adorned Input is the inner
* text box, not the visible field. Anchor to the `input-root` wrapper so the calendar starts on
* the field's left edge instead of the text area after the icon.
*/
function resolveFieldAnchor(element) {
	return element?.closest("[data-slot=\"input-root\"]") ?? element;
}
/** Monday that starts the ISO-8601 week containing `date`. */
function startOfISOWeek(date) {
	const start = new Date(date.getFullYear(), date.getMonth(), date.getDate());
	start.setDate(start.getDate() - (start.getDay() + 6) % 7);
	return start;
}
/** Sunday that ends the ISO-8601 week starting on `weekStart`. */
function endOfISOWeek(weekStart) {
	const end = new Date(weekStart.getFullYear(), weekStart.getMonth(), weekStart.getDate());
	end.setDate(end.getDate() + 6);
	return end;
}
/** ISO-8601 week-year and week number for a date, e.g. `2026, Week 45`. */
function getISOWeek(date) {
	const thursday = new Date(date.getFullYear(), date.getMonth(), date.getDate());
	const dayNumber = thursday.getDay() || 7;
	thursday.setDate(thursday.getDate() + 4 - dayNumber);
	const weekYear = thursday.getFullYear();
	const yearStart = new Date(weekYear, 0, 1);
	return {
		weekYear,
		week: Math.ceil(((thursday.getTime() - yearStart.getTime()) / 864e5 + 1) / 7)
	};
}
function formatWeekLabel(date) {
	const { weekYear, week } = getISOWeek(date);
	return `${weekYear}, Week ${week}`;
}
function DatePicker(props) {
	const { value, defaultValue, onValueChange, id, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, placeholder = "Pick a date", disabled = false, className, buttonClassName, calendarClassName, calendarButtonLabel = "Open calendar", calendarProps } = props;
	const [internalValue, setInternalValue] = React.useState(defaultValue);
	const [open, setOpen] = React.useState(false);
	const [draft, setDraft] = React.useState(null);
	const [invalid, setInvalid] = React.useState(false);
	const inputRef = React.useRef(null);
	const anchor = React.useCallback(() => resolveFieldAnchor(inputRef.current), []);
	const selectAllOnMouseUpRef = React.useRef(false);
	const isControlled = Object.prototype.hasOwnProperty.call(props, "value");
	const selectedDate = isControlled ? value : internalValue;
	const formatter = React.useMemo(() => new Intl.DateTimeFormat(void 0, { dateStyle: "medium" }), []);
	const locale = formatter.resolvedOptions().locale;
	const formattedValue = selectedDate ? formatter.format(selectedDate) : "";
	const inputValue = draft ?? formattedValue;
	const commitValue = (nextValue) => {
		if (!isControlled) setInternalValue(nextValue);
		onValueChange?.(nextValue);
	};
	const isUnavailableDate = (date) => date == null || calendarProps?.disabled != null && dateMatchModifiers(date, calendarProps.disabled);
	const commitDraft = () => {
		if (draft === null) return true;
		if (draft === formattedValue) {
			setDraft(null);
			setInvalid(false);
			return true;
		}
		const text = draft.trim();
		if (!text) {
			commitValue(void 0);
			setDraft(null);
			setInvalid(false);
			return true;
		}
		const parsed = parseDateInput(text, formatter.resolvedOptions().locale);
		if (isUnavailableDate(parsed)) {
			setInvalid(true);
			return false;
		}
		commitValue(parsed);
		setDraft(null);
		setInvalid(false);
		return true;
	};
	const handleSelect = (nextValue) => {
		commitValue(nextValue);
		setDraft(null);
		setInvalid(false);
		setOpen(false);
	};
	const handleFocus = (event) => {
		setDraft(formattedValue);
		setInvalid(false);
		selectAllOnMouseUpRef.current = true;
		event.currentTarget.select();
	};
	const handleMouseUp = (event) => {
		if (!selectAllOnMouseUpRef.current) return;
		event.preventDefault();
		selectAllOnMouseUpRef.current = false;
	};
	const handleBlur = () => {
		selectAllOnMouseUpRef.current = false;
		if (commitDraft()) return;
		setDraft(null);
		setInvalid(false);
	};
	const handleKeyDown = (event) => {
		if (event.key === "Enter") {
			event.preventDefault();
			if (commitDraft()) setOpen(false);
			return;
		}
		if (event.key === "Escape") {
			if (draft !== null) {
				setDraft(null);
				setInvalid(false);
			}
			return;
		}
		if (event.key === "ArrowDown" && !open) {
			event.preventDefault();
			setOpen(true);
		}
	};
	return /* @__PURE__ */ jsxs(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ jsx("div", {
			"data-slot": "date-picker",
			className: cn("w-full", className),
			children: /* @__PURE__ */ jsx(Input, {
				ref: inputRef,
				disabled,
				id,
				type: "text",
				value: inputValue,
				placeholder,
				autoComplete: "off",
				spellCheck: false,
				"data-empty": !selectedDate,
				"data-invalid": invalid ? "" : void 0,
				"aria-invalid": invalid || void 0,
				"aria-label": ariaLabel ?? (id || ariaLabelledby ? void 0 : selectedDate ? `Selected date: ${formattedValue}` : placeholder),
				"aria-labelledby": ariaLabelledby,
				className: cn("w-full", buttonClassName),
				startAdornment: /* @__PURE__ */ jsx(PopoverTrigger, {
					render: /* @__PURE__ */ jsx("button", {
						type: "button",
						disabled,
						"aria-label": calendarButtonLabel,
						className: cn("-ms-1 inline-flex size-7 shrink-0 cursor-pointer items-center justify-center rounded-(--radius) text-muted-foreground transition-colors", "hover:text-foreground disabled:pointer-events-none disabled:opacity-50", focusRing)
					}),
					children: /* @__PURE__ */ jsx(CalendarBlankIcon, { "aria-hidden": "true" })
				}),
				onFocus: handleFocus,
				onBlur: handleBlur,
				onChange: (event) => {
					const nextDraft = event.target.value;
					setDraft(nextDraft);
					setInvalid(nextDraft.trim().length > 0 && isUnavailableDate(parseDateInput(nextDraft, locale)));
				},
				onKeyDown: handleKeyDown,
				onMouseUp: handleMouseUp
			})
		}), /* @__PURE__ */ jsx(PopoverPortal, { children: /* @__PURE__ */ jsx(PopoverPositioner, {
			anchor,
			side: "bottom",
			align: "start",
			sideOffset: 4,
			collisionAvoidance: calendarCollisionAvoidance,
			children: /* @__PURE__ */ jsx(PopoverPopup, {
				className: "w-auto p-0",
				children: /* @__PURE__ */ jsx(Calendar, {
					mode: "single",
					selected: selectedDate,
					onSelect: handleSelect,
					className: calendarClassName,
					...calendarProps
				})
			})
		}) })]
	});
}
function DateRangePicker(props) {
	const { value, defaultValue, onValueChange, id, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, placeholder = "Pick a date range", disabled = false, className, buttonClassName, calendarClassName, calendarProps } = props;
	const [internalValue, setInternalValue] = React.useState(defaultValue);
	const [open, setOpen] = React.useState(false);
	const inputRef = React.useRef(null);
	const anchor = React.useCallback(() => resolveFieldAnchor(inputRef.current), []);
	const isControlled = Object.prototype.hasOwnProperty.call(props, "value");
	const selectedRange = isControlled ? value : internalValue;
	const formatDate = React.useCallback((date) => new Intl.DateTimeFormat(void 0, { dateStyle: "medium" }).format(date), []);
	const label = selectedRange?.from ? selectedRange.to ? `${formatDate(selectedRange.from)} – ${formatDate(selectedRange.to)}` : `${formatDate(selectedRange.from)} – Select end date` : placeholder;
	return /* @__PURE__ */ jsxs(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ jsx("div", {
			"data-slot": "date-range-picker",
			className: cn("w-full", className),
			children: /* @__PURE__ */ jsx(PopoverTrigger, {
				nativeButton: false,
				render: /* @__PURE__ */ jsx(Input, {
					ref: inputRef,
					disabled,
					id,
					value: selectedRange?.from ? label : "",
					placeholder,
					readOnly: true,
					startAdornment: /* @__PURE__ */ jsx(CalendarBlankIcon, { "aria-hidden": "true" }),
					"data-empty": !selectedRange?.from,
					"aria-label": ariaLabel ?? (id || ariaLabelledby ? void 0 : label),
					"aria-labelledby": ariaLabelledby,
					className: cn("w-full", buttonClassName)
				})
			})
		}), /* @__PURE__ */ jsx(PopoverPortal, { children: /* @__PURE__ */ jsx(PopoverPositioner, {
			anchor,
			side: "bottom",
			align: "start",
			sideOffset: 4,
			collisionAvoidance: calendarCollisionAvoidance,
			children: /* @__PURE__ */ jsx(PopoverPopup, {
				className: "w-auto max-w-none p-0",
				children: /* @__PURE__ */ jsx(Calendar, {
					mode: "range",
					selected: selectedRange,
					onSelect: (nextRange) => {
						const normalizedRange = !selectedRange?.from && nextRange?.from && nextRange.to && nextRange.from.toDateString() === nextRange.to.toDateString() ? { from: nextRange.from } : nextRange;
						if (!isControlled) setInternalValue(normalizedRange);
						onValueChange?.(normalizedRange);
						if (normalizedRange?.from && normalizedRange.to) setOpen(false);
					},
					className: calendarClassName,
					...calendarProps
				})
			})
		}) })]
	});
}
function DateWeekPicker(props) {
	const { value, defaultValue, onValueChange, id, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, placeholder = "Pick a week", disabled = false, className, buttonClassName, calendarClassName, calendarProps } = props;
	const [internalValue, setInternalValue] = React.useState(defaultValue);
	const [open, setOpen] = React.useState(false);
	const inputRef = React.useRef(null);
	const anchor = React.useCallback(() => resolveFieldAnchor(inputRef.current), []);
	const isControlled = Object.prototype.hasOwnProperty.call(props, "value");
	const selectedDate = isControlled ? value : internalValue;
	const weekStart = selectedDate ? startOfISOWeek(selectedDate) : void 0;
	const weekEnd = weekStart ? endOfISOWeek(weekStart) : void 0;
	const label = weekStart ? formatWeekLabel(weekStart) : "";
	return /* @__PURE__ */ jsxs(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ jsx("div", {
			"data-slot": "date-week-picker",
			className: cn("w-full", className),
			children: /* @__PURE__ */ jsx(PopoverTrigger, {
				nativeButton: false,
				render: /* @__PURE__ */ jsx(Input, {
					ref: inputRef,
					disabled,
					id,
					value: label,
					placeholder,
					readOnly: true,
					startAdornment: /* @__PURE__ */ jsx(CalendarBlankIcon, { "aria-hidden": "true" }),
					"data-empty": !weekStart,
					"aria-label": ariaLabel ?? (id || ariaLabelledby ? void 0 : weekStart ? `Selected ${label}` : placeholder),
					"aria-labelledby": ariaLabelledby,
					className: cn("w-full", buttonClassName)
				})
			})
		}), /* @__PURE__ */ jsx(PopoverPortal, { children: /* @__PURE__ */ jsx(PopoverPositioner, {
			anchor,
			side: "bottom",
			align: "start",
			sideOffset: 4,
			collisionAvoidance: calendarCollisionAvoidance,
			children: /* @__PURE__ */ jsx(PopoverPopup, {
				className: "w-auto max-w-none p-0",
				children: /* @__PURE__ */ jsx(Calendar, {
					...calendarProps,
					mode: "range",
					selected: weekStart && weekEnd ? {
						from: weekStart,
						to: weekEnd
					} : void 0,
					weekStartsOn: 1,
					onSelect: (_range, triggerDate) => {
						if (!triggerDate) return;
						const nextWeek = startOfISOWeek(triggerDate);
						if (!isControlled) setInternalValue(nextWeek);
						onValueChange?.(nextWeek);
						setOpen(false);
					},
					className: calendarClassName
				})
			})
		}) })]
	});
}
//#endregion
export { DateRangePicker as n, DateWeekPicker as r, DatePicker as t };
