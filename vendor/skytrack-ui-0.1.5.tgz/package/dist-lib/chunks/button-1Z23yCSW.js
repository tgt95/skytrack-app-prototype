import { t as cn } from "./utils-bl1I_eUQ.js";
import "react";
import { Button } from "@base-ui/react/button";
import { cva } from "class-variance-authority";
import { jsx } from "react/jsx-runtime";
//#region src/components/ui/control-sizes.ts
var CONTROL_SIZE_CLASSES = {
	xs: "h-6 text-xs",
	sm: "h-8 text-sm",
	default: "h-9 text-sm",
	lg: "h-10 text-sm"
};
//#endregion
//#region src/components/ui/button.tsx
/** Shared focus ring + disabled styles. Reuse in every interactive component. */
var focusRing = "outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:border-ring";
var buttonVariants = cva(cn("inline-flex cursor-pointer shrink-0 items-center justify-center gap-2 whitespace-nowrap rounded-(--radius) text-sm font-medium transition-colors select-none", "disabled:pointer-events-none disabled:opacity-50 data-disabled:pointer-events-none data-disabled:opacity-50", "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", focusRing), {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			destructive: "bg-destructive text-(--foreground-inverse) hover:bg-destructive/90 focus-visible:ring-destructive/30",
			outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:hover:bg-input/50",
			secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: cn(CONTROL_SIZE_CLASSES.default, "px-4 py-2 has-[>svg]:px-3"),
			xs: cn(CONTROL_SIZE_CLASSES.xs, "gap-1.5 px-3 has-[>svg]:px-2.5"),
			sm: cn(CONTROL_SIZE_CLASSES.sm, "gap-1.5 px-3 has-[>svg]:px-2.5"),
			lg: cn(CONTROL_SIZE_CLASSES.lg, "px-6 has-[>svg]:px-4"),
			icon: "size-9",
			"icon-xs": "size-6",
			"icon-sm": "size-8",
			"icon-lg": "size-10"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button$1({ className, variant, size, ...props }) {
	return /* @__PURE__ */ jsx(Button, {
		"data-slot": "button",
		"data-size": size ?? "default",
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
//#endregion
export { CONTROL_SIZE_CLASSES as i, buttonVariants as n, focusRing as r, Button$1 as t };
