import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import { Dialog, DialogBackdrop, DialogPopup, DialogPortal, DialogViewport } from "./dialog.js";
import "react";
import { MagnifyingGlassIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Command as Command$1 } from "cmdk";
//#region src/components/ui/command.tsx
function Command({ className, ...props }) {
	return /* @__PURE__ */ jsx(Command$1, {
		"data-slot": "command",
		className: cn("flex h-full w-full flex-col overflow-hidden rounded-(--radius) bg-popover text-popover-foreground", className),
		...props
	});
}
function CommandDialog({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Dialog, {
		...props,
		children: /* @__PURE__ */ jsxs(DialogPortal, { children: [/* @__PURE__ */ jsx(DialogBackdrop, {}), /* @__PURE__ */ jsx(DialogViewport, {
			className: "flex items-start justify-center p-4 pt-[12vh]",
			children: /* @__PURE__ */ jsx(DialogPopup, {
				className: cn("overflow-hidden p-0 sm:max-w-lg", className),
				children: /* @__PURE__ */ jsx(Command, { children })
			})
		})] })
	});
}
function CommandInput({ className, ...props }) {
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "command-input-wrapper",
		className: "flex items-center gap-2 border-b border-border px-3",
		children: [/* @__PURE__ */ jsx(MagnifyingGlassIcon, {
			"aria-hidden": "true",
			className: "size-4 shrink-0 text-muted-foreground"
		}), /* @__PURE__ */ jsx(Command$1.Input, {
			"data-slot": "command-input",
			className: cn("flex h-10 w-full bg-transparent py-3 text-sm text-foreground outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50", className),
			...props
		})]
	});
}
function CommandList({ className, ...props }) {
	return /* @__PURE__ */ jsx(Command$1.List, {
		"data-slot": "command-list",
		className: cn("max-h-72 scroll-py-1 overflow-y-auto overflow-x-hidden p-1", className),
		...props
	});
}
function CommandEmpty({ className, ...props }) {
	return /* @__PURE__ */ jsx(Command$1.Empty, {
		"data-slot": "command-empty",
		className: cn("px-3 py-6 text-center text-sm text-muted-foreground", className),
		...props
	});
}
function CommandGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx(Command$1.Group, {
		"data-slot": "command-group",
		className: cn("overflow-hidden p-1 text-foreground [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground", className),
		...props
	});
}
function CommandItem({ className, ...props }) {
	return /* @__PURE__ */ jsx(Command$1.Item, {
		"data-slot": "command-item",
		className: cn("relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none select-none", "data-[selected=true]:bg-accent data-[selected=true]:text-accent-foreground aria-disabled:pointer-events-none aria-disabled:opacity-50", className),
		...props
	});
}
function CommandSeparator({ className, ...props }) {
	return /* @__PURE__ */ jsx(Command$1.Separator, {
		"data-slot": "command-separator",
		className: cn("-mx-1 my-1 h-px bg-border", className),
		...props
	});
}
function CommandShortcut({ className, ...props }) {
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "command-shortcut",
		className: cn("ml-auto text-xs tracking-widest text-muted-foreground", className),
		...props
	});
}
//#endregion
export { Command, CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator, CommandShortcut };
