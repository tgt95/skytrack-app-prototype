import { t as cn } from "./chunks/utils-Cr_eCEw3.js";
import { Button } from "./button.js";
import { Input } from "./input.js";
import * as React from "react";
import { MagnifyingGlassIcon, XIcon } from "@phosphor-icons/react";
import { jsx } from "react/jsx-runtime";
//#region src/components/ui/search.tsx
function Search({ value: valueProp, defaultValue = "", onValueChange, onClear, appearance = "default", disabled, className, onChange, ...props }) {
	const [internalValue, setInternalValue] = React.useState(defaultValue);
	const isControlled = valueProp !== void 0;
	const value = isControlled ? valueProp : internalValue;
	const setValue = (nextValue) => {
		if (!isControlled) setInternalValue(nextValue);
		onValueChange?.(nextValue);
	};
	return /* @__PURE__ */ jsx(Input, {
		...props,
		type: "text",
		role: "searchbox",
		disabled,
		"data-appearance": appearance,
		value,
		onChange: (event) => {
			onChange?.(event);
			setValue(event.currentTarget.value);
		},
		startAdornment: /* @__PURE__ */ jsx(MagnifyingGlassIcon, { "aria-hidden": "true" }),
		endAdornment: value ? /* @__PURE__ */ jsx(Button, {
			type: "button",
			variant: "ghost",
			size: "icon-xs",
			disabled,
			"aria-label": "Clear search",
			onClick: () => {
				setValue("");
				onClear?.();
			},
			children: /* @__PURE__ */ jsx(XIcon, { "aria-hidden": "true" })
		}) : void 0,
		className: cn("w-full", appearance === "fluid" && "min-h-16 items-start bg-muted/30 py-2", className)
	});
}
//#endregion
export { Search };
