import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import { Drawer, DrawerBackdrop, DrawerPopup, DrawerPortal, DrawerViewport } from "./drawer.js";
import { Tooltip, TooltipArrow, TooltipPopup, TooltipPortal, TooltipPositioner, TooltipTrigger } from "./tooltip.js";
import * as React from "react";
import { SidebarSimpleIcon } from "@phosphor-icons/react";
import { Button } from "@base-ui/react/button";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
//#region src/components/ui/sidebar.tsx
var SIDEBAR_WIDTH = "16rem";
var SIDEBAR_WIDTH_ICON = "3rem";
var SIDEBAR_WIDTH_MOBILE = "18rem";
var SIDEBAR_KEYBOARD_SHORTCUT = "b";
var SidebarContext = React.createContext(null);
var SidebarIconCollapseContext = React.createContext(false);
function useIsMobile() {
	const [isMobile, setIsMobile] = React.useState(false);
	React.useEffect(() => {
		const mediaQuery = window.matchMedia("(max-width: 767px)");
		const update = () => setIsMobile(mediaQuery.matches);
		update();
		mediaQuery.addEventListener("change", update);
		return () => mediaQuery.removeEventListener("change", update);
	}, []);
	return isMobile;
}
function useSidebar() {
	const context = React.useContext(SidebarContext);
	if (!context) throw new Error("useSidebar must be used within a SidebarProvider.");
	return context;
}
function SidebarProvider({ defaultOpen = true, open: openProp, onOpenChange, className, style, children, ...props }) {
	const isMobile = useIsMobile();
	const [openState, setOpenState] = React.useState(defaultOpen);
	const [openMobile, setOpenMobile] = React.useState(false);
	const open = openProp ?? openState;
	const setOpen = React.useCallback((nextOpen) => {
		if (openProp === void 0) setOpenState(nextOpen);
		onOpenChange?.(nextOpen);
	}, [onOpenChange, openProp]);
	const toggleSidebar = React.useCallback(() => {
		if (isMobile) setOpenMobile((current) => !current);
		else setOpen(!open);
	}, [
		isMobile,
		open,
		setOpen
	]);
	React.useEffect(() => {
		const handleKeyDown = (event) => {
			if (event.key.toLowerCase() !== "b" || !(event.metaKey || event.ctrlKey) || event.altKey || event.shiftKey) return;
			const target = event.target;
			if (target instanceof HTMLElement && (target.isContentEditable || target.closest("input, textarea, select, [role=\"textbox\"], [contenteditable=\"true\"]"))) return;
			event.preventDefault();
			toggleSidebar();
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [toggleSidebar]);
	const contextValue = React.useMemo(() => ({
		state: open ? "expanded" : "collapsed",
		open,
		setOpen,
		openMobile,
		setOpenMobile,
		isMobile,
		toggleSidebar
	}), [
		open,
		setOpen,
		openMobile,
		isMobile,
		toggleSidebar
	]);
	return /* @__PURE__ */ jsx(SidebarContext.Provider, {
		value: contextValue,
		children: /* @__PURE__ */ jsx("div", {
			"data-slot": "sidebar-provider",
			"data-state": open ? "expanded" : "collapsed",
			className: cn("group/sidebar-wrapper flex min-h-svh w-full has-[>_[data-variant=inset]]:bg-sidebar", className),
			style: {
				"--sidebar-width": SIDEBAR_WIDTH,
				"--sidebar-width-icon": SIDEBAR_WIDTH_ICON,
				"--sidebar-width-mobile": SIDEBAR_WIDTH_MOBILE,
				...style
			},
			...props,
			children
		})
	});
}
function Sidebar({ side = "left", variant = "sidebar", collapsible = "offcanvas", gapClassName, containerClassName, className, children, dir, style, ...props }) {
	const { open, openMobile, setOpenMobile, isMobile } = useSidebar();
	const state = open ? "expanded" : "collapsed";
	if (collapsible === "none" && !isMobile) return /* @__PURE__ */ jsx("aside", {
		"data-slot": "sidebar",
		"data-sidebar": "sidebar",
		"data-side": side,
		"data-variant": variant,
		"data-collapsible": "none",
		"data-icon-collapsed": "false",
		dir,
		className: cn("group/sidebar flex h-full w-(--sidebar-width) shrink-0 flex-col overflow-hidden border-r border-sidebar-border bg-sidebar text-sidebar-foreground data-[variant=inset]:border-r-0", variant === "floating" && "m-2 rounded-(--radius) border border-sidebar-border shadow-sm", side === "right" && variant === "inset" && "border-l border-sidebar-border", side === "right" && "order-last", className),
		style,
		...props,
		children
	});
	if (isMobile) return /* @__PURE__ */ jsx(Drawer, {
		open: openMobile,
		onOpenChange: setOpenMobile,
		swipeDirection: side,
		children: /* @__PURE__ */ jsxs(DrawerPortal, { children: [/* @__PURE__ */ jsx(DrawerBackdrop, { className: "bg-black/50" }), /* @__PURE__ */ jsx(DrawerViewport, {
			side,
			children: /* @__PURE__ */ jsx(DrawerPopup, {
				side,
				dir,
				"data-slot": "sidebar-mobile",
				"data-sidebar": "sidebar",
				"data-side": side,
				"data-variant": variant,
				"data-state": openMobile ? "expanded" : "collapsed",
				"data-icon-collapsed": "false",
				className: cn("h-dvh max-w-none rounded-none border-0 bg-sidebar p-0 text-sidebar-foreground shadow-lg", className),
				style: {
					width: "var(--sidebar-width-mobile)",
					...style
				},
				...props,
				children
			})
		})] })
	});
	const panelWidth = !open && collapsible === "icon" ? "var(--sidebar-width-icon)" : "var(--sidebar-width)";
	const gapWidth = !open && collapsible === "offcanvas" ? "0px" : panelWidth;
	const offset = open || collapsible === "icon" ? "0px" : "calc(var(--sidebar-width) * -1)";
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("div", {
		"data-slot": "sidebar-gap",
		"data-sidebar": "gap",
		"data-side": side,
		"data-variant": variant,
		"data-collapsible": collapsible,
		"data-state": state,
		"aria-hidden": "true",
		className: cn("relative hidden h-svh shrink-0 transition-[width] duration-200 ease-linear md:block", side === "right" && "order-last", gapClassName),
		style: { width: gapWidth }
	}), /* @__PURE__ */ jsx("div", {
		"data-slot": "sidebar-container",
		"data-sidebar": "container",
		"data-side": side,
		"data-variant": variant,
		"data-collapsible": collapsible,
		"data-state": state,
		className: cn("fixed inset-y-0 z-30 hidden h-svh w-(--sidebar-width) transition-[left,right,width] duration-200 ease-linear md:flex", side === "left" ? "left-0" : "right-0", !open && collapsible === "offcanvas" && "pointer-events-none", containerClassName),
		style: {
			[side]: open || collapsible === "icon" ? 0 : offset,
			width: panelWidth
		},
		children: /* @__PURE__ */ jsx(SidebarIconCollapseContext.Provider, {
			value: !open && collapsible === "icon",
			children: /* @__PURE__ */ jsx("aside", {
				"data-slot": "sidebar",
				"data-sidebar": "sidebar",
				"data-side": side,
				"data-variant": variant,
				"data-collapsible": collapsible,
				"data-state": state,
				"data-icon-collapsed": !open && collapsible === "icon",
				dir,
				className: cn("group/sidebar flex h-full w-full flex-col overflow-hidden border-r border-sidebar-border bg-sidebar text-sidebar-foreground data-[variant=inset]:border-r-0", variant === "floating" && "m-2 h-[calc(100%-1rem)] w-[calc(100%-1rem)] rounded-(--radius) border border-sidebar-border shadow-sm", side === "right" && variant === "inset" && "border-l border-sidebar-border", !open && collapsible === "icon" && "w-(--sidebar-width-icon)", className),
				style: {
					width: variant === "floating" ? "calc(100% - 1rem)" : "100%",
					...style
				},
				...props,
				children
			})
		})
	})] });
}
function SidebarTrigger({ className, onClick, ...props }) {
	const { toggleSidebar, open, openMobile, isMobile } = useSidebar();
	const isExpanded = isMobile ? openMobile : open;
	const label = isExpanded ? "Collapse sidebar" : "Expand sidebar";
	const button = /* @__PURE__ */ jsxs(Button, {
		"data-slot": "sidebar-trigger",
		"data-sidebar": "trigger",
		type: "button",
		"aria-label": label,
		className: cn("inline-flex size-8 shrink-0 cursor-pointer items-center justify-center rounded-(--radius) text-sidebar-foreground transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sidebar-ring", className),
		onClick: (event) => {
			onClick?.(event);
			if (!event.defaultPrevented) toggleSidebar();
		},
		...props,
		children: [/* @__PURE__ */ jsx(SidebarSimpleIcon, {
			"aria-hidden": "true",
			className: "size-4",
			weight: isExpanded ? "regular" : "fill"
		}), /* @__PURE__ */ jsx("span", {
			className: "sr-only",
			children: label
		})]
	});
	return /* @__PURE__ */ jsxs(Tooltip, { children: [/* @__PURE__ */ jsx(TooltipTrigger, { render: button }), /* @__PURE__ */ jsx(TooltipPortal, { children: /* @__PURE__ */ jsx(TooltipPositioner, {
		side: "bottom",
		sideOffset: 8,
		children: /* @__PURE__ */ jsxs(TooltipPopup, { children: [
			/* @__PURE__ */ jsx(TooltipArrow, {}),
			label,
			" (⌘/Ctrl+B)"
		] })
	}) })] });
}
function SidebarRail({ className, ...props }) {
	const { toggleSidebar } = useSidebar();
	return /* @__PURE__ */ jsx("button", {
		"data-slot": "sidebar-rail",
		"data-sidebar": "rail",
		type: "button",
		"aria-label": "Toggle sidebar",
		tabIndex: -1,
		onClick: toggleSidebar,
		className: cn("absolute inset-y-0 z-20 hidden w-4 -translate-x-1/2 cursor-ew-resize transition-all after:absolute after:inset-y-0 after:left-1/2 after:w-px hover:after:bg-sidebar-border focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sidebar-ring md:block", "group-data-[side=left]/sidebar:-right-4 group-data-[side=right]/sidebar:left-0", className),
		...props
	});
}
function SidebarInset({ className, ...props }) {
	return /* @__PURE__ */ jsx("main", {
		"data-slot": "sidebar-inset",
		"data-sidebar": "inset",
		className: cn("relative flex min-h-svh min-w-0 flex-1 flex-col bg-background", "group-has-[>_[data-variant=inset]]/sidebar-wrapper:min-h-[calc(100svh-1rem)] md:group-has-[>_[data-variant=inset]]/sidebar-wrapper:m-2 md:group-has-[>_[data-variant=inset]]/sidebar-wrapper:ml-0 md:group-has-[>_[data-variant=inset]]/sidebar-wrapper:rounded-(--radius) md:group-has-[>_[data-variant=inset]]/sidebar-wrapper:border md:group-has-[>_[data-variant=inset]]/sidebar-wrapper:border-border md:group-has-[>_[data-variant=inset]]/sidebar-wrapper:shadow-sm", className),
		...props
	});
}
function SidebarHeader({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "sidebar-header",
		"data-sidebar": "header",
		className: cn("flex flex-col gap-2 p-2", className),
		...props
	});
}
function SidebarFooter({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "sidebar-footer",
		"data-sidebar": "footer",
		className: cn("mt-auto flex flex-col gap-2 p-2", className),
		...props
	});
}
function SidebarContent({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "sidebar-content",
		"data-sidebar": "content",
		className: cn("flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[icon-collapsed=true]/sidebar:overflow-hidden", className),
		...props
	});
}
function SidebarGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "sidebar-group",
		"data-sidebar": "group",
		className: cn("relative flex w-full min-w-0 flex-col p-2", className),
		...props
	});
}
function SidebarGroupLabel({ className, render, children, ...props }) {
	const labelClassName = cn("flex h-8 shrink-0 items-center rounded-(--radius) px-2 text-xs sub-heading text-sidebar-foreground/70 outline-none ring-sidebar-ring transition-[margin,opacity] duration-200 ease-linear focus-visible:ring-2 group-data-[icon-collapsed=true]/sidebar:-mt-8 group-data-[icon-collapsed=true]/sidebar:opacity-0", render && "cursor-pointer", className);
	if (render) return /* @__PURE__ */ jsx(Button, {
		render,
		"data-slot": "sidebar-group-label",
		"data-sidebar": "group-label",
		className: labelClassName,
		...props,
		children
	});
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "sidebar-group-label",
		"data-sidebar": "group-label",
		className: labelClassName,
		...props,
		children
	});
}
function SidebarGroupAction({ className, ...props }) {
	return /* @__PURE__ */ jsx(Button, {
		"data-slot": "sidebar-group-action",
		"data-sidebar": "group-action",
		type: "button",
		className: cn("flex size-5 cursor-pointer items-center justify-center rounded-(--radius) text-sidebar-foreground outline-none ring-sidebar-ring transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 [&>svg]:size-4 group-data-[icon-collapsed=true]/sidebar:hidden", className),
		...props
	});
}
function SidebarGroupContent({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "sidebar-group-content",
		"data-sidebar": "group-content",
		className: cn("w-full text-sm", className),
		...props
	});
}
function SidebarMenu({ className, ...props }) {
	return /* @__PURE__ */ jsx("ul", {
		"data-slot": "sidebar-menu",
		"data-sidebar": "menu",
		className: cn("flex w-full min-w-0 flex-col gap-1", className),
		...props
	});
}
function SidebarMenuItem({ className, ...props }) {
	return /* @__PURE__ */ jsx("li", {
		"data-slot": "sidebar-menu-item",
		"data-sidebar": "menu-item",
		className: cn("group/menu-item relative", className),
		...props
	});
}
function SidebarMenuButton({ className, isActive = false, size = "default", variant = "default", tooltip, ...props }) {
	const isIconCollapsed = React.useContext(SidebarIconCollapseContext);
	const button = /* @__PURE__ */ jsx(Button, {
		"data-slot": "sidebar-menu-button",
		"data-sidebar": "menu-button",
		"data-size": size,
		"data-active": isActive ? "" : void 0,
		"aria-current": isActive ? "page" : void 0,
		type: "button",
		className: cn("peer/menu-button group/sidebar-menu-button flex w-full min-w-0 cursor-pointer items-center gap-2 overflow-hidden rounded-(--radius) px-2 text-left text-sm outline-none transition-[width,height,padding] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 focus-visible:ring-sidebar-ring active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 [&>svg]:size-4 [&>svg]:shrink-0 [&>span:last-child]:truncate", size === "default" && "h-8", size === "sm" && "h-7 text-xs", size === "lg" && "h-12 text-sm group-data-[icon-collapsed=true]/sidebar:!p-0", variant === "outline" && "border border-sidebar-border bg-background shadow-[0_0_0_1px_var(--sidebar-border)] hover:bg-sidebar-accent hover:shadow-[0_0_0_1px_var(--sidebar-accent)]", "data-active:bg-sidebar-accent data-active:font-medium data-active:text-sidebar-accent-foreground", "group-data-[icon-collapsed=true]/sidebar:size-8 group-data-[icon-collapsed=true]/sidebar:justify-center group-data-[icon-collapsed=true]/sidebar:p-2 group-data-[icon-collapsed=true]/sidebar:[&>span]:sr-only", className),
		...props
	});
	if (!tooltip?.trim() || !isIconCollapsed) return button;
	return /* @__PURE__ */ jsxs(Tooltip, { children: [/* @__PURE__ */ jsx(TooltipTrigger, { render: button }), /* @__PURE__ */ jsx(TooltipPortal, { children: /* @__PURE__ */ jsx(TooltipPositioner, {
		side: "right",
		sideOffset: 8,
		children: /* @__PURE__ */ jsxs(TooltipPopup, { children: [/* @__PURE__ */ jsx(TooltipArrow, {}), tooltip] })
	}) })] });
}
function SidebarMenuAction({ className, ...props }) {
	return /* @__PURE__ */ jsx(Button, {
		"data-slot": "sidebar-menu-action",
		"data-sidebar": "menu-action",
		type: "button",
		className: cn("absolute right-1 top-1.5 flex size-5 cursor-pointer items-center justify-center rounded-(--radius) text-sidebar-foreground outline-none ring-sidebar-ring transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 [&>svg]:size-3.5 group-data-[icon-collapsed=true]/sidebar:hidden", className),
		...props
	});
}
function SidebarMenuBadge({ className, render, children, ...props }) {
	const positionClassName = "pointer-events-none absolute right-2 group-data-[icon-collapsed=true]/sidebar:hidden peer-data-[size=sm]/menu-button:top-1 peer-data-[size=default]/menu-button:top-1.5 peer-data-[size=lg]/menu-button:top-3";
	if (render) {
		const renderProps = render.props;
		return React.cloneElement(render, {
			...props,
			"data-slot": "sidebar-menu-badge",
			"data-sidebar": "menu-badge",
			className: cn(positionClassName, className, renderProps.className),
			children: children ?? renderProps.children
		});
	}
	const badgeClassName = cn(positionClassName, "flex h-5 min-w-5 items-center justify-center rounded-(--radius) px-1 text-xs font-medium tabular-nums text-sidebar-foreground", className);
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "sidebar-menu-badge",
		"data-sidebar": "menu-badge",
		className: badgeClassName,
		...props,
		children
	});
}
function SidebarMenuSkeleton({ className, showIcon = false, ...props }) {
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "sidebar-menu-skeleton",
		"data-sidebar": "menu-skeleton",
		className: cn("flex h-8 items-center gap-2 rounded-(--radius) px-2", className),
		...props,
		children: [showIcon && /* @__PURE__ */ jsx("span", { className: "size-4 shrink-0 rounded-(--radius) bg-sidebar-accent" }), /* @__PURE__ */ jsx("span", { className: "h-4 max-w-(--skeleton-width,60%) flex-1 rounded-(--radius) bg-sidebar-accent" })]
	});
}
function SidebarMenuSub({ className, ...props }) {
	return /* @__PURE__ */ jsx("ul", {
		"data-slot": "sidebar-menu-sub",
		"data-sidebar": "menu-sub",
		className: cn("mx-3.5 flex min-w-0 translate-x-px flex-col gap-1 border-l border-sidebar-border px-2.5 py-0.5 group-data-[icon-collapsed=true]/sidebar:hidden", className),
		...props
	});
}
function SidebarMenuSubItem({ className, ...props }) {
	return /* @__PURE__ */ jsx("li", {
		"data-slot": "sidebar-menu-sub-item",
		"data-sidebar": "menu-sub-item",
		className: cn("group/menu-sub-item relative", className),
		...props
	});
}
function SidebarMenuSubButton({ className, isActive = false, size = "md", ...props }) {
	return /* @__PURE__ */ jsx(Button, {
		"data-slot": "sidebar-menu-sub-button",
		"data-sidebar": "menu-sub-button",
		"data-size": size,
		"data-active": isActive ? "" : void 0,
		"aria-current": isActive ? "page" : void 0,
		type: "button",
		className: cn("flex h-7 min-w-0 cursor-pointer items-center gap-2 overflow-hidden rounded-(--radius) px-2 text-sidebar-foreground outline-none ring-sidebar-ring hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 [&>svg]:size-4 [&>svg]:shrink-0 [&>span:last-child]:truncate data-active:bg-sidebar-accent data-active:text-sidebar-accent-foreground", size === "sm" && "text-xs", size === "md" && "text-sm", className),
		...props
	});
}
//#endregion
export { SIDEBAR_KEYBOARD_SHORTCUT, SIDEBAR_WIDTH, SIDEBAR_WIDTH_ICON, SIDEBAR_WIDTH_MOBILE, Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarGroupAction, SidebarGroupContent, SidebarGroupLabel, SidebarHeader, SidebarInset, SidebarMenu, SidebarMenuAction, SidebarMenuBadge, SidebarMenuButton, SidebarMenuItem, SidebarMenuSkeleton, SidebarMenuSub, SidebarMenuSubButton, SidebarMenuSubItem, SidebarProvider, SidebarRail, SidebarTrigger, useSidebar };
