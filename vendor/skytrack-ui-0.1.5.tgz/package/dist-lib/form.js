import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { Form as Form$1 } from "@base-ui/react/form";
//#region src/components/ui/form.tsx
function Form({ className, ...props }) {
	return /* @__PURE__ */ jsx(Form$1, {
		"data-slot": "form",
		className: cn("flex w-full flex-col gap-4", className),
		...props
	});
}
//#endregion
export { Form };
