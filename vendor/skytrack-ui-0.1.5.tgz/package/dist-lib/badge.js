import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import "react";
import { cva } from "class-variance-authority";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
//#region src/components/ui/badge.tsx
var badgeVariants = cva("uppercase tracking-wide", {
	variants: {
		status: {
			default: "bg-muted text-foreground",
			success: "bg-success text-(--foreground-inverse)",
			warning: "bg-warning text-(--foreground-inverse)",
			error: "bg-destructive text-(--foreground-inverse)",
			processing: "bg-primary text-primary-foreground",
			secondary: "bg-secondary text-secondary-foreground",
			outline: "border border-input bg-background text-foreground"
		},
		size: {
			default: "h-5 min-w-5 px-1.5 text-xs",
			sm: "h-4 min-w-4 px-1 text-[11px]"
		}
	},
	defaultVariants: {
		status: "default",
		size: "default"
	}
});
/** Numeric counts above `maxCount` collapse to `{maxCount}+`; anything else passes through. */
function formatCount(count, maxCount) {
	if (typeof count === "number" && count > maxCount) return `${maxCount}+`;
	return count;
}
/**
* Count / dot / status badge.
* Two modes: anchor (`<Badge count={n}><Icon/></Badge>`) vs label pill (`<Badge count='text' />`).
*
* `className` targets the PILL (the count or dot), never the anchor wrapper — size the
* anchor through `children`. With no `children` the pill renders standalone (inline, not
* absolutely positioned); with `children` it is anchored to the child's top-end corner.
* Any other span props (`id`, `aria-label`, handlers, ...) land on the pill.
*/
function Badge({ className, status, size, count, maxCount = 99, showZero = false, dot = false, animationPing = false, children, ...props }) {
	const value = formatCount(count, maxCount);
	if (!(dot || value != null && (showZero || value !== 0))) return /* @__PURE__ */ jsx(Fragment, { children });
	const pill = /* @__PURE__ */ jsxs("span", {
		"data-slot": "badge-count",
		className: cn("relative inline-flex items-center justify-center leading-none font-medium tabular-nums", dot ? cn("size-1.5 p-0 rounded-full", badgeVariants({
			status,
			size: null
		})) : cn("", badgeVariants({
			status,
			size
		})), className),
		...props,
		children: [dot ? null : value, animationPing ? /* @__PURE__ */ jsx("span", {
			"aria-hidden": true,
			className: "absolute inset-0 animate-ping bg-primary/40"
		}) : null]
	});
	if (children == null) return pill;
	return /* @__PURE__ */ jsxs("span", {
		"data-slot": "badge",
		className: "relative inline-flex shrink-0",
		children: [children, /* @__PURE__ */ jsx("span", {
			className: "absolute top-0 inset-e-0 translate-x-1/2 -translate-y-1/2",
			children: pill
		})]
	});
}
//#endregion
export { Badge, badgeVariants };
