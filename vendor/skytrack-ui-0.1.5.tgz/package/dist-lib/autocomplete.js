import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import { i as CONTROL_SIZE_CLASSES, r as focusRing } from "./chunks/button-1Z23yCSW.js";
import "react";
import { CaretDownIcon, MagnifyingGlassIcon, XIcon } from "@phosphor-icons/react";
import { cva } from "class-variance-authority";
import { jsx } from "react/jsx-runtime";
import { Autocomplete as Autocomplete$1 } from "@base-ui/react/autocomplete";
//#region src/components/ui/autocomplete.tsx
function Autocomplete(props) {
	const RootImpl = Autocomplete$1.Root;
	return /* @__PURE__ */ jsx(RootImpl, { ...props });
}
var autocompleteInputVariants = cva(cn("w-full min-w-0 border-0 bg-transparent text-sm text-foreground outline-hidden", "placeholder:text-muted-foreground"), {
	variants: {
		/** `group` = input inside `AutocompleteInputGroup`, `standalone` = bordered input. */
		context: {
			group: "h-full px-1",
			standalone: "rounded-(--radius) border border-input bg-background px-3 shadow-xs focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50"
		},
		size: {
			xs: "text-xs",
			sm: "text-sm",
			default: "text-sm",
			lg: "text-sm"
		}
	},
	compoundVariants: [
		"xs",
		"sm",
		"default",
		"lg"
	].map((size) => ({
		context: "standalone",
		size,
		class: CONTROL_SIZE_CLASSES[size]
	})),
	defaultVariants: {
		context: "standalone",
		size: "default"
	}
});
function AutocompleteInput({ className, context, size, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Input, {
		"data-slot": "autocomplete-input",
		"data-size": size ?? "default",
		className: cn(autocompleteInputVariants({
			context,
			size
		}), className),
		...props
	});
}
var autocompleteInputGroupVariants = cva(cn("relative flex w-full items-center gap-1 rounded-(--radius) border border-input bg-background text-foreground shadow-xs transition-colors", "focus-within:border-ring focus-within:ring-[3px] focus-within:ring-ring/50", "has-[button]:px-1", "data-disabled:cursor-not-allowed data-disabled:opacity-50", "data-invalid:border-destructive data-invalid:ring-destructive/20"), {
	variants: { size: {
		xs: "min-h-6 px-2",
		sm: "min-h-8 px-2",
		default: "min-h-9 px-2",
		lg: "min-h-10 px-2"
	} },
	compoundVariants: [
		"xs",
		"sm",
		"default",
		"lg"
	].map((size) => ({
		size,
		class: CONTROL_SIZE_CLASSES[size]
	})),
	defaultVariants: { size: "default" }
});
function AutocompleteInputGroup({ className, size, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.InputGroup, {
		"data-slot": "autocomplete-input-group",
		"data-size": size ?? "default",
		className: cn(autocompleteInputGroupVariants({ size }), className),
		...props
	});
}
function AutocompleteTrigger({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Trigger, {
		"data-slot": "autocomplete-trigger",
		className: cn("flex size-6 cursor-pointer shrink-0 items-center justify-center rounded-(--radius) border-0 bg-transparent p-0 text-muted-foreground transition-colors", "hover:bg-accent hover:text-accent-foreground", "data-pressed:bg-accent data-pressed:text-accent-foreground", "data-disabled:pointer-events-none data-disabled:opacity-50", focusRing, className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretDownIcon, { className: "size-4" })
	});
}
/** Standalone trigger used by the input-inside-popup pattern. */
function AutocompleteTriggerButton({ className, size = "default", children, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Trigger, {
		"data-slot": "autocomplete-trigger-button",
		"data-size": size,
		className: cn("flex w-full cursor-pointer items-center justify-between gap-2 whitespace-nowrap rounded-(--radius) border border-input bg-background px-3 text-foreground shadow-xs transition-colors", CONTROL_SIZE_CLASSES[size], "data-placeholder:text-muted-foreground", "hover:not-data-disabled:bg-accent hover:not-data-disabled:text-accent-foreground", "data-disabled:cursor-not-allowed data-disabled:opacity-50", focusRing, className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(MagnifyingGlassIcon, { className: "size-4 shrink-0 text-muted-foreground" })
	});
}
function AutocompleteIcon({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Icon, {
		"data-slot": "autocomplete-icon",
		className: cn("flex size-4 shrink-0 items-center justify-center text-muted-foreground", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretDownIcon, { className: "size-4" })
	});
}
function AutocompleteClear({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Clear, {
		"data-slot": "autocomplete-clear",
		className: cn("flex size-6 cursor-pointer shrink-0 items-center justify-center rounded-(--radius) border-0 bg-transparent p-0 text-muted-foreground transition-colors", "hover:bg-accent hover:text-accent-foreground", "data-disabled:pointer-events-none data-disabled:opacity-50", focusRing, className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(XIcon, { className: "size-4" })
	});
}
/** Renders the current input value. Renders no element of its own. */
function AutocompleteValue(props) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Value, { ...props });
}
function AutocompletePortal({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Portal, {
		"data-slot": "autocomplete-portal",
		className: cn(className),
		...props
	});
}
function AutocompleteBackdrop({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Backdrop, {
		"data-slot": "autocomplete-backdrop",
		className: cn("fixed inset-0 z-50 bg-black/20 transition-opacity data-starting-style:opacity-0 data-ending-style:opacity-0", className),
		...props
	});
}
function AutocompletePositioner({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Positioner, {
		"data-slot": "autocomplete-positioner",
		className: cn("z-50 outline-hidden", className),
		...props
	});
}
function AutocompletePopup({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Popup, {
		"data-slot": "autocomplete-popup",
		className: cn("w-[var(--anchor-width)] max-w-[var(--available-width)] origin-[var(--transform-origin)] rounded-(--radius) border border-border bg-popover text-popover-foreground shadow-md", "transition-[transform,scale,opacity] duration-150 ease-out", "data-starting-style:scale-95 data-starting-style:opacity-0", "data-ending-style:scale-95 data-ending-style:opacity-0", className),
		...props
	});
}
function AutocompleteArrow({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Arrow, {
		"data-slot": "autocomplete-arrow",
		className: cn("flex size-4 items-center justify-center text-muted-foreground", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretDownIcon, { className: "size-3 rotate-180" })
	});
}
function AutocompleteStatus({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Status, {
		"data-slot": "autocomplete-status",
		className: cn("empty:hidden", className),
		...props
	});
}
function AutocompleteEmpty({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Empty, {
		"data-slot": "autocomplete-empty",
		className: cn("px-2 py-3 text-sm leading-none text-muted-foreground empty:hidden", className),
		...props,
		children: children === void 0 ? "No results found." : children
	});
}
function AutocompleteList({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.List, {
		"data-slot": "autocomplete-list",
		className: cn("max-h-[min(22.5rem,var(--available-height))] scroll-py-1 overflow-y-auto overscroll-contain py-1 outline-hidden data-empty:p-0", className),
		...props
	});
}
function AutocompleteRow({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Row, {
		"data-slot": "autocomplete-row",
		className: cn(className),
		...props
	});
}
function AutocompleteItem({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Item, {
		"data-slot": "autocomplete-item",
		className: cn("flex cursor-pointer items-center gap-2 rounded-(--radius) px-2 py-1.5 text-sm select-none", "data-highlighted:bg-accent data-highlighted:text-accent-foreground", "data-disabled:pointer-events-none data-disabled:opacity-50", focusRing, className),
		...props,
		children
	});
}
function AutocompleteGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Group, {
		"data-slot": "autocomplete-group",
		className: cn("block pb-1 last:pb-0", className),
		...props
	});
}
function AutocompleteGroupLabel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.GroupLabel, {
		"data-slot": "autocomplete-group-label",
		className: cn("px-2 py-1.5 text-xs leading-5 font-medium text-muted-foreground select-none", className),
		...props
	});
}
function AutocompleteSeparator({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Separator, {
		"data-slot": "autocomplete-separator",
		className: cn("-mx-1 my-1 h-px bg-border", className),
		...props
	});
}
/** Renders the filtered items of the enclosing group/list. Renders no element of its own. */
function AutocompleteCollection(props) {
	return /* @__PURE__ */ jsx(Autocomplete$1.Collection, { ...props });
}
/** Re-exported Base UI helpers so demos never need the raw package. */
var useAutocompleteFilter = Autocomplete$1.useFilter;
var useAutocompleteFilteredItems = Autocomplete$1.useFilteredItems;
//#endregion
export { Autocomplete, AutocompleteArrow, AutocompleteBackdrop, AutocompleteClear, AutocompleteCollection, AutocompleteEmpty, AutocompleteGroup, AutocompleteGroupLabel, AutocompleteIcon, AutocompleteInput, AutocompleteInputGroup, AutocompleteItem, AutocompleteList, AutocompletePopup, AutocompletePortal, AutocompletePositioner, AutocompleteRow, AutocompleteSeparator, AutocompleteStatus, AutocompleteTrigger, AutocompleteTriggerButton, AutocompleteValue, autocompleteInputGroupVariants, autocompleteInputVariants, useAutocompleteFilter, useAutocompleteFilteredItems };
