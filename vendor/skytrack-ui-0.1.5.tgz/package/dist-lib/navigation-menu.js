import { t as cn } from "./chunks/utils-QluraT_M.js";
import { focusRing } from "./button.js";
import "react";
import { CaretDown } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
import { NavigationMenu as NavigationMenu$1 } from "@base-ui/react/navigation-menu";
//#region src/components/ui/navigation-menu.tsx
function NavigationMenu({ className, ...props }) {
	return /* @__PURE__ */ jsx(NavigationMenu$1.Root, {
		"data-slot": "navigation-menu",
		className: cn("relative flex max-w-max flex-col", "data-[orientation=vertical]:flex-row", className),
		...props
	});
}
function NavigationMenuList({ className, ...props }) {
	return /* @__PURE__ */ jsx(NavigationMenu$1.List, {
		"data-slot": "navigation-menu-list",
		className: cn("flex list-none flex-row items-center gap-1", "data-[orientation=vertical]:flex-col data-[orientation=vertical]:items-stretch", className),
		...props
	});
}
function NavigationMenuItem({ className, ...props }) {
	return /* @__PURE__ */ jsx(NavigationMenu$1.Item, {
		"data-slot": "navigation-menu-item",
		className: cn("relative", className),
		...props
	});
}
function NavigationMenuTrigger({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(NavigationMenu$1.Trigger, {
		"data-slot": "navigation-menu-trigger",
		className: cn("group inline-flex h-9 cursor-pointer items-center justify-center gap-1 rounded-md bg-transparent px-3 text-sm font-medium text-foreground no-underline select-none transition-colors", "hover:bg-accent hover:text-accent-foreground", "data-[popup-open]:bg-accent data-[popup-open]:text-accent-foreground", "data-[orientation=vertical]:w-full data-[orientation=vertical]:justify-between", "disabled:pointer-events-none disabled:opacity-50 data-[disabled]:pointer-events-none data-[disabled]:opacity-50", "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", focusRing, className),
		...props,
		children
	});
}
function NavigationMenuIcon({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(NavigationMenu$1.Icon, {
		"data-slot": "navigation-menu-icon",
		className: cn("flex size-4 items-center justify-center transition-transform duration-200", "data-[popup-open]:rotate-180", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretDown, {})
	});
}
function NavigationMenuContent({ className, ...props }) {
	return /* @__PURE__ */ jsx(NavigationMenu$1.Content, {
		"data-slot": "navigation-menu-content",
		className: cn("h-full w-[calc(100vw-2.5rem)] p-2 md:w-max md:max-w-[25rem]", "transition-[opacity,transform,translate] duration-200 ease-out", "data-[starting-style]:opacity-0 data-[ending-style]:opacity-0", "data-[starting-style]:data-[activation-direction=left]:translate-x-[-50%]", "data-[starting-style]:data-[activation-direction=right]:translate-x-[50%]", "data-[ending-style]:data-[activation-direction=left]:translate-x-[50%]", "data-[ending-style]:data-[activation-direction=right]:translate-x-[-50%]", className),
		...props
	});
}
function NavigationMenuPortal({ className, ...props }) {
	return /* @__PURE__ */ jsx(NavigationMenu$1.Portal, {
		"data-slot": "navigation-menu-portal",
		className: cn(className),
		...props
	});
}
function NavigationMenuBackdrop({ className, ...props }) {
	return /* @__PURE__ */ jsx(NavigationMenu$1.Backdrop, {
		"data-slot": "navigation-menu-backdrop",
		className: cn("fixed inset-0 z-50 bg-foreground/20 transition-opacity duration-150", "data-[starting-style]:opacity-0 data-[ending-style]:opacity-0", className),
		...props
	});
}
function NavigationMenuPositioner({ className, ...props }) {
	return /* @__PURE__ */ jsx(NavigationMenu$1.Positioner, {
		"data-slot": "navigation-menu-positioner",
		className: cn("z-50 outline-hidden", "transition-[top,left,right,bottom,transform] duration-200 ease-out data-[instant]:transition-none", className),
		...props
	});
}
function NavigationMenuPopup({ className, ...props }) {
	return /* @__PURE__ */ jsx(NavigationMenu$1.Popup, {
		"data-slot": "navigation-menu-popup",
		className: cn("relative h-[var(--popup-height)] w-[var(--popup-width)] origin-[var(--transform-origin)] rounded-lg border border-border bg-popover text-popover-foreground shadow-md outline-hidden", "transition-[opacity,transform,width,height,scale] duration-200 ease-out", "data-[instant]:transition-none", "data-[starting-style]:scale-95 data-[starting-style]:opacity-0", "data-[ending-style]:scale-95 data-[ending-style]:opacity-0", className),
		...props
	});
}
function NavigationMenuViewport({ className, ...props }) {
	return /* @__PURE__ */ jsx(NavigationMenu$1.Viewport, {
		"data-slot": "navigation-menu-viewport",
		className: cn("relative h-full w-full overflow-hidden", className),
		...props
	});
}
function NavigationMenuArrowGlyph(props) {
	return /* @__PURE__ */ jsxs("svg", {
		width: "20",
		height: "10",
		viewBox: "0 0 20 10",
		fill: "none",
		"aria-hidden": "true",
		focusable: "false",
		...props,
		children: [/* @__PURE__ */ jsx("path", {
			d: "M1 9 L10 1 L19 9 Z",
			fill: "currentColor",
			stroke: "none",
			className: "text-popover"
		}), /* @__PURE__ */ jsx("path", {
			d: "M1 9 L10 1 L19 9",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: 1,
			strokeLinejoin: "round",
			strokeLinecap: "round",
			className: "text-border"
		})]
	});
}
function NavigationMenuArrow({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(NavigationMenu$1.Arrow, {
		"data-slot": "navigation-menu-arrow",
		className: cn("pointer-events-none absolute z-10 flex h-2.5 w-5 items-center justify-center", "data-[side=top]:bottom-[-9px] data-[side=top]:rotate-180", "data-[side=bottom]:top-[-9px]", "data-[side=left]:right-[-14px] data-[side=left]:rotate-90", "data-[side=right]:left-[-14px] data-[side=right]:-rotate-90", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(NavigationMenuArrowGlyph, {})
	});
}
function NavigationMenuLink({ className, ...props }) {
	return /* @__PURE__ */ jsx(NavigationMenu$1.Link, {
		"data-slot": "navigation-menu-link",
		className: cn("block cursor-pointer select-none rounded-md p-2 text-foreground no-underline transition-colors", "hover:bg-accent hover:text-accent-foreground", "data-[active]:bg-accent/60 data-[active]:font-medium", focusRing, className),
		...props
	});
}
//#endregion
export { NavigationMenu, NavigationMenuArrow, NavigationMenuBackdrop, NavigationMenuContent, NavigationMenuIcon, NavigationMenuItem, NavigationMenuLink, NavigationMenuList, NavigationMenuPopup, NavigationMenuPortal, NavigationMenuPositioner, NavigationMenuTrigger, NavigationMenuViewport };
