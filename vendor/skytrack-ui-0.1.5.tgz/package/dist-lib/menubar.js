import { t as cn } from "./chunks/utils-QluraT_M.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { Menubar as Menubar$1 } from "@base-ui/react/menubar";
//#region src/components/ui/menubar.tsx
/**
* Container for a row of `Menu.Root` instances. Menus themselves come from
* `@/components/ui/menu`; this only styles the bar that holds the triggers.
*/
function Menubar({ className, ...props }) {
	return /* @__PURE__ */ jsx(Menubar$1, {
		"data-slot": "menubar",
		className: cn("flex items-center gap-1 rounded-(--radius) border border-border bg-background p-1", "data-[orientation=vertical]:flex-col data-[orientation=vertical]:items-stretch", "data-[disabled]:opacity-50", className),
		...props
	});
}
//#endregion
export { Menubar };
