import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import { r as focusRing } from "./chunks/button-1Z23yCSW.js";
import { ToggleGroupContext } from "./toggle-group.js";
import * as React from "react";
import { cva } from "class-variance-authority";
import { jsx } from "react/jsx-runtime";
import { Toggle as Toggle$1 } from "@base-ui/react/toggle";
//#region src/components/ui/toggle.tsx
var toggleVariants = cva(cn("inline-flex cursor-pointer items-center justify-center gap-2 rounded-(--radius) text-sm font-medium whitespace-nowrap transition-colors select-none", "disabled:pointer-events-none disabled:opacity-50 data-disabled:pointer-events-none data-disabled:opacity-50", "data-pressed:bg-accent data-pressed:text-accent-foreground", "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", focusRing), {
	variants: {
		variant: {
			default: "bg-transparent hover:bg-muted hover:text-foreground",
			outline: "border border-input bg-transparent hover:bg-accent",
			segmented: "flex-1 justify-center rounded-(--radius) bg-transparent text-muted-foreground hover:bg-muted hover:text-foreground data-pressed:bg-card data-pressed:text-foreground data-pressed:shadow-sm",
			brand: "bg-transparent hover:bg-muted hover:text-foreground data-pressed:bg-primary data-pressed:text-primary-foreground"
		},
		size: {
			default: "h-9 px-3",
			xs: "h-6 px-2 text-xs",
			sm: "h-8 px-2 text-xs",
			lg: "h-10 px-4",
			icon: "size-9 p-0",
			"icon-xs": "size-6 p-0",
			"icon-sm": "size-8 p-0",
			"icon-lg": "size-10 p-0"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Toggle({ className, variant, size, ...props }) {
	const group = React.useContext(ToggleGroupContext);
	return /* @__PURE__ */ jsx(Toggle$1, {
		"data-slot": "toggle",
		className: cn(toggleVariants({
			variant: variant ?? group?.variant,
			size: size ?? group?.size
		}), className),
		...props
	});
}
//#endregion
export { Toggle, toggleVariants };
