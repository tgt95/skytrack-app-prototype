import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import "react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/components/ui/page-header.tsx
/** Page heading composition. Breadcrumbs and Toolbar are caller-composed; children can hold Tabs. */
function PageHeader({ breadcrumbs, title, toolbar, className, children, ...props }) {
	return /* @__PURE__ */ jsxs("header", {
		"data-slot": "page-header",
		className: cn("flex min-w-0 flex-col gap-4 border-border border-b p-4 has-[>[data-slot=page-header-breadcrumbs]]:pt-0 has-[>[data-slot=page-header-body]>[data-slot=page-header-content]>[data-slot=tabs-list][data-variant=line]]:pb-0", className),
		...props,
		children: [breadcrumbs != null && /* @__PURE__ */ jsx("div", {
			"data-slot": "page-header-breadcrumbs",
			className: "-mx-4 flex min-w-0 items-center border-border border-b p-2",
			children: breadcrumbs
		}), /* @__PURE__ */ jsxs("div", {
			"data-slot": "page-header-body",
			className: "flex min-w-0 flex-col gap-4",
			children: [/* @__PURE__ */ jsxs("div", {
				"data-slot": "page-header-main",
				className: "flex min-w-0 flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ jsx("h1", {
					"data-slot": "page-header-title",
					className: "h3 m-0 min-w-0 flex-1",
					children: title
				}), toolbar != null && /* @__PURE__ */ jsx("div", {
					"data-slot": "page-header-toolbar",
					className: "min-w-0 max-w-full overflow-x-auto sm:ml-auto sm:shrink-0",
					children: toolbar
				})]
			}), children != null && /* @__PURE__ */ jsx("div", {
				"data-slot": "page-header-content",
				className: "min-w-0 max-w-full overflow-x-auto has-[>[data-slot=tabs-list][data-variant=line]]:-mx-3",
				children
			})]
		})]
	});
}
//#endregion
export { PageHeader };
