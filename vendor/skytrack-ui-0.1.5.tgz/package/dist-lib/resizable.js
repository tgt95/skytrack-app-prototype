import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import * as React from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Group, Panel, Separator } from "react-resizable-panels";
//#region src/components/ui/resizable.tsx
var ResizableContext = React.createContext("horizontal");
function ResizablePanelGroup({ className, orientation = "horizontal", ...props }) {
	return /* @__PURE__ */ jsx(ResizableContext.Provider, {
		value: orientation,
		children: /* @__PURE__ */ jsx(Group, {
			"data-slot": "resizable-panel-group",
			"data-orientation": orientation,
			orientation,
			className: cn("h-full w-full", className),
			...props
		})
	});
}
function ResizablePanel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Panel, {
		"data-slot": "resizable-panel",
		className: cn("min-h-0 min-w-0", className),
		...props
	});
}
function ResizableHandle({ className, withHandle, ...props }) {
	const orientation = React.useContext(ResizableContext);
	return /* @__PURE__ */ jsx(Separator, {
		"data-slot": "resizable-handle",
		"data-orientation": orientation === "horizontal" ? "vertical" : "horizontal",
		className: cn("relative z-10 flex shrink-0 items-center justify-center bg-border outline-none transition-colors focus-visible:bg-primary/40 focus-visible:ring-1 focus-visible:ring-primary", orientation === "horizontal" ? "h-full w-px cursor-col-resize" : "h-px w-full cursor-row-resize", className),
		...props,
		children: withHandle && /* @__PURE__ */ jsx("span", {
			"data-slot": "resizable-handle-grip",
			className: "pointer-events-none absolute z-10 flex h-4 w-3 items-center justify-center rounded-[var(--radius)] border border-border bg-background text-muted-foreground",
			children: /* @__PURE__ */ jsxs("span", {
				className: cn("flex items-center justify-center", orientation === "horizontal" ? "h-2 flex-row gap-0.5" : "w-2 flex-col gap-0.5"),
				children: [/* @__PURE__ */ jsx("span", { className: cn("bg-current", orientation === "horizontal" ? "h-2 w-px" : "h-px w-2") }), /* @__PURE__ */ jsx("span", { className: cn("bg-current", orientation === "horizontal" ? "h-2 w-px" : "h-px w-2") })]
			})
		})
	});
}
//#endregion
export { ResizableHandle, ResizablePanel, ResizablePanelGroup };
