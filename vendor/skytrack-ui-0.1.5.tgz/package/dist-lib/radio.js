import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import { r as focusRing } from "./chunks/button-1Z23yCSW.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { Radio } from "@base-ui/react/radio";
import { RadioGroup as RadioGroup$1 } from "@base-ui/react/radio-group";
//#region src/components/ui/radio.tsx
function RadioRoot({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Radio.Root, {
		"data-slot": "radio",
		className: cn("flex size-4 cursor-pointer shrink-0 items-center justify-center rounded-full border border-input bg-background p-0 text-(--foreground-inverse) transition-colors", "data-checked:border-primary data-checked:bg-primary", "data-disabled:cursor-not-allowed data-disabled:opacity-50", "data-readonly:cursor-default", "data-invalid:border-destructive data-invalid:ring-destructive/20", focusRing, className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(RadioIndicator, { className: "before:size-2 before:rounded-full before:bg-current" })
	});
}
function RadioIndicator({ className, ...props }) {
	return /* @__PURE__ */ jsx(Radio.Indicator, {
		"data-slot": "radio-indicator",
		className: cn("flex items-center justify-center text-current", "transition-all data-starting-style:scale-50 data-starting-style:opacity-0 data-ending-style:scale-50 data-ending-style:opacity-0", className),
		...props
	});
}
function RadioGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx(RadioGroup$1, {
		"data-slot": "radio-group",
		className: cn("flex flex-col items-start gap-2 text-sm text-foreground", className),
		...props
	});
}
//#endregion
export { RadioGroup, RadioIndicator, RadioRoot };
