import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import { r as focusRing } from "./chunks/button-1Z23yCSW.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { OTPField as OTPField$1 } from "@base-ui/react/otp-field";
//#region src/components/ui/otp-field.tsx
function OTPField({ className, ...props }) {
	return /* @__PURE__ */ jsx(OTPField$1.Root, {
		"data-slot": "otp-field",
		className: cn("flex items-center gap-2", className),
		...props
	});
}
function OTPFieldInput({ className, ...props }) {
	return /* @__PURE__ */ jsx(OTPField$1.Input, {
		"data-slot": "otp-field-input",
		className: cn("m-0 h-10 w-10 rounded-(--radius) border border-input bg-background text-center text-base font-normal transition-colors", "data-disabled:cursor-not-allowed data-disabled:opacity-50 data-readonly:bg-muted", "data-filled:border-foreground", focusRing, className),
		...props
	});
}
function OTPFieldSeparator({ className, ...props }) {
	return /* @__PURE__ */ jsx(OTPField$1.Separator, {
		"data-slot": "otp-field-separator",
		className: cn("h-px w-4 shrink-0 bg-border text-foreground", "data-[orientation=vertical]:h-4 data-[orientation=vertical]:w-px", className),
		...props
	});
}
//#endregion
export { OTPField, OTPFieldInput, OTPFieldSeparator };
