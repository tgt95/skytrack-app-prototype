import { t as cn } from "./chunks/utils-QluraT_M.js";
import { Button } from "./button.js";
import * as React from "react";
import { UploadSimpleIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/components/ui/dropzone.tsx
function Dropzone({ accept, multiple = false, disabled = false, hint = "Choose a file or drag it here to upload.", buttonLabel = "Choose file", onFilesSelected, className, ...props }) {
	const inputRef = React.useRef(null);
	const [dragging, setDragging] = React.useState(false);
	const hintId = React.useId();
	const selectFiles = React.useCallback((files) => {
		if (disabled) return;
		const selected = Array.from(files);
		if (selected.length) onFilesSelected?.(selected);
	}, [disabled, onFilesSelected]);
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "dropzone",
		role: "group",
		"aria-label": "File upload",
		"data-dragging": dragging ? "" : void 0,
		"data-disabled": disabled ? "" : void 0,
		"aria-describedby": hintId,
		className: cn("flex min-h-40 flex-col items-center justify-center gap-3 border border-dashed border-border bg-muted/30 p-6 text-center transition-colors", "data-[dragging]:border-primary data-[dragging]:bg-primary/5", "data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
		onDragEnter: (event) => {
			event.preventDefault();
			if (!disabled) setDragging(true);
		},
		onDragOver: (event) => {
			event.preventDefault();
			if (!disabled) setDragging(true);
		},
		onDragLeave: (event) => {
			if (!event.currentTarget.contains(event.relatedTarget)) setDragging(false);
		},
		onDrop: (event) => {
			event.preventDefault();
			setDragging(false);
			selectFiles(event.dataTransfer.files);
		},
		...props,
		children: [
			/* @__PURE__ */ jsx(UploadSimpleIcon, {
				"aria-hidden": "true",
				className: "size-5 text-muted-foreground"
			}),
			/* @__PURE__ */ jsx("p", {
				id: hintId,
				className: "text-sm text-muted-foreground",
				children: hint
			}),
			/* @__PURE__ */ jsx(Button, {
				type: "button",
				variant: "outline",
				size: "sm",
				disabled,
				onClick: () => inputRef.current?.click(),
				children: buttonLabel
			}),
			/* @__PURE__ */ jsx("input", {
				ref: inputRef,
				type: "file",
				accept,
				multiple,
				disabled,
				tabIndex: -1,
				"aria-hidden": "true",
				className: "sr-only",
				onChange: (event) => {
					selectFiles(event.currentTarget.files ?? []);
					event.currentTarget.value = "";
				}
			})
		]
	});
}
//#endregion
export { Dropzone };
