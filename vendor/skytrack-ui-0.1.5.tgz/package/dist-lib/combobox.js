import { t as cn } from "./chunks/utils-QluraT_M.js";
import { focusRing } from "./button.js";
import "react";
import { CaretDownIcon, CaretUpDownIcon, CheckIcon, XIcon } from "@phosphor-icons/react";
import { cva } from "class-variance-authority";
import { jsx } from "react/jsx-runtime";
import { Combobox as Combobox$1 } from "@base-ui/react/combobox";
//#region src/components/ui/combobox.tsx
function Combobox(props) {
	return /* @__PURE__ */ jsx(Combobox$1.Root, { ...props });
}
function ComboboxLabel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Label, {
		"data-slot": "combobox-label",
		className: cn("cursor-default text-sm leading-none font-medium text-foreground", className),
		...props
	});
}
var comboboxInputGroupVariants = cva(cn("relative flex w-full items-center gap-1 rounded-md border border-input bg-background text-foreground shadow-xs transition-colors", "focus-within:border-ring focus-within:ring-[3px] focus-within:ring-ring/50", "has-[button]:px-1", "data-[disabled]:cursor-not-allowed data-[disabled]:opacity-50", "data-[invalid]:border-destructive data-[invalid]:ring-destructive/20"), {
	variants: {
		size: {
			default: "min-h-9 px-2 py-1",
			sm: "min-h-8 px-2 py-0.5 text-xs"
		},
		shape: {
			input: "",
			chips: "flex-wrap items-center"
		}
	},
	defaultVariants: {
		size: "default",
		shape: "input"
	}
});
function ComboboxInputGroup({ className, size, shape, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.InputGroup, {
		"data-slot": "combobox-input-group",
		className: cn(comboboxInputGroupVariants({
			size,
			shape
		}), className),
		...props
	});
}
function ComboboxInput({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Input, {
		"data-slot": "combobox-input",
		className: cn("h-full min-w-0 flex-1 border-0 bg-transparent px-1 text-sm outline-hidden", "placeholder:text-muted-foreground", className),
		...props
	});
}
function ComboboxTrigger({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Trigger, {
		"data-slot": "combobox-trigger",
		className: cn("flex size-6 cursor-pointer shrink-0 items-center justify-center rounded-sm border-0 bg-transparent p-0 text-muted-foreground transition-colors", "hover:bg-accent hover:text-accent-foreground", "data-[pressed]:bg-accent data-[pressed]:text-accent-foreground", "data-[disabled]:pointer-events-none data-[disabled]:opacity-50", focusRing, className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretDownIcon, { className: "size-4" })
	});
}
/** Standalone trigger used by the input-inside-popup pattern. */
function ComboboxTriggerButton({ className, size, children, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Trigger, {
		"data-slot": "combobox-trigger-button",
		className: cn("flex w-full cursor-pointer items-center justify-between gap-2 whitespace-nowrap rounded-md border border-input bg-background px-3 text-sm text-foreground shadow-xs transition-colors", "data-[placeholder]:text-muted-foreground", "hover:not-data-[disabled]:bg-accent hover:not-data-[disabled]:text-accent-foreground", "data-[pressed]:bg-accent data-[pressed]:text-accent-foreground", "data-[disabled]:cursor-not-allowed data-[disabled]:opacity-50", size === "sm" ? "h-8 text-xs" : "h-9", focusRing, className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretUpDownIcon, { className: "size-4 shrink-0 text-muted-foreground" })
	});
}
function ComboboxIcon({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Icon, {
		"data-slot": "combobox-icon",
		className: cn("flex size-4 shrink-0 items-center justify-center text-muted-foreground", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretUpDownIcon, { className: "size-4" })
	});
}
function ComboboxClear({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Clear, {
		"data-slot": "combobox-clear",
		className: cn("flex size-6 cursor-pointer shrink-0 items-center justify-center rounded-sm border-0 bg-transparent p-0 text-muted-foreground transition-colors", "hover:bg-accent hover:text-accent-foreground", "data-[disabled]:pointer-events-none data-[disabled]:opacity-50", focusRing, className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(XIcon, { className: "size-4" })
	});
}
/** Renders the selected label (or a render function). Renders no element of its own. */
function ComboboxValue(props) {
	return /* @__PURE__ */ jsx(Combobox$1.Value, { ...props });
}
function ComboboxChips({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Chips, {
		"data-slot": "combobox-chips",
		className: cn("flex w-full flex-wrap items-center gap-1", className),
		...props
	});
}
function ComboboxChip({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Chip, {
		"data-slot": "combobox-chip",
		className: cn("flex min-h-6 cursor-pointer items-center gap-1 overflow-hidden rounded-sm bg-secondary py-0 pr-1 pl-1.5 text-sm leading-none text-secondary-foreground select-none", "data-[highlighted]:bg-accent data-[highlighted]:text-accent-foreground", "data-[focused]:bg-accent data-[focused]:text-accent-foreground", className),
		...props
	});
}
function ComboboxChipRemove({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.ChipRemove, {
		"data-slot": "combobox-chip-remove",
		className: cn("flex size-4 cursor-pointer shrink-0 items-center justify-center rounded-sm border-0 bg-transparent p-0 text-current transition-colors hover:bg-accent", focusRing, className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(XIcon, { className: "size-3" })
	});
}
function ComboboxPortal({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Portal, {
		"data-slot": "combobox-portal",
		className: cn(className),
		...props
	});
}
function ComboboxBackdrop({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Backdrop, {
		"data-slot": "combobox-backdrop",
		className: cn("fixed inset-0 z-50 bg-black/20 transition-opacity data-[starting-style]:opacity-0 data-[ending-style]:opacity-0", className),
		...props
	});
}
function ComboboxPositioner({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Positioner, {
		"data-slot": "combobox-positioner",
		className: cn("z-50 outline-hidden", className),
		...props
	});
}
function ComboboxPopup({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Popup, {
		"data-slot": "combobox-popup",
		className: cn("w-[var(--anchor-width)] max-w-[var(--available-width)] origin-[var(--transform-origin)] rounded-md border border-border bg-popover text-popover-foreground shadow-md", "transition-[transform,scale,opacity] duration-150 ease-out", "data-[starting-style]:scale-95 data-[starting-style]:opacity-0", "data-[ending-style]:scale-95 data-[ending-style]:opacity-0", className),
		...props
	});
}
function ComboboxArrow({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Arrow, {
		"data-slot": "combobox-arrow",
		className: cn("flex size-4 items-center justify-center text-muted-foreground", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretDownIcon, { className: "size-3 rotate-180" })
	});
}
function ComboboxStatus({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Status, {
		"data-slot": "combobox-status",
		className: cn("empty:hidden", className),
		...props
	});
}
function ComboboxEmpty({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Empty, {
		"data-slot": "combobox-empty",
		className: cn("px-2 py-3 text-sm leading-none text-muted-foreground empty:hidden", className),
		...props,
		children: children === void 0 ? "No results found." : children
	});
}
function ComboboxList({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.List, {
		"data-slot": "combobox-list",
		className: cn("max-h-[min(22.5rem,var(--available-height))] scroll-py-1 overflow-y-auto overscroll-contain py-1 outline-hidden data-[empty]:p-0", className),
		...props
	});
}
function ComboboxRow({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Row, {
		"data-slot": "combobox-row",
		className: cn(className),
		...props
	});
}
function ComboboxItem({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Item, {
		"data-slot": "combobox-item",
		className: cn("relative grid cursor-pointer grid-cols-[1rem_1fr] items-center gap-2 rounded-sm px-2 py-1.5 text-sm select-none", "data-[highlighted]:bg-accent data-[highlighted]:text-accent-foreground", "data-[selected]:font-medium", "data-[disabled]:pointer-events-none data-[disabled]:opacity-50", focusRing, className),
		...props,
		children
	});
}
function ComboboxItemIndicator({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.ItemIndicator, {
		"data-slot": "combobox-item-indicator",
		className: cn("col-start-1 flex items-center justify-center", "transition-transform data-[starting-style]:scale-50 data-[ending-style]:scale-50", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CheckIcon, { className: "size-4" })
	});
}
function ComboboxGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Group, {
		"data-slot": "combobox-group",
		className: cn("block pb-1 last:pb-0", className),
		...props
	});
}
function ComboboxGroupLabel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.GroupLabel, {
		"data-slot": "combobox-group-label",
		className: cn("px-2 py-1.5 text-xs leading-5 font-medium text-muted-foreground select-none", className),
		...props
	});
}
function ComboboxSeparator({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox$1.Separator, {
		"data-slot": "combobox-separator",
		className: cn("-mx-1 my-1 h-px bg-border", className),
		...props
	});
}
/** Renders the filtered items of the enclosing group/list. Renders no element of its own. */
function ComboboxCollection(props) {
	return /* @__PURE__ */ jsx(Combobox$1.Collection, { ...props });
}
/** Re-exported Base UI helpers so demos never need the raw package. */
var useComboboxFilter = Combobox$1.useFilter;
var useComboboxFilteredItems = Combobox$1.useFilteredItems;
var createComboboxItems = Combobox$1.createItems;
//#endregion
export { Combobox, ComboboxArrow, ComboboxBackdrop, ComboboxChip, ComboboxChipRemove, ComboboxChips, ComboboxClear, ComboboxCollection, ComboboxEmpty, ComboboxGroup, ComboboxGroupLabel, ComboboxIcon, ComboboxInput, ComboboxInputGroup, ComboboxItem, ComboboxItemIndicator, ComboboxLabel, ComboboxList, ComboboxPopup, ComboboxPortal, ComboboxPositioner, ComboboxRow, ComboboxSeparator, ComboboxStatus, ComboboxTrigger, ComboboxTriggerButton, ComboboxValue, comboboxInputGroupVariants, createComboboxItems, useComboboxFilter, useComboboxFilteredItems };
