import { t as cn } from "./chunks/utils-QluraT_M.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { Fieldset } from "@base-ui/react/fieldset";
//#region src/components/ui/fieldset.tsx
function FieldsetRoot({ className, ...props }) {
	return /* @__PURE__ */ jsx(Fieldset.Root, {
		"data-slot": "fieldset",
		className: cn("flex w-full flex-col gap-4", "data-[disabled]:opacity-50", className),
		...props
	});
}
function FieldsetLegend({ className, ...props }) {
	return /* @__PURE__ */ jsx(Fieldset.Legend, {
		"data-slot": "fieldset-legend",
		className: cn("text-base leading-none font-semibold text-foreground", className),
		...props
	});
}
//#endregion
export { FieldsetLegend, FieldsetRoot };
