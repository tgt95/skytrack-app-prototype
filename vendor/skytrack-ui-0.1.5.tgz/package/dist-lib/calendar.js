import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import { t as Button } from "./chunks/button-1Z23yCSW.js";
import { Menu, MenuGroup, MenuGroupLabel, MenuPopup, MenuPortal, MenuPositioner, MenuRadioGroup, MenuRadioItem, MenuRadioItemIndicator, MenuTrigger } from "./menu.js";
import * as React from "react";
import { CaretDownIcon, CaretLeftIcon, CaretRightIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
import { DayPicker, UI, useDayPicker } from "react-day-picker";
//#region src/components/ui/calendar.tsx
var calendarClassNames = {
	[UI.Months]: "flex flex-col gap-4 sm:flex-row",
	[UI.Month]: "relative space-y-4",
	[UI.MonthCaption]: "flex h-9 items-center justify-center gap-1",
	[UI.CaptionLabel]: "text-sm font-medium",
	[UI.Nav]: "flex items-center justify-between",
	[UI.PreviousMonthButton]: "absolute start-0 top-0 size-9 p-0",
	[UI.NextMonthButton]: "absolute end-0 top-0 size-9 p-0",
	[UI.MonthGrid]: "w-full border-collapse",
	[UI.Weekdays]: "flex",
	[UI.Weekday]: "w-9 rounded-md text-center text-xs font-normal text-muted-foreground",
	[UI.Weeks]: "mt-2 flex flex-col gap-1",
	[UI.Week]: "flex w-full",
	[UI.Day]: "relative size-9 p-0 text-center text-sm focus-within:z-10",
	[UI.DayButton]: "size-9 p-0 font-normal aria-selected:bg-primary aria-selected:text-primary-foreground",
	[UI.Footer]: "pt-2 text-center text-sm text-muted-foreground",
	today: "bg-accent text-accent-foreground",
	outside: "text-muted-foreground opacity-50",
	disabled: "pointer-events-none opacity-50",
	selected: "bg-primary text-primary-foreground",
	range_middle: "aria-selected:bg-accent aria-selected:text-accent-foreground",
	hidden: "invisible"
};
function createMonthDate(year, month) {
	const date = /* @__PURE__ */ new Date(0);
	date.setFullYear(year, month, 1);
	date.setHours(12, 0, 0, 0);
	return date;
}
function monthIndex(date) {
	return date.getFullYear() * 12 + date.getMonth();
}
function isMonthInRange(date, startMonth, endMonth) {
	const value = monthIndex(date);
	return (!startMonth || value >= monthIndex(startMonth)) && (!endMonth || value <= monthIndex(endMonth));
}
function MonthSelector({ monthDate }) {
	const { dayPickerProps, goToMonth, labels } = useDayPicker();
	const [open, setOpen] = React.useState(false);
	const year = monthDate.getFullYear();
	const selectedMonth = monthDate.getMonth();
	const locale = dayPickerProps.locale?.code;
	const formatter = new Intl.DateTimeFormat(locale, { month: "long" });
	const months = Array.from({ length: 12 }, (_, month) => ({
		value: month,
		label: formatter.format(createMonthDate(year, month))
	}));
	return /* @__PURE__ */ jsxs(Menu, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ jsxs(MenuTrigger, {
			render: /* @__PURE__ */ jsx(Button, {
				type: "button",
				variant: "ghost",
				size: "default",
				"aria-label": labels.labelMonthDropdown(),
				disabled: dayPickerProps.disableNavigation,
				className: "min-w-0 justify-center gap-1 px-2"
			}),
			children: [formatter.format(monthDate), /* @__PURE__ */ jsx(CaretDownIcon, {
				"aria-hidden": "true",
				className: "size-3.5"
			})]
		}), /* @__PURE__ */ jsx(MenuPortal, { children: /* @__PURE__ */ jsx(MenuPositioner, {
			side: "bottom",
			align: "center",
			sideOffset: 4,
			children: /* @__PURE__ */ jsx(MenuPopup, {
				className: "max-h-64 min-w-36",
				children: /* @__PURE__ */ jsxs(MenuGroup, { children: [/* @__PURE__ */ jsx(MenuGroupLabel, { children: "Month" }), /* @__PURE__ */ jsx(MenuRadioGroup, {
					value: String(selectedMonth),
					onValueChange: (value) => {
						goToMonth(createMonthDate(year, Number(value)));
						setOpen(false);
					},
					children: months.map(({ value, label }) => /* @__PURE__ */ jsxs(MenuRadioItem, {
						value: String(value),
						inset: true,
						disabled: dayPickerProps.disableNavigation || !isMonthInRange(createMonthDate(year, value), dayPickerProps.startMonth, dayPickerProps.endMonth),
						children: [/* @__PURE__ */ jsx(MenuRadioItemIndicator, {}), label]
					}, value))
				})] })
			})
		}) })]
	});
}
function YearSelector({ monthDate }) {
	const { dayPickerProps, goToMonth, labels } = useDayPicker();
	const [open, setOpen] = React.useState(false);
	const optionListRef = React.useRef(null);
	const year = monthDate.getFullYear();
	const month = monthDate.getMonth();
	const locale = dayPickerProps.locale?.code;
	const formatter = new Intl.DateTimeFormat(locale, { year: "numeric" });
	const firstYear = Math.min(dayPickerProps.startMonth?.getFullYear() ?? year - 100, year);
	const lastYear = Math.max(dayPickerProps.endMonth?.getFullYear() ?? year + 100, year);
	const years = Array.from({ length: lastYear - firstYear + 1 }, (_, index) => firstYear + index);
	React.useEffect(() => {
		if (!open) return;
		const frame = window.requestAnimationFrame(() => {
			optionListRef.current?.querySelector("[data-current-year]")?.scrollIntoView({ block: "center" });
		});
		return () => window.cancelAnimationFrame(frame);
	}, [open, year]);
	return /* @__PURE__ */ jsxs(Menu, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ jsxs(MenuTrigger, {
			render: /* @__PURE__ */ jsx(Button, {
				type: "button",
				variant: "ghost",
				size: "default",
				"aria-label": labels.labelYearDropdown(),
				disabled: dayPickerProps.disableNavigation,
				className: "min-w-0 justify-center gap-1 px-2"
			}),
			children: [formatter.format(monthDate), /* @__PURE__ */ jsx(CaretDownIcon, {
				"aria-hidden": "true",
				className: "size-3.5"
			})]
		}), /* @__PURE__ */ jsx(MenuPortal, { children: /* @__PURE__ */ jsx(MenuPositioner, {
			side: "bottom",
			align: "center",
			sideOffset: 4,
			children: /* @__PURE__ */ jsx(MenuPopup, {
				className: "max-h-64 min-w-28",
				children: /* @__PURE__ */ jsxs(MenuGroup, { children: [/* @__PURE__ */ jsx(MenuGroupLabel, { children: "Year" }), /* @__PURE__ */ jsx("div", {
					ref: optionListRef,
					children: /* @__PURE__ */ jsx(MenuRadioGroup, {
						value: String(year),
						onValueChange: (value) => {
							goToMonth(createMonthDate(Number(value), month));
							setOpen(false);
						},
						children: years.map((optionYear) => /* @__PURE__ */ jsxs(MenuRadioItem, {
							value: String(optionYear),
							inset: true,
							"data-current-year": optionYear === year ? "" : void 0,
							disabled: dayPickerProps.disableNavigation || dayPickerProps.startMonth != null && optionYear < dayPickerProps.startMonth.getFullYear() || dayPickerProps.endMonth != null && optionYear > dayPickerProps.endMonth.getFullYear(),
							children: [/* @__PURE__ */ jsx(MenuRadioItemIndicator, {}), formatter.format(createMonthDate(optionYear, 0))]
						}, optionYear))
					})
				})] })
			})
		}) })]
	});
}
function CalendarMonthCaption({ calendarMonth, className, children, ...props }) {
	const monthDate = calendarMonth.date;
	return /* @__PURE__ */ jsxs("div", {
		...props,
		className: cn(className, "flex h-9 items-center justify-center gap-1"),
		children: [
			/* @__PURE__ */ jsx("span", {
				className: "sr-only",
				children
			}),
			/* @__PURE__ */ jsx(MonthSelector, { monthDate }),
			/* @__PURE__ */ jsx(YearSelector, { monthDate })
		]
	});
}
function CalendarPreviousMonthButton({ className, ...props }) {
	return /* @__PURE__ */ jsx(Button, {
		type: "button",
		variant: "ghost",
		size: "default",
		className,
		disabled: props["aria-disabled"] === true || props["aria-disabled"] === "true",
		...props
	});
}
function CalendarNextMonthButton({ className, ...props }) {
	return /* @__PURE__ */ jsx(Button, {
		type: "button",
		variant: "ghost",
		size: "default",
		className,
		disabled: props["aria-disabled"] === true || props["aria-disabled"] === "true",
		...props
	});
}
function CalendarDayButton({ day, modifiers, ...props }) {
	const buttonRef = React.useRef(null);
	React.useEffect(() => {
		if (modifiers.focused) buttonRef.current?.focus();
	}, [modifiers.focused]);
	return /* @__PURE__ */ jsx(Button, {
		ref: buttonRef,
		variant: "ghost",
		size: "default",
		...props
	});
}
function Calendar({ className, classNames, components, ...props }) {
	return /* @__PURE__ */ jsx(DayPicker, {
		"data-slot": "calendar",
		navLayout: "around",
		captionLayout: "label",
		className: cn("w-fit rounded-(--radius) p-3", className),
		classNames: {
			...calendarClassNames,
			...classNames
		},
		components: {
			...components,
			Chevron: components?.Chevron ?? (({ orientation, className: iconClassName }) => orientation === "left" ? /* @__PURE__ */ jsx(CaretLeftIcon, {
				"aria-hidden": "true",
				className: cn("size-4", iconClassName)
			}) : /* @__PURE__ */ jsx(CaretRightIcon, {
				"aria-hidden": "true",
				className: cn("size-4", iconClassName)
			})),
			MonthCaption: components?.MonthCaption ?? CalendarMonthCaption,
			PreviousMonthButton: components?.PreviousMonthButton ?? CalendarPreviousMonthButton,
			NextMonthButton: components?.NextMonthButton ?? CalendarNextMonthButton,
			DayButton: components?.DayButton ?? CalendarDayButton
		},
		...props
	});
}
//#endregion
export { Calendar };
