import { t as cn } from "./chunks/utils-QluraT_M.js";
import { focusRing } from "./button.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { Field } from "@base-ui/react/field";
//#region src/components/ui/field.tsx
function FieldRoot({ className, ...props }) {
	return /* @__PURE__ */ jsx(Field.Root, {
		"data-slot": "field",
		className: cn("group/field flex w-full flex-col items-start gap-2", "data-[disabled]:opacity-50", className),
		...props
	});
}
function FieldLabel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Field.Label, {
		"data-slot": "field-label",
		className: cn("text-sm leading-none font-medium text-foreground", "group-data-[disabled]/field:cursor-not-allowed group-data-[disabled]/field:opacity-50", className),
		...props
	});
}
function FieldControl({ className, ...props }) {
	return /* @__PURE__ */ jsx(Field.Control, {
		"data-slot": "field-control",
		className: cn("flex h-9 w-full min-w-0 self-stretch rounded-md border border-input bg-background px-3 py-1 text-sm text-foreground shadow-xs transition-colors", "placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground", "data-[filled]:border-foreground/40", "data-[disabled]:cursor-not-allowed data-[disabled]:opacity-50", "data-[invalid]:border-destructive data-[invalid]:ring-destructive/20", focusRing, className),
		...props
	});
}
function FieldDescription({ className, ...props }) {
	return /* @__PURE__ */ jsx(Field.Description, {
		"data-slot": "field-description",
		className: cn("text-sm leading-normal text-muted-foreground", className),
		...props
	});
}
function FieldError({ className, ...props }) {
	return /* @__PURE__ */ jsx(Field.Error, {
		"data-slot": "field-error",
		className: cn("text-sm leading-normal font-medium text-destructive", className),
		...props
	});
}
function FieldValidity({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Field.Validity, {
		...props,
		children: (state) => /* @__PURE__ */ jsx("span", {
			"data-slot": "field-validity",
			className: cn("text-sm leading-normal text-muted-foreground", className),
			children: children(state)
		})
	});
}
function FieldItem({ className, ...props }) {
	return /* @__PURE__ */ jsx(Field.Item, {
		"data-slot": "field-item",
		className: cn("flex items-center gap-2 self-stretch", "data-[disabled]:opacity-50", className),
		...props
	});
}
/** Convenience layout part: tight vertical stack for related fields. */
function FieldGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "field-group",
		className: cn("flex flex-col gap-4", className),
		...props
	});
}
/** Convenience layout part: horizontal row for a control and its message. */
function FieldRow({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "field-row",
		className: cn("flex items-center gap-3", className),
		...props
	});
}
//#endregion
export { Field, FieldControl, FieldDescription, FieldError, FieldGroup, FieldItem, FieldLabel, FieldRoot, FieldRow, FieldValidity };
