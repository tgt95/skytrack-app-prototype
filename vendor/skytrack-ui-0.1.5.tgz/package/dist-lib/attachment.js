import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import { t as Button } from "./chunks/button-1Z23yCSW.js";
import * as React from "react";
import { cva } from "class-variance-authority";
import { jsx } from "react/jsx-runtime";
//#region src/components/ui/attachment.tsx
var AttachmentContext = React.createContext({
	state: "done",
	size: "default",
	orientation: "horizontal"
});
var attachmentVariants = cva("relative isolate flex w-full gap-3 rounded-(--radius) border border-border bg-card text-card-foreground transition-colors", {
	variants: {
		size: {
			default: "min-h-16 p-3",
			sm: "min-h-14 gap-2 p-2",
			xs: "gap-2 p-1"
		},
		orientation: {
			horizontal: "flex-row items-center",
			vertical: "flex-col items-stretch"
		},
		state: {
			idle: "border-border",
			uploading: "border-primary/40",
			processing: "border-primary/40",
			error: "border-destructive/50 bg-destructive/5",
			done: "border-border"
		}
	},
	defaultVariants: {
		size: "default",
		orientation: "horizontal",
		state: "done"
	}
});
function Attachment({ className, size = "default", orientation = "horizontal", state = "done", ...props }) {
	const resolvedSize = size ?? "default";
	const resolvedOrientation = orientation ?? "horizontal";
	const context = React.useMemo(() => ({
		state,
		size: resolvedSize,
		orientation: resolvedOrientation
	}), [
		state,
		resolvedSize,
		resolvedOrientation
	]);
	return /* @__PURE__ */ jsx(AttachmentContext.Provider, {
		value: context,
		children: /* @__PURE__ */ jsx("div", {
			"data-slot": "attachment",
			"data-state": state,
			"data-size": resolvedSize,
			"data-orientation": resolvedOrientation,
			className: cn(attachmentVariants({
				size: resolvedSize,
				orientation: resolvedOrientation,
				state
			}), className),
			...props
		})
	});
}
function AttachmentMedia({ variant = "icon", className, ...props }) {
	const { size, orientation } = React.useContext(AttachmentContext);
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "attachment-media",
		"data-variant": variant,
		className: cn("relative z-10 flex shrink-0 items-center justify-center overflow-hidden bg-muted text-muted-foreground [&>svg]:size-5 [&>svg]:shrink-0", variant === "icon" && "size-12", variant === "image" && "aspect-square w-16 [&>img]:size-full [&>img]:object-cover", size === "default" || size === "sm" && "rounded-(--radius)", size === "sm" && variant === "icon" && "size-11", size === "xs" && variant === "icon" && "size-10", orientation === "vertical" && variant === "image" && "w-full", className),
		...props
	});
}
function AttachmentContent({ className, ...props }) {
	const { size } = React.useContext(AttachmentContext);
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "attachment-content",
		className: cn("pointer-events-none relative z-10 flex min-w-0 flex-1 flex-col justify-center gap-1", size === "xs" ? "gap-0" : "gap-1", className),
		...props
	});
}
function AttachmentTitle({ className, ...props }) {
	const { state, size } = React.useContext(AttachmentContext);
	return /* @__PURE__ */ jsx("p", {
		"data-slot": "attachment-title",
		"data-state": state,
		className: cn("truncate font-medium text-base leading-6 text-foreground", (state === "uploading" || state === "processing") && "animate-pulse", size == "default" || size == "sm" ? "text-base leading-5" : size == "xs" && "text-sm leading-5", className),
		...props
	});
}
function AttachmentDescription({ className, ...props }) {
	const { state, size } = React.useContext(AttachmentContext);
	return /* @__PURE__ */ jsx("p", {
		"data-slot": "attachment-description",
		className: cn("truncate text-sm leading-5 text-muted-foreground", size == "xs" && "text-xs", state === "error" && "text-destructive", className),
		...props
	});
}
function AttachmentActions({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "attachment-actions",
		className: cn("relative z-20 ml-auto flex shrink-0 items-center gap-1", className),
		...props
	});
}
function AttachmentAction({ className, size = "icon-xs", variant = "ghost", ...props }) {
	return /* @__PURE__ */ jsx(Button, {
		"data-slot": "attachment-action",
		variant,
		size,
		className: cn("relative z-20 text-muted-foreground hover:text-foreground", className),
		...props
	});
}
function AttachmentTrigger({ className, render, ...props }) {
	const triggerClassName = cn("absolute inset-0 z-0 cursor-pointer rounded-(--radius) outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className);
	if (render) {
		const renderProps = render.props;
		return React.cloneElement(render, {
			...props,
			className: cn(triggerClassName, renderProps.className)
		});
	}
	return /* @__PURE__ */ jsx("button", {
		"data-slot": "attachment-trigger",
		type: "button",
		className: triggerClassName,
		...props
	});
}
function AttachmentGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "attachment-group",
		className: cn("flex w-full snap-x snap-mandatory gap-3 overflow-x-auto overscroll-x-contain pb-1 [&>*]:snap-start", className),
		...props
	});
}
//#endregion
export { Attachment, AttachmentAction, AttachmentActions, AttachmentContent, AttachmentDescription, AttachmentGroup, AttachmentMedia, AttachmentTitle, AttachmentTrigger };
