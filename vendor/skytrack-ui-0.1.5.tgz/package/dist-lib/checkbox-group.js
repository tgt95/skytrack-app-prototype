import { t as cn } from "./chunks/utils-QluraT_M.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { CheckboxGroup as CheckboxGroup$1 } from "@base-ui/react/checkbox-group";
//#region src/components/ui/checkbox-group.tsx
function CheckboxGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx(CheckboxGroup$1, {
		"data-slot": "checkbox-group",
		className: cn("flex flex-col items-start gap-2 text-sm text-foreground", className),
		...props
	});
}
//#endregion
export { CheckboxGroup };
