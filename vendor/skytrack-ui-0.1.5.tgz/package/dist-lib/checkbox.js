import { t as cn } from "./chunks/utils-QluraT_M.js";
import { focusRing } from "./button.js";
import "react";
import { CheckIcon, MinusIcon } from "@phosphor-icons/react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Checkbox } from "@base-ui/react/checkbox";
//#region src/components/ui/checkbox.tsx
function CheckboxRoot({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Checkbox.Root, {
		"data-slot": "checkbox",
		className: cn("flex size-4 cursor-pointer shrink-0 items-center justify-center rounded-md border border-input bg-background p-0 text-primary-foreground transition-colors", "data-[checked]:border-primary data-[checked]:bg-primary", "data-[indeterminate]:border-primary data-[indeterminate]:bg-primary", "data-[disabled]:cursor-not-allowed data-[disabled]:opacity-50", "data-[invalid]:border-destructive data-[invalid]:ring-destructive/20", focusRing, className),
		...props,
		children: children ?? /* @__PURE__ */ jsxs(CheckboxIndicator, { children: [/* @__PURE__ */ jsx(CheckIcon, {
			className: "hidden size-3 group-data-[checked]/indicator:block",
			weight: "bold"
		}), /* @__PURE__ */ jsx(MinusIcon, {
			className: "hidden size-3 group-data-[indeterminate]/indicator:block",
			weight: "bold"
		})] })
	});
}
function CheckboxIndicator({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Checkbox.Indicator, {
		"data-slot": "checkbox-indicator",
		className: cn("group/indicator flex items-center justify-center text-current", "transition-all data-[starting-style]:scale-75 data-[starting-style]:opacity-0 data-[ending-style]:scale-75 data-[ending-style]:opacity-0", className),
		...props,
		children
	});
}
//#endregion
export { CheckboxIndicator, CheckboxRoot };
