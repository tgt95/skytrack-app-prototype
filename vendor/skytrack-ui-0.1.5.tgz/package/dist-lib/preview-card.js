import { t as cn } from "./chunks/utils-QluraT_M.js";
import "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { PreviewCard as PreviewCard$1 } from "@base-ui/react/preview-card";
//#region src/components/ui/preview-card.tsx
/**
* Preview Card — a link that shows a destination preview on hover or focus.
* `PreviewCard` (Root) renders no element of its own, so it is re-exported as-is.
*/
var PreviewCard = PreviewCard$1.Root;
/** Creates a handle that lets detached triggers control this preview card. */
var createHandle = PreviewCard$1.createHandle;
function PreviewCardTrigger({ className, ...props }) {
	return /* @__PURE__ */ jsx(PreviewCard$1.Trigger, {
		"data-slot": "preview-card-trigger",
		className,
		...props
	});
}
function PreviewCardPortal({ className, ...props }) {
	return /* @__PURE__ */ jsx(PreviewCard$1.Portal, {
		"data-slot": "preview-card-portal",
		className: cn("z-50", className),
		...props
	});
}
function PreviewCardBackdrop({ className, ...props }) {
	return /* @__PURE__ */ jsx(PreviewCard$1.Backdrop, {
		"data-slot": "preview-card-backdrop",
		className: cn("fixed inset-0 z-50 bg-black/20 transition-opacity duration-150", "data-[starting-style]:opacity-0 data-[ending-style]:opacity-0 data-[closed]:pointer-events-none", className),
		...props
	});
}
function PreviewCardPositioner({ className, ...props }) {
	return /* @__PURE__ */ jsx(PreviewCard$1.Positioner, {
		"data-slot": "preview-card-positioner",
		className: cn("z-50 h-[var(--positioner-height)] w-[var(--positioner-width)] max-w-[var(--available-width)]", className),
		...props
	});
}
function PreviewCardPopup({ className, ...props }) {
	return /* @__PURE__ */ jsx(PreviewCard$1.Popup, {
		"data-slot": "preview-card-popup",
		className: cn("relative z-50 w-[var(--popup-width,auto)] max-w-80 origin-[var(--transform-origin)] rounded-(--radius) border border-border bg-popover text-popover-foreground shadow-md", "transition-[scale,opacity] duration-100 ease-out", "data-[starting-style]:scale-95 data-[starting-style]:opacity-0", "data-[ending-style]:scale-95 data-[ending-style]:opacity-0", "data-[instant]:transition-none", className),
		...props
	});
}
function PreviewCardArrowGlyph(props) {
	return /* @__PURE__ */ jsxs("svg", {
		width: "20",
		height: "10",
		viewBox: "0 0 20 10",
		fill: "none",
		"aria-hidden": "true",
		focusable: "false",
		...props,
		children: [/* @__PURE__ */ jsx("path", {
			d: "M1 9 L10 1 L19 9 Z",
			fill: "currentColor",
			stroke: "none",
			className: "text-popover"
		}), /* @__PURE__ */ jsx("path", {
			d: "M1 9 L10 1 L19 9",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: 1,
			strokeLinejoin: "round",
			strokeLinecap: "round",
			className: "text-border"
		})]
	});
}
function PreviewCardArrow({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(PreviewCard$1.Arrow, {
		"data-slot": "preview-card-arrow",
		className: cn("pointer-events-none absolute z-10 flex h-2.5 w-5 items-center justify-center", "data-[side=top]:bottom-[-9px] data-[side=top]:rotate-180", "data-[side=bottom]:top-[-9px]", "data-[side=left]:right-[-9px] data-[side=left]:rotate-90", "data-[side=right]:left-[-9px] data-[side=right]:-rotate-90", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(PreviewCardArrowGlyph, {})
	});
}
function PreviewCardViewport({ className, ...props }) {
	return /* @__PURE__ */ jsx(PreviewCard$1.Viewport, {
		"data-slot": "preview-card-viewport",
		className: cn("relative h-full w-full overflow-clip", className),
		...props
	});
}
//#endregion
export { PreviewCard, PreviewCardArrow, PreviewCardBackdrop, PreviewCardPopup, PreviewCardPortal, PreviewCardPositioner, PreviewCardTrigger, PreviewCardViewport, createHandle };
