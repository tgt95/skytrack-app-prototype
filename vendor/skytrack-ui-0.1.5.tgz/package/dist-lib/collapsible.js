import { t as cn } from "./chunks/utils-QluraT_M.js";
import { focusRing } from "./button.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { Collapsible as Collapsible$1 } from "@base-ui/react/collapsible";
//#region src/components/ui/collapsible.tsx
function Collapsible({ className, ...props }) {
	return /* @__PURE__ */ jsx(Collapsible$1.Root, {
		"data-slot": "collapsible",
		className: cn("flex w-64 flex-col", className),
		...props
	});
}
function CollapsibleTrigger({ className, ...props }) {
	return /* @__PURE__ */ jsx(Collapsible$1.Trigger, {
		"data-slot": "collapsible-trigger",
		className: cn("group flex h-8 cursor-pointer items-center justify-between gap-2 border border-border bg-background pl-3 pr-2 text-sm font-normal whitespace-nowrap text-foreground select-none", "hover:bg-accent hover:text-accent-foreground active:bg-muted", "disabled:pointer-events-none disabled:opacity-50 data-[disabled]:pointer-events-none data-[disabled]:opacity-50", focusRing, className),
		...props
	});
}
function CollapsiblePanel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Collapsible$1.Panel, {
		"data-slot": "collapsible-panel",
		className: cn("flex h-[var(--collapsible-panel-height)] flex-col justify-end overflow-hidden text-sm transition-[height] duration-150 ease-out", "[&[hidden]:not([hidden='until-found'])]:hidden data-[ending-style]:h-0 data-[starting-style]:h-0", className),
		...props
	});
}
//#endregion
export { Collapsible, CollapsiblePanel, CollapsibleTrigger };
