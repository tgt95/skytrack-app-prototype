import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { Collapsible as Collapsible$1 } from "@base-ui/react/collapsible";
//#region src/components/ui/collapsible.tsx
function Collapsible({ className, ...props }) {
	return /* @__PURE__ */ jsx(Collapsible$1.Root, {
		"data-slot": "collapsible",
		className: cn("flex w-64 flex-col", className),
		...props
	});
}
function CollapsibleTrigger({ className, ...props }) {
	return /* @__PURE__ */ jsx(Collapsible$1.Trigger, {
		"data-slot": "collapsible-trigger",
		className,
		...props
	});
}
function CollapsiblePanel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Collapsible$1.Panel, {
		"data-slot": "collapsible-panel",
		className: cn("flex h-[var(--collapsible-panel-height)] flex-col justify-end overflow-hidden text-sm transition-[height] duration-150 ease-out", "[&[hidden]:not([hidden='until-found'])]:hidden data-ending-style:h-0 data-starting-style:h-0", className),
		...props
	});
}
//#endregion
export { Collapsible, CollapsiblePanel, CollapsibleTrigger };
