import { t as cn } from "./chunks/utils-QluraT_M.js";
import { focusRing } from "./button.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { ScrollArea as ScrollArea$1 } from "@base-ui/react/scroll-area";
//#region src/components/ui/scroll-area.tsx
function ScrollArea({ className, ...props }) {
	return /* @__PURE__ */ jsx(ScrollArea$1.Root, {
		"data-slot": "scroll-area",
		className: cn("relative overflow-hidden", className),
		...props
	});
}
function ScrollAreaViewport({ className, ...props }) {
	return /* @__PURE__ */ jsx(ScrollArea$1.Viewport, {
		"data-slot": "scroll-area-viewport",
		className: cn("size-full overflow-hidden outline-none", focusRing, className),
		...props
	});
}
function ScrollAreaContent({ className, ...props }) {
	return /* @__PURE__ */ jsx(ScrollArea$1.Content, {
		"data-slot": "scroll-area-content",
		className: cn("flex flex-col gap-4 p-4 text-sm leading-relaxed", className),
		...props
	});
}
function ScrollAreaScrollbar({ className, ...props }) {
	return /* @__PURE__ */ jsx(ScrollArea$1.Scrollbar, {
		"data-slot": "scroll-area-scrollbar",
		className: cn("m-1 flex justify-center rounded-(--radius) bg-border/60 opacity-0 transition-opacity duration-150 select-none", "pointer-events-none data-[hovering]:pointer-events-auto data-[hovering]:opacity-100", "data-[scrolling]:pointer-events-auto data-[scrolling]:opacity-100 data-[scrolling]:duration-0", "data-[orientation=vertical]:w-2 data-[orientation=horizontal]:h-2", className),
		...props
	});
}
function ScrollAreaThumb({ className, ...props }) {
	return /* @__PURE__ */ jsx(ScrollArea$1.Thumb, {
		"data-slot": "scroll-area-thumb",
		className: cn("cursor-pointer rounded-(--radius) bg-border", "data-[orientation=vertical]:w-full data-[orientation=horizontal]:h-full", className),
		...props
	});
}
function ScrollAreaCorner({ className, ...props }) {
	return /* @__PURE__ */ jsx(ScrollArea$1.Corner, {
		"data-slot": "scroll-area-corner",
		className: cn("rounded-(--radius) bg-background", className),
		...props
	});
}
//#endregion
export { ScrollArea, ScrollAreaContent, ScrollAreaCorner, ScrollAreaScrollbar, ScrollAreaThumb, ScrollAreaViewport };
