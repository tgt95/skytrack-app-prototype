import { t as cn } from "./chunks/utils-QluraT_M.js";
import { buttonVariants } from "./button.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { AlertDialog as AlertDialog$1 } from "@base-ui/react/alert-dialog";
//#region src/components/ui/alert-dialog.tsx
/**
* Alert Dialog — a dialog that requires a user response to proceed.
* `AlertDialog` (Root) renders no element of its own, so it is re-exported as-is.
*/
var AlertDialog = AlertDialog$1.Root;
/** Creates a handle that lets detached triggers control this alert dialog. */
var createHandle = AlertDialog$1.createHandle;
function AlertDialogTrigger({ className, ...props }) {
	return /* @__PURE__ */ jsx(AlertDialog$1.Trigger, {
		"data-slot": "alert-dialog-trigger",
		className,
		...props
	});
}
function AlertDialogPortal({ className, ...props }) {
	return /* @__PURE__ */ jsx(AlertDialog$1.Portal, {
		"data-slot": "alert-dialog-portal",
		className: cn("z-50", className),
		...props
	});
}
function AlertDialogBackdrop({ className, ...props }) {
	return /* @__PURE__ */ jsx(AlertDialog$1.Backdrop, {
		"data-slot": "alert-dialog-backdrop",
		className: cn("fixed inset-0 z-50 min-h-dvh bg-black/20 transition-opacity duration-150", "supports-[-webkit-touch-callout:none]:absolute", "data-[starting-style]:opacity-0 data-[ending-style]:opacity-0", className),
		...props
	});
}
/** Convenience alias matching the shadcn naming. */
function AlertDialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ jsx(AlertDialogBackdrop, {
		"data-slot": "alert-dialog-overlay",
		className,
		...props
	});
}
function AlertDialogViewport({ className, ...props }) {
	return /* @__PURE__ */ jsx(AlertDialog$1.Viewport, {
		"data-slot": "alert-dialog-viewport",
		className: cn("fixed inset-0 z-50 overflow-y-auto overscroll-contain", className),
		...props
	});
}
function AlertDialogPopup({ className, ...props }) {
	return /* @__PURE__ */ jsx(AlertDialog$1.Popup, {
		"data-slot": "alert-dialog-popup",
		className: cn("fixed top-1/2 left-1/2 z-50 flex w-full max-w-[calc(100vw-2rem)] -translate-x-1/2 -translate-y-1/2 flex-col gap-4 rounded-lg border border-border bg-background p-6 text-foreground shadow-lg sm:max-w-lg", "transition-[scale,opacity] duration-100 ease-out", "data-[starting-style]:scale-95 data-[starting-style]:opacity-0", "data-[ending-style]:scale-95 data-[ending-style]:opacity-0", "motion-reduce:transition-none", className),
		...props
	});
}
function AlertDialogHeader({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "alert-dialog-header",
		className: cn("flex flex-col gap-2 text-left", className),
		...props
	});
}
function AlertDialogFooter({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "alert-dialog-footer",
		className: cn("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
function AlertDialogTitle({ className, ...props }) {
	return /* @__PURE__ */ jsx(AlertDialog$1.Title, {
		"data-slot": "alert-dialog-title",
		className: cn("h5", className),
		...props
	});
}
function AlertDialogDescription({ className, ...props }) {
	return /* @__PURE__ */ jsx(AlertDialog$1.Description, {
		"data-slot": "alert-dialog-description",
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
function AlertDialogClose({ className, variant, size, ...props }) {
	return /* @__PURE__ */ jsx(AlertDialog$1.Close, {
		"data-slot": "alert-dialog-close",
		className: cn(buttonVariants({
			variant: variant ?? "outline",
			size
		}), className),
		...props
	});
}
//#endregion
export { AlertDialog, AlertDialogBackdrop, AlertDialogClose, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogOverlay, AlertDialogPopup, AlertDialogPortal, AlertDialogTitle, AlertDialogTrigger, AlertDialogViewport, createHandle };
