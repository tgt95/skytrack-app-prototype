import { t as cn } from "./chunks/utils-QluraT_M.js";
import { focusRing } from "./button.js";
import "react";
import { CaretRight, Check } from "@phosphor-icons/react";
import { cva } from "class-variance-authority";
import { jsx, jsxs } from "react/jsx-runtime";
import { Menu as Menu$1 } from "@base-ui/react/menu";
//#region src/components/ui/menu.tsx
/**
* Shared row styling for every menu item part (Item, LinkItem, CheckboxItem,
* RadioItem, SubmenuTrigger). `variant="destructive"` is the destructive item variant.
*/
var menuItemVariants = cva(cn("relative flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm text-popover-foreground select-none outline-none transition-colors", "data-[highlighted]:bg-accent data-[highlighted]:text-accent-foreground", "data-[disabled]:pointer-events-none data-[disabled]:opacity-50", "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4"), {
	variants: {
		variant: {
			default: "",
			destructive: "text-destructive data-[highlighted]:bg-destructive data-[highlighted]:text-white"
		},
		inset: {
			true: "pl-8",
			false: ""
		}
	},
	defaultVariants: {
		variant: "default",
		inset: false
	}
});
/**
* `Menu` and `MenuTrigger` keep Base UI's `Payload` generic so that
* `Menu.createHandle<Payload>()` + the payload render function stay typed.
*/
function Menu(props) {
	return /* @__PURE__ */ jsx(Menu$1.Root, { ...props });
}
function MenuTrigger({ className, render, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.Trigger, {
		"data-slot": "menu-trigger",
		className: cn(render == null ? cn("inline-flex h-8 cursor-pointer items-center justify-center gap-1.5 rounded-md border border-input bg-background px-3 text-sm font-medium whitespace-nowrap text-foreground select-none transition-colors", "hover:bg-accent hover:text-accent-foreground active:bg-muted", "data-[popup-open]:bg-accent data-[popup-open]:text-accent-foreground", "disabled:pointer-events-none disabled:opacity-50 data-[disabled]:pointer-events-none data-[disabled]:opacity-50", "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", focusRing) : "", className),
		render,
		...props
	});
}
function MenuPortal({ className, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.Portal, {
		"data-slot": "menu-portal",
		className: cn(className),
		...props
	});
}
function MenuBackdrop({ className, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.Backdrop, {
		"data-slot": "menu-backdrop",
		className: cn("fixed inset-0 z-50 bg-foreground/20 transition-opacity duration-150", "data-[starting-style]:opacity-0 data-[ending-style]:opacity-0", className),
		...props
	});
}
function MenuPositioner({ className, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.Positioner, {
		"data-slot": "menu-positioner",
		className: cn("z-50 outline-hidden", className),
		...props
	});
}
function MenuPopup({ className, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.Popup, {
		"data-slot": "menu-popup",
		className: cn("origin-[var(--transform-origin)] rounded-lg border border-border bg-popover p-1 text-popover-foreground shadow-md outline-hidden", "max-h-[var(--available-height)] min-w-[8rem] overflow-y-auto overscroll-contain", "transition-[scale,opacity] duration-100 ease-out data-[instant]:transition-none", "data-[starting-style]:scale-95 data-[starting-style]:opacity-0", "data-[ending-style]:scale-95 data-[ending-style]:opacity-0", className),
		...props
	});
}
function MenuArrow({ className, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.Arrow, {
		"data-slot": "menu-arrow",
		className: cn("h-2 w-2 rotate-45 rounded-md border border-border bg-popover", "data-[side=top]:-bottom-1 data-[side=top]:-rotate-135", "data-[side=bottom]:-top-1 data-[side=bottom]:rotate-45", "data-[side=left]:-right-1 data-[side=left]:rotate-225", "data-[side=right]:-left-1 data-[side=right]:rotate-135", "data-[side=inline-start]:-right-1 data-[side=inline-start]:-rotate-45", "data-[side=inline-end]:-left-1 data-[side=inline-end]:-rotate-225", className),
		...props
	});
}
function MenuViewport({ className, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.Viewport, {
		"data-slot": "menu-viewport",
		className: cn("relative", className),
		...props
	});
}
function MenuGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.Group, {
		"data-slot": "menu-group",
		className: cn(className),
		...props
	});
}
function MenuGroupLabel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.GroupLabel, {
		"data-slot": "menu-group-label",
		className: cn("px-2 py-1.5 text-xs font-medium tracking-wide text-muted-foreground select-none", className),
		...props
	});
}
function MenuSeparator({ className, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.Separator, {
		"data-slot": "menu-separator",
		className: cn("-mx-1 my-1 h-px shrink-0 bg-border", className),
		...props
	});
}
function MenuItem({ className, variant, inset, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.Item, {
		"data-slot": "menu-item",
		className: cn(menuItemVariants({
			variant,
			inset
		}), className),
		...props
	});
}
function MenuLinkItem({ className, variant, inset, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.LinkItem, {
		"data-slot": "menu-link-item",
		className: cn(menuItemVariants({
			variant,
			inset
		}), className),
		...props
	});
}
function MenuSubmenuRoot(props) {
	return /* @__PURE__ */ jsx(Menu$1.SubmenuRoot, { ...props });
}
function MenuSubmenuTrigger({ className, children, variant, inset, ...props }) {
	return /* @__PURE__ */ jsxs(Menu$1.SubmenuTrigger, {
		"data-slot": "menu-submenu-trigger",
		className: cn(menuItemVariants({
			variant,
			inset
		}), "justify-between data-[popup-open]:bg-accent data-[popup-open]:text-accent-foreground", className),
		...props,
		children: [children, /* @__PURE__ */ jsx(CaretRight, { className: "ml-auto" })]
	});
}
function MenuRadioGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.RadioGroup, {
		"data-slot": "menu-radio-group",
		className: cn("py-0.5", className),
		...props
	});
}
function MenuRadioItem({ className, variant, inset, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.RadioItem, {
		"data-slot": "menu-radio-item",
		className: cn(menuItemVariants({
			variant,
			inset
		}), className),
		...props
	});
}
function MenuRadioItemIndicator({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.RadioItemIndicator, {
		"data-slot": "menu-radio-item-indicator",
		className: cn("absolute left-2 flex size-4 items-center justify-center text-current", "transition-all data-[starting-style]:scale-50 data-[starting-style]:opacity-0 data-[ending-style]:scale-50 data-[ending-style]:opacity-0", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx("span", { className: "size-2 rounded-full bg-current" })
	});
}
function MenuCheckboxItem({ className, variant, inset, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.CheckboxItem, {
		"data-slot": "menu-checkbox-item",
		className: cn(menuItemVariants({
			variant,
			inset
		}), className),
		...props
	});
}
function MenuCheckboxItemIndicator({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Menu$1.CheckboxItemIndicator, {
		"data-slot": "menu-checkbox-item-indicator",
		className: cn("absolute left-2 flex size-4 items-center justify-center text-current", "transition-all data-[starting-style]:scale-75 data-[starting-style]:opacity-0 data-[ending-style]:scale-75 data-[ending-style]:opacity-0", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(Check, {
			className: "size-3.5",
			weight: "bold"
		})
	});
}
function MenuShortcut({ className, ...props }) {
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "menu-shortcut",
		className: cn("ml-auto text-xs tracking-widest text-muted-foreground", className),
		...props
	});
}
/** Base UI helper for detached triggers (`Menu.createHandle()` in the docs). */
function createMenuHandle() {
	return Menu$1.createHandle();
}
//#endregion
export { Menu, MenuArrow, MenuBackdrop, MenuCheckboxItem, MenuCheckboxItemIndicator, MenuGroup, MenuGroupLabel, MenuItem, MenuLinkItem, MenuPopup, MenuPortal, MenuPositioner, MenuRadioGroup, MenuRadioItem, MenuRadioItemIndicator, MenuSeparator, MenuShortcut, MenuSubmenuRoot, MenuSubmenuTrigger, MenuTrigger, MenuViewport, createMenuHandle, menuItemVariants };
