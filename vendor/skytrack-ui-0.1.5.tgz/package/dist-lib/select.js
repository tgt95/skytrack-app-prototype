import { t as cn } from "./chunks/utils-QluraT_M.js";
import { focusRing } from "./button.js";
import "react";
import { CaretDownIcon, CaretUpDownIcon, CaretUpIcon, CheckIcon } from "@phosphor-icons/react";
import { cva } from "class-variance-authority";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Select as Select$1 } from "@base-ui/react/select";
//#region src/components/ui/select.tsx
function Select(props) {
	return /* @__PURE__ */ jsx(Select$1.Root, { ...props });
}
function SelectLabel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.Label, {
		"data-slot": "select-label",
		className: cn("cursor-default text-sm font-medium leading-none text-foreground", className),
		...props
	});
}
var selectTriggerVariants = cva(cn("flex w-full cursor-pointer items-center justify-between gap-2 whitespace-nowrap rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground shadow-xs transition-colors", "data-[placeholder]:text-muted-foreground", "hover:not-data-[disabled]:bg-accent hover:not-data-[disabled]:text-accent-foreground", "active:not-data-[disabled]:bg-accent", "data-[pressed]:bg-accent data-[pressed]:text-accent-foreground", "data-[disabled]:cursor-not-allowed data-[disabled]:opacity-50 disabled:pointer-events-none disabled:opacity-50", "data-[invalid]:border-destructive data-[invalid]:ring-destructive/20", "*:data-[slot=select-value]:truncate", focusRing), {
	variants: { size: {
		default: "min-h-9 py-1",
		sm: "min-h-8 text-xs"
	} },
	defaultVariants: { size: "default" }
});
function SelectTrigger({ className, size, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.Trigger, {
		"data-slot": "select-trigger",
		className: cn(selectTriggerVariants({ size }), className),
		...props
	});
}
function SelectValue({ className, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.Value, {
		"data-slot": "select-value",
		className: cn("truncate text-left data-[placeholder]:text-muted-foreground", className),
		...props
	});
}
function SelectIcon({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.Icon, {
		"data-slot": "select-icon",
		className: cn("flex size-4 shrink-0 items-center justify-center text-muted-foreground", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretUpDownIcon, { className: "size-4" })
	});
}
function SelectPortal({ className, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.Portal, {
		"data-slot": "select-portal",
		className: cn(className),
		...props
	});
}
function SelectBackdrop({ className, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.Backdrop, {
		"data-slot": "select-backdrop",
		className: cn("fixed inset-0 z-50 bg-black/20 transition-opacity data-[starting-style]:opacity-0 data-[ending-style]:opacity-0", className),
		...props
	});
}
function SelectPositioner({ className, side = "bottom", align = "start", sideOffset = 4, alignItemWithTrigger = false, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.Positioner, {
		"data-slot": "select-positioner",
		side,
		align,
		sideOffset,
		alignItemWithTrigger,
		className: cn("z-50 outline-hidden", className),
		...props
	});
}
function SelectPopup({ className, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.Popup, {
		"data-slot": "select-popup",
		className: cn("max-h-[var(--available-height)] min-w-[var(--anchor-width)] origin-[var(--transform-origin)] overflow-x-hidden overflow-y-auto rounded-md border border-border bg-popover text-popover-foreground shadow-md", "transition-[transform,scale,opacity] duration-150 ease-out", "data-[starting-style]:scale-95 data-[starting-style]:opacity-0", "data-[ending-style]:scale-95 data-[ending-style]:opacity-0", className),
		...props
	});
}
function SelectList({ className, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.List, {
		"data-slot": "select-list",
		className: cn("max-h-[var(--available-height)] scroll-py-1 overflow-y-auto overscroll-contain py-1 outline-hidden", className),
		...props
	});
}
function SelectItem({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.Item, {
		"data-slot": "select-item",
		className: cn("relative grid cursor-pointer grid-cols-[1rem_1fr] items-center gap-2 rounded-sm px-2 py-1.5 text-sm select-none", "data-[highlighted]:bg-accent data-[highlighted]:text-accent-foreground", "data-[disabled]:pointer-events-none data-[disabled]:opacity-50", focusRing, className),
		...props,
		children: children ?? /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(SelectItemIndicator, {}), /* @__PURE__ */ jsx(SelectItemText, {})] })
	});
}
function SelectItemText({ className, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.ItemText, {
		"data-slot": "select-item-text",
		className: cn("col-start-2 truncate", className),
		...props
	});
}
function SelectItemIndicator({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.ItemIndicator, {
		"data-slot": "select-item-indicator",
		className: cn("col-start-1 flex items-center justify-center", "transition-transform data-[starting-style]:scale-50 data-[ending-style]:scale-50", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CheckIcon, { className: "size-4" })
	});
}
function SelectArrow({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.Arrow, {
		"data-slot": "select-arrow",
		className: cn("flex size-4 items-center justify-center text-muted-foreground", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretDownIcon, { className: "size-4 rotate-180" })
	});
}
function SelectScrollUpArrow({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.ScrollUpArrow, {
		"data-slot": "select-scroll-up-arrow",
		className: cn("top-0 z-10 flex h-4 w-full cursor-default items-center justify-center bg-popover text-muted-foreground", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretUpIcon, { className: "size-3" })
	});
}
function SelectScrollDownArrow({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.ScrollDownArrow, {
		"data-slot": "select-scroll-down-arrow",
		className: cn("bottom-0 z-10 flex h-4 w-full cursor-default items-center justify-center bg-popover text-muted-foreground", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretDownIcon, { className: "size-3" })
	});
}
function SelectGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.Group, {
		"data-slot": "select-group",
		className: cn(className),
		...props
	});
}
function SelectGroupLabel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.GroupLabel, {
		"data-slot": "select-group-label",
		className: cn("px-2 py-1.5 text-xs leading-5 font-medium text-muted-foreground select-none", className),
		...props
	});
}
function SelectSeparator({ className, ...props }) {
	return /* @__PURE__ */ jsx(Select$1.Separator, {
		"data-slot": "select-separator",
		className: cn("-mx-1 my-1 h-px bg-border", className),
		...props
	});
}
//#endregion
export { Select, SelectArrow, SelectBackdrop, SelectGroup, SelectGroupLabel, SelectIcon, SelectItem, SelectItemIndicator, SelectItemText, SelectLabel, SelectList, SelectPopup, SelectPortal, SelectPositioner, SelectScrollDownArrow, SelectScrollUpArrow, SelectSeparator, SelectTrigger, SelectValue, selectTriggerVariants };
