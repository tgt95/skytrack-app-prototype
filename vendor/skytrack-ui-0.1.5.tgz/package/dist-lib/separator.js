import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { Separator as Separator$1 } from "@base-ui/react/separator";
//#region src/components/ui/separator.tsx
function Separator({ className, orientation = "horizontal", ...props }) {
	return /* @__PURE__ */ jsx(Separator$1, {
		"data-slot": "separator",
		orientation,
		className: cn("shrink-0 bg-border", orientation === "horizontal" ? "h-px w-full" : "h-full w-px", className),
		...props
	});
}
//#endregion
export { Separator };
