import { t as cn } from "./chunks/utils-QluraT_M.js";
import { buttonVariants } from "./button.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { Dialog as Dialog$1 } from "@base-ui/react/dialog";
//#region src/components/ui/dialog.tsx
/**
* Dialog — a popup that opens on top of the entire page.
* `Dialog` (Root) renders no element of its own, so it is re-exported as-is.
*/
var Dialog = Dialog$1.Root;
/** Creates a handle that lets detached triggers control this dialog. */
var createHandle = Dialog$1.createHandle;
function DialogTrigger({ className, ...props }) {
	return /* @__PURE__ */ jsx(Dialog$1.Trigger, {
		"data-slot": "dialog-trigger",
		className,
		...props
	});
}
function DialogPortal({ className, ...props }) {
	return /* @__PURE__ */ jsx(Dialog$1.Portal, {
		"data-slot": "dialog-portal",
		className: cn("z-50", className),
		...props
	});
}
function DialogBackdrop({ className, ...props }) {
	return /* @__PURE__ */ jsx(Dialog$1.Backdrop, {
		"data-slot": "dialog-backdrop",
		className: cn("fixed inset-0 z-50 min-h-dvh bg-black/70 transition-opacity duration-150", "supports-[-webkit-touch-callout:none]:absolute", "data-[starting-style]:opacity-0 data-[ending-style]:opacity-0 data-[closed]:pointer-events-none", className),
		...props
	});
}
/** Convenience alias matching the shadcn naming. */
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ jsx(DialogBackdrop, {
		"data-slot": "dialog-overlay",
		className,
		...props
	});
}
function DialogViewport({ className, ...props }) {
	return /* @__PURE__ */ jsx(Dialog$1.Viewport, {
		"data-slot": "dialog-viewport",
		className: cn("fixed inset-0 z-50 overflow-y-auto overscroll-contain", className),
		...props
	});
}
function DialogPopup({ className, ...props }) {
	return /* @__PURE__ */ jsx(Dialog$1.Popup, {
		"data-slot": "dialog-popup",
		className: cn("fixed top-[calc(50%+var(--nested-dialogs,0)*1.25rem)] left-1/2 z-50 flex w-full max-w-[calc(100vw-2rem)] -translate-x-1/2 -translate-y-1/2 scale-[calc(1-0.1*var(--nested-dialogs,0))] flex-col gap-4 rounded-(--radius) border border-border bg-background p-6 text-foreground shadow-lg sm:max-w-lg", "after:pointer-events-none after:absolute after:inset-0 after:bg-foreground/5 after:opacity-0 after:transition-opacity after:duration-100", "data-[nested-dialog-open]:after:opacity-100", "transition-[top,scale,opacity] duration-100 ease-out", "data-[starting-style]:top-[calc(50%+0.25rem+var(--nested-dialogs,0)*1.25rem)] data-[starting-style]:scale-[calc(0.96-0.1*var(--nested-dialogs,0))] data-[starting-style]:opacity-0", "data-[ending-style]:top-[calc(50%+0.25rem+var(--nested-dialogs,0)*1.25rem)] data-[ending-style]:scale-[calc(0.96-0.1*var(--nested-dialogs,0))] data-[ending-style]:opacity-0", "motion-reduce:transition-none", className),
		...props
	});
}
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "dialog-header",
		className: cn("flex flex-col gap-1.5 text-left", className),
		...props
	});
}
function DialogFooter({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "dialog-footer",
		className: cn("flex flex-col-reverse gap-3 sm:flex-row sm:justify-end", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ jsx(Dialog$1.Title, {
		"data-slot": "dialog-title",
		className: cn("text-base leading-none font-semibold", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ jsx(Dialog$1.Description, {
		"data-slot": "dialog-description",
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
function DialogClose({ className, variant, size, ...props }) {
	return /* @__PURE__ */ jsx(Dialog$1.Close, {
		"data-slot": "dialog-close",
		className: cn(buttonVariants({
			variant: variant ?? "outline",
			size
		}), className),
		...props
	});
}
//#endregion
export { Dialog, DialogBackdrop, DialogClose, DialogDescription, DialogFooter, DialogHeader, DialogOverlay, DialogPopup, DialogPortal, DialogTitle, DialogTrigger, DialogViewport, createHandle };
