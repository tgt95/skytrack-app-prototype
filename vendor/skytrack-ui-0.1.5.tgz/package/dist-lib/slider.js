import { t as cn } from "./chunks/utils-QluraT_M.js";
import "react";
import { jsx } from "react/jsx-runtime";
import { Slider as Slider$1 } from "@base-ui/react/slider";
//#region src/components/ui/slider.tsx
function Slider({ className, thumbAlignment = "edge", ...props }) {
	const widthClass = props.orientation === "vertical" ? "w-auto" : "w-full";
	return /* @__PURE__ */ jsx(Slider$1.Root, {
		"data-slot": "slider",
		thumbAlignment,
		className: cn("flex flex-col gap-2 data-[disabled]:opacity-50", widthClass, className),
		...props
	});
}
function SliderLabel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Slider$1.Label, {
		"data-slot": "slider-label",
		className: cn("text-sm font-medium text-foreground", className),
		...props
	});
}
function SliderValue({ className, ...props }) {
	return /* @__PURE__ */ jsx(Slider$1.Value, {
		"data-slot": "slider-value",
		className: cn("text-sm tabular-nums text-muted-foreground", className),
		...props
	});
}
function SliderControl({ className, ...props }) {
	return /* @__PURE__ */ jsx(Slider$1.Control, {
		"data-slot": "slider-control",
		className: cn("flex w-full cursor-pointer items-center touch-none select-none", "data-[orientation=vertical]:h-44 data-[orientation=vertical]:w-auto data-[orientation=vertical]:flex-col", "data-[disabled]:pointer-events-none", className),
		...props
	});
}
function SliderTrack({ className, ...props }) {
	return /* @__PURE__ */ jsx(Slider$1.Track, {
		"data-slot": "slider-track",
		className: cn("h-1.5 w-full rounded-full bg-muted select-none", "data-[orientation=vertical]:h-full data-[orientation=vertical]:w-1.5", className),
		...props
	});
}
function SliderIndicator({ className, ...props }) {
	return /* @__PURE__ */ jsx(Slider$1.Indicator, {
		"data-slot": "slider-indicator",
		className: cn("select-none bg-primary", className),
		...props
	});
}
function SliderThumb({ className, ...props }) {
	return /* @__PURE__ */ jsx(Slider$1.Thumb, {
		"data-slot": "slider-thumb",
		className: cn("block size-4 cursor-pointer shrink-0 rounded-xl border border-primary bg-background shadow-sm", "data-[dragging]:shadow-md", "data-[disabled]:border-muted-foreground", "outline-none focus-within:ring-[3px] focus-within:ring-ring/50 focus-within:border-ring", className),
		...props
	});
}
//#endregion
export { Slider, SliderControl, SliderIndicator, SliderLabel, SliderThumb, SliderTrack, SliderValue };
