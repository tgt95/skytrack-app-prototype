import { t as cn } from "./chunks/utils-bl1I_eUQ.js";
import { i as CONTROL_SIZE_CLASSES, r as focusRing } from "./chunks/button-1Z23yCSW.js";
import "react";
import { CaretLeftIcon, CaretRightIcon } from "@phosphor-icons/react";
import { jsx } from "react/jsx-runtime";
import { NumberField as NumberField$1 } from "@base-ui/react/number-field";
//#region src/components/ui/number-field.tsx
function NumberField({ className, ...props }) {
	return /* @__PURE__ */ jsx(NumberField$1.Root, {
		"data-slot": "number-field",
		className: cn("flex flex-col items-start gap-1", className),
		...props
	});
}
function NumberFieldGroup({ className, size = "default", ...props }) {
	return /* @__PURE__ */ jsx(NumberField$1.Group, {
		"data-slot": "number-field-group",
		"data-size": size,
		className: cn("flex items-stretch", CONTROL_SIZE_CLASSES[size], className),
		...props
	});
}
function NumberFieldInput({ className, size = "default", ...props }) {
	return /* @__PURE__ */ jsx(NumberField$1.Input, {
		"data-slot": "number-field-input",
		"data-size": size,
		className: cn(size === "default" ? cn(CONTROL_SIZE_CLASSES.default, "w-16 border border-input bg-background px-3 text-left tabular-nums") : cn(CONTROL_SIZE_CLASSES[size], "w-full min-w-0 border border-input bg-background px-1 text-right tabular-nums"), "placeholder:text-muted-foreground", "data-disabled:cursor-not-allowed data-disabled:opacity-50 data-readonly:bg-muted", "data-invalid:border-destructive", focusRing, className),
		...props
	});
}
var stepperClasses = cn("flex h-full w-9 cursor-pointer shrink-0 items-center justify-center border border-input bg-background text-foreground transition-colors select-none", "hover:bg-accent hover:text-accent-foreground", "active:bg-secondary", "data-disabled:pointer-events-none data-disabled:opacity-50 data-readonly:bg-muted", focusRing);
function NumberFieldDecrement({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(NumberField$1.Decrement, {
		"data-slot": "number-field-decrement",
		className: cn(stepperClasses, "border-e-0", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretLeftIcon, {})
	});
}
function NumberFieldIncrement({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(NumberField$1.Increment, {
		"data-slot": "number-field-increment",
		className: cn(stepperClasses, "border-s-0", className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretRightIcon, {})
	});
}
function NumberFieldScrubArea({ className, ...props }) {
	return /* @__PURE__ */ jsx(NumberField$1.ScrubArea, {
		"data-slot": "number-field-scrub-area",
		className: cn("group cursor-ew-resize select-none", "data-disabled:pointer-events-none data-disabled:opacity-50", className),
		...props
	});
}
function NumberFieldScrubAreaCursor({ className, ...props }) {
	return /* @__PURE__ */ jsx(NumberField$1.ScrubAreaCursor, {
		"data-slot": "number-field-scrub-area-cursor",
		className: cn("pointer-events-none flex items-center opacity-0 transition-opacity data-scrubbing:opacity-100", className),
		...props
	});
}
//#endregion
export { NumberField, NumberFieldDecrement, NumberFieldGroup, NumberFieldIncrement, NumberFieldInput, NumberFieldScrubArea, NumberFieldScrubAreaCursor };
